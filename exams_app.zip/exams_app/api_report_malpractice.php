<?php
// api_report_malpractice.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['session_id'])) {
    $session_id = (int)$_POST['session_id'];
    $user_id = $_SESSION['user_id'];

    // 1. Verify session and get student department
    $sq = mysqli_query($conn, "SELECT es.*, ep.course_id, u.department_id as student_dept_id 
                               FROM exam_sessions es 
                               JOIN exam_papers ep ON es.exam_paper_id = ep.id
                               JOIN users u ON es.student_id = u.id
                               WHERE es.id = $session_id AND es.student_id = $user_id AND es.status = 'In_progress' 
                               LIMIT 1");
    
    if (!$sq || mysqli_num_rows($sq) === 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid or already completed session.']);
        exit();
    }
    
    $session = mysqli_fetch_assoc($sq);
    $paper_id = $session['exam_paper_id'];
    $dept_id = $session['student_dept_id'];

    // 2. Create Malpractice Report
    $incident_type = 'Unatuthorized Tab Switch / Window Blur';
    $details = 'Automatic detection: Student moved away from the examination tab/window.';
    
    $mq = mysqli_query($conn, "INSERT INTO malpractice_reports (student_id, exam_paper_id, session_id, department_id, incident_type, details) 
                               VALUES ($user_id, $paper_id, $session_id, $dept_id, '$incident_type', '$details')");

    if (!$mq) {
        echo json_encode(['success' => false, 'message' => 'Failed to log malpractice.']);
        exit();
    }

    // 3. Mark session as Completed (Abnormally)
    mysqli_query($conn, "UPDATE exam_sessions SET status = 'Completed' WHERE id = $session_id");

    // 4. Force Result to 0
    $total_score = 0;
    $grading_status = 'malpractice_detected';
    
    $r_check = mysqli_query($conn, "SELECT id FROM exam_results WHERE exam_paper_id = $paper_id AND student_id = $user_id");
    if ($r_check && mysqli_num_rows($r_check) > 0) {
        mysqli_query($conn, "UPDATE exam_results SET total_score = $total_score, grading_status = '$grading_status' WHERE exam_paper_id = $paper_id AND student_id = $user_id");
    } else {
        mysqli_query($conn, "INSERT INTO exam_results (exam_paper_id, student_id, total_score, grading_status) VALUES ($paper_id, $user_id, $total_score, '$grading_status')");
    }

    echo json_encode(['success' => true]);
    exit();
}

echo json_encode(['success' => false, 'message' => 'Invalid request.']);
?>
