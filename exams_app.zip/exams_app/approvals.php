<?php
// approvals.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['admin', 'hod', 'exam_master']);
$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Handle Approvals
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $paper_id = (int)$_POST['paper_id'];
    $action = $_POST['action'] ?? ''; // 'approve' or 'reject'

    // Determine the current state and new state based on role
    // Flow: submitted -> published
    if ($paper_id > 0) {
        // fetch paper
        $pq = mysqli_query($conn, "SELECT status FROM exam_papers WHERE id = $paper_id");
        if ($pq && mysqli_num_rows($pq) > 0) {
            $p = mysqli_fetch_assoc($pq);
            $new_status = '';

            if ($action === 'approve') {
                if ($role === 'hod' && $p['status'] === 'Submitted') {
                    $new_status = 'Hod_approved';
                } elseif ($role === 'exam_master' && $p['status'] === 'Hod_approved') {
                    $new_status = 'Published';
                }
            } elseif ($action === 'reject') {
                $new_status = 'Draft';
            }

            if (! empty($new_status)) {
                $sql_update = "UPDATE exam_papers SET status = '$new_status'";
                if ($new_status === 'Ready_for_print') {
                    $sql_update .= ", dean_approved_at = CURRENT_TIMESTAMP";
                } elseif ($new_status === 'Hod_approved' || $new_status === 'Approved') {
                    $sql_update .= ", hod_approved_at = CURRENT_TIMESTAMP";
                }

                $sql_update .= " WHERE id = $paper_id";
                mysqli_query($conn, $sql_update);

                // Add workflow history
                $action_log = 'rejected';
                if ($action === 'approve') {
                    $action_log = $new_status === 'Published' ? 'Published' : 'Approved';
                }
                mysqli_query($conn, "INSERT INTO workflow_history (exam_paper_id, action, from_status, to_status, actor_id, actor_role) 
                                     VALUES ($paper_id, '$action_log', '{$p['status']}', '$new_status', $user_id, '$role')");

                set_flash_message('success', "Paper successfully $action_log.");
            } else {
                set_flash_message('danger', "Invalid state transition.");
            }
        }
    }
    header("Location: approvals.php");
    exit();
}

// Fetch papers needing approval
$query_where = "ep.deleted_at IS NULL AND ep.academic_year = '2026' AND ";

if ($role === 'hod') {
    $dep_id = (int)($_SESSION['department_id'] ?? 0);
    $query_where .= "ep.status = 'Submitted' AND c.department_id = $dep_id";
} elseif ($role === 'exam_master') {
    $dep_id = (int)($_SESSION['department_id'] ?? 0);
    $query_where .= "ep.status = 'Hod_approved' AND c.department_id = $dep_id";
} else { // admin
    $query_where .= "ep.status = 'Published'";
}

$sql = "SELECT ep.*, c.code as course_code, c.title as course_title,
        CONCAT(u.first_name, ' ', u.last_name) as creator_name
        FROM exam_papers ep
        JOIN courses c ON ep.course_id = c.id
        LEFT JOIN users u ON ep.created_by = u.id
        WHERE $query_where ORDER BY ep.created_at ASC";

$papers = [];
$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $papers[] = $row;
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<div class="d-flex justify-content-center align-items-center mb-4 text-center">
    <h2 class="w-100"><i class="bi bi-check2-square"></i> <?php echo ($role === 'admin') ? 'Approved Exams' : 'Exams Pending Approval'; ?></h2>
</div>

<div class="row g-4">
    <?php if (empty($papers)): ?>
        <div class="col-12 text-center py-5">
            <h4 class="text-muted"><i class="bi bi-folder-x"></i> No Exams currently require your approval.</h4>
        </div>
    <?php else: ?>
        <?php foreach ($papers as $p): ?>
            <div class="col-md-6 col-lg-3">
                <div class="card border-0 shadow-sm rounded-4 h-100 hover-shadow transition-all">
                    <div class="card-body p-4 text-center">
                        <div class="display-6 text-primary mb-3"><i class="bi bi-file-earmark-text"></i></div>
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($p['course_code']); ?></h5>
                        <p class="text-muted small mb-3"><?php echo htmlspecialchars($p['course_title']); ?></p>
                        <p class="text-secondary small mb-2">
                            <i class="bi bi-calendar3"></i> Published: <?php echo date('M j, Y', strtotime($p['published_at'] ?? $p['created_at'])); ?>
                        </p>
                        <p class="text-secondary small mb-3"><i class="bi bi-person"></i> <?php echo htmlspecialchars($p['creator_name']); ?></p>
                        <div class="d-flex justify-content-center gap-2 flex-wrap">
                            <a href="view_paper.php?id=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="bi bi-eye"></i> View Paper</a>

                            <?php if ($role !== 'admin'): ?>
                                <?php if ($role === 'hod'): ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="paper_id" value="<?php echo $p['id']; ?>">
                                        <input type="hidden" name="action" value="approve">
                                        <button type="submit" class="btn btn-sm btn-primary shadow-sm" onclick="return confirm('Approve and forward this paper to the Exam Master?')">
                                            <i class="bi bi-send-check"></i> Approve & Forward
                                        </button>
                                    </form>
                                <?php elseif ($role === 'exam_master'): ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="paper_id" value="<?php echo $p['id']; ?>">
                                        <input type="hidden" name="action" value="approve">
                                        <button type="submit" class="btn btn-sm btn-primary shadow-sm" onclick="return confirm('Publish this paper?')">
                                            <i class="bi bi-cloud-arrow-up"></i> Publish
                                        </button>
                                    </form>
                                <?php endif; ?>
                                <button class="btn btn-sm btn-danger shadow-sm ms-1" data-bs-toggle="modal" data-bs-target="#rejectModal" data-id="<?php echo $p['id']; ?>"><i class="bi bi-x-lg"></i> Reject</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<style>
    .hover-shadow:hover {
        transform: translateY(-5px);
        box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15) !important;
    }

    .transition-all {
        transition: all 0.3s ease;
    }
</style>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Reject Paper</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="reject">
                    <input type="hidden" name="paper_id" id="reject_id">
                    <p>Are you sure you want to reject this paper and send it back to draft?</p>
                    <div class="mb-3">
                        <label class="form-label">Feedback / Reason (Optional)</label>
                        <textarea class="form-control" name="feedback" rows="3" placeholder="Explain what needs to be changed..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reject Paper</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var rejectModal = document.getElementById('rejectModal');
        if (rejectModal) {
            rejectModal.addEventListener('show.bs.modal', function(event) {
                var button = event.relatedTarget;
                rejectModal.querySelector('#reject_id').value = button.getAttribute('data-id');
            });
        }
    });
</script>

<?php require_once 'includes/footer.php'; ?>