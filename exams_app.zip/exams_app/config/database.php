<?php
// config/database.php

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Set to empty string for XAMPP default, or 'your_password' if configured
define('DB_NAME', 'uems');
define('DB_PORT', 3306);

// Create a procedural mysqli connection
function get_db_connection() {
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);

    if (!$conn) {
        die("Database connection failed: " . mysqli_connect_error());
    }
    
    // Set charset to UTF-8
    mysqli_set_charset($conn, "utf8mb4");

    return $conn;
}

// Global connection variable
$conn = get_db_connection();
?>
