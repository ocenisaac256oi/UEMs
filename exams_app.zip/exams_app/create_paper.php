<?php
// create_paper.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['lecturer']);
$user_id = $_SESSION['user_id'];

// Fetch Courses for Dropdown (Strictly filtered by lecturer's department)
$user_dept_id = (int)($_SESSION['department_id'] ?? 0);
$courses = [];
$c_query = "SELECT id, code, title, department_id, level, semester FROM courses WHERE deleted_at IS NULL";
if (($_SESSION['role'] ?? '') !== 'admin') {
    $c_query .= " AND department_id = $user_dept_id";
}
$c_query .= " ORDER BY code";

$c_res = mysqli_query($conn, $c_query);
if ($c_res) {
    while ($row = mysqli_fetch_assoc($c_res)) {
        $courses[] = $row;
    }
}
$departments = [];
$user_role = $_SESSION['role'] ?? '';
$user_dept_id = (int)($_SESSION['department_id'] ?? 0);

if ($user_role === 'admin') {
    $d_query = "SELECT id, name FROM departments ORDER BY name";
} else {
    $d_query = "SELECT id, name FROM departments WHERE id = $user_dept_id ORDER BY name";
}

$d_res = mysqli_query($conn, $d_query);
if ($d_res) {
    while ($row = mysqli_fetch_assoc($d_res)) {
        $departments[] = $row;
    }
}

// Output logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = (int)$_POST['course_id'];
    $exam_type = sanitize_input($conn, $_POST['exam_type']);
    $academic_year = (int)$_POST['academic_year'];
    $semester = (int)$_POST['semester'];
    $year_of_study = isset($_POST['year_of_study']) ? (int)$_POST['year_of_study'] : 1;
    $duration = (int)$_POST['duration'];
    $total_marks = (int)$_POST['total_marks'];
    $instructions = sanitize_input($conn, $_POST['instructions'] ?? '');
    $paper_content = sanitize_input($conn, $_POST['paper_content'] ?? '');
    // exam_date has been removed from the system. We now use academic_year exclusively.

    if ($course_id > 0 && !empty($exam_type) && $academic_year > 0 && $semester > 0) {
        // Look up course logic
        $c_q = mysqli_query($conn, "SELECT code, department_id, college_id FROM courses WHERE id = $course_id");
        $courseData = mysqli_fetch_assoc($c_q);

        if ($courseData) {
            // Assume we fetch hod_id based on department...
            $hod_id = 'NULL';
            $hq = mysqli_query($conn, "SELECT id FROM users WHERE department_id = {$courseData['department_id']} AND role = 'hod' LIMIT 1");
            if ($hq && mysqli_num_rows($hq) > 0) $hod_id = mysqli_fetch_assoc($hq)['id'];

            $sql = "INSERT INTO exam_papers (course_id, created_by, exam_type, academic_year, semester, year_of_study, duration, total_marks, instructions, paper_content, status, hod_id, created_at) 
                    VALUES ($course_id, $user_id, '$exam_type', $academic_year, $semester, $year_of_study, $duration, $total_marks, '$instructions', '$paper_content', 'Draft', $hod_id, NOW())";

            if (mysqli_query($conn, $sql)) {
                $new_id = mysqli_insert_id($conn);
                set_flash_message('success', 'Exam paper created successfully!');
                header("Location: view_paper.php?id=" . $new_id);
                exit();
            } else {
                set_flash_message('danger', 'Error creating exam paper drafting phase.');
            }
        }
    } else {
        set_flash_message('danger', 'Please fill all required fields properly.');
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="text-center mb-4">
            <h2 class="fw-bold mb-3"><i class="bi bi-file-earmark-plus text-primary"></i> Create Exam Paper</h2>
            <a href="exam_papers.php" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left"></i> Back to Papers
            </a>
        </div>

        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4">
                <form method="POST">

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Department <span class="text-danger">*</span></label>
                            <select class="form-select" id="department_id" name="department_id" required>
                                <?php if (count($departments) > 1): ?>
                                    <option value="">-- Select Department --</option>
                                <?php endif; ?>
                                <?php foreach ($departments as $d): ?>
                                    <option value="<?php echo $d['id']; ?>" <?php echo ($d['id'] == $user_dept_id) ? 'selected' : ''; ?>><?php echo htmlspecialchars($d['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Select Course <span class="text-danger">*</span></label>
                            <select class="form-select" id="course_id" name="course_id" required>
                                <option value="">-- Choose a Course --</option>
                                <?php foreach ($courses as $c): ?>
                                    <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['code'] . ' - ' . $c['title']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Exam Type <span class="text-danger">*</span></label>
                            <select class="form-select" name="exam_type" id="exam_type" required>
                                <option value="End of Semester">End of Semester</option>
                                <option value="CAT">CATs</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Duration (Mins) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="duration" id="duration" value="180" min="30" max="360" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Total Marks <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="total_marks" id="total_marks" value="60" min="1" max="100" required>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Academic Year <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="academic_year" value="<?php echo date('Y'); ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Year of Study <span class="text-danger">*</span></label>
                            <select class="form-select" id="year_of_study" name="year_of_study" required>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Semester <span class="text-danger">*</span></label>
                            <select class="form-select" id="semester" name="semester" required>
                                <option value="1">Semester 1</option>
                                <option value="2">Semester 2</option>
                            </select>
                        </div>
                    </div>

                    <!-- Examination Date removed in favor of Academic Year -->

                    <div class="mb-4">
                        <label class="form-label fw-bold">Candidate Instructions (Optional)</label>
                        <textarea class="form-control" name="instructions" rows="3" placeholder="Enter specific instructions for students (e.g., Answer any 4 questions)"></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold text-primary">Examination Paper Content <span class="text-danger">*</span></label>
                        <div class="alert alert-info py-2 small mb-2"><i class="bi bi-info-circle"></i> Type or paste your full examination questions here. This will be printed exactly as shown.</div>
                        <textarea class="form-control font-monospace" name="paper_content" rows="15" placeholder="Q1. Explain the concepts of..." required style="resize: vertical;"></textarea>
                    </div>

                    <hr class="my-4">

                    <div class="text-center">
                        <button type="submit" class="btn btn-primary px-5 py-2 fw-bold shadow-sm"><i class="bi bi-save"></i> Save Examination Paper</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const coursesData = <?php echo json_encode($courses); ?>;
    
    const deptSelect = document.getElementById('department_id');
    const yearSelect = document.getElementById('year_of_study');
    const semSelect = document.getElementById('semester');
    const courseSelect = document.getElementById('course_id');
    
    function filterCourses() {
        const deptId = deptSelect.value;
        const year = yearSelect.value;
        const sem = semSelect.value;
        
        courseSelect.innerHTML = '<option value="">-- Choose a Course --</option>';
        
        // Show all if criteria not selected
        let filtered = coursesData;
        if (deptId) {
            filtered = filtered.filter(c => c.department_id == deptId);
        }
        if (year) {
            filtered = filtered.filter(c => c.level == year);
        }
        if (sem) {
            filtered = filtered.filter(c => c.semester == sem);
        }
        
        filtered.forEach(c => {
            const opt = document.createElement('option');
            opt.value = c.id;
            opt.textContent = c.code + ' - ' + c.title;
            courseSelect.appendChild(opt);
        });
    }
    
    deptSelect.addEventListener('change', filterCourses);
    yearSelect.addEventListener('change', filterCourses);
    semSelect.addEventListener('change', filterCourses);
    
    // Initial run to clear invalid selections by default
    filterCourses();

    const examTypeSelect = document.getElementById('exam_type');
    const durationInput = document.getElementById('duration');
    const totalMarksInput = document.getElementById('total_marks');
    if (examTypeSelect && durationInput && totalMarksInput) {
        examTypeSelect.addEventListener('change', function() {
            if (this.value === 'CAT') {
                durationInput.value = 60;
                totalMarksInput.value = 40;
            } else {
                durationInput.value = 180;
                totalMarksInput.value = 60;
            }
        });
    }
});
</script>
