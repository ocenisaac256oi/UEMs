SET FOREIGN_KEY_CHECKS=0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS gender ENUM('Male', 'Female') DEFAULT NULL AFTER last_name;

ALTER TABLE exam_papers MODIFY status ENUM('draft', 'submitted', 'hod_review', 'hod_approved', 'hod_rejected', 'dean_review', 'dean_approved', 'dean_rejected', 'ready_for_print', 'printing', 'printed', 'published', 'Draft', 'Submitted', 'Approved', 'Hod_review', 'Hod_approved', 'Hod_rejected', 'Dean_review', 'Dean_approved', 'Dean_rejected', 'Ready_for_print', 'Printing', 'Printed', 'Published') DEFAULT 'Draft';
UPDATE exam_papers SET status = CONCAT(UCASE(LEFT(status, 1)), LCASE(SUBSTRING(status, 2)));
ALTER TABLE exam_papers MODIFY status ENUM('Draft', 'Submitted', 'Approved', 'Hod_review', 'Hod_approved', 'Hod_rejected', 'Dean_review', 'Dean_approved', 'Dean_rejected', 'Ready_for_print', 'Printing', 'Printed', 'Published') DEFAULT 'Draft';

-- Indices for Question Bank Optimization
ALTER TABLE exam_papers ADD INDEX IF NOT EXISTS idx_year_of_study (year_of_study);
ALTER TABLE exam_papers ADD INDEX IF NOT EXISTS idx_semester (semester);

-- Allow system-generated papers without a creator
ALTER TABLE exam_papers MODIFY created_by INT(11) NULL;
ALTER TABLE exam_papers DROP FOREIGN KEY IF EXISTS exam_papers_ibfk_2;
ALTER TABLE exam_papers ADD CONSTRAINT exam_papers_ibfk_2 FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE exam_sessions MODIFY status ENUM('in_progress', 'completed', 'expired', 'In_progress', 'Completed', 'Expired') DEFAULT 'In_progress';
UPDATE exam_sessions SET status = CONCAT(UCASE(LEFT(status, 1)), LCASE(SUBSTRING(status, 2)));
ALTER TABLE exam_sessions MODIFY status ENUM('In_progress', 'Completed', 'Expired') DEFAULT 'In_progress';

SET FOREIGN_KEY_CHECKS=1;
