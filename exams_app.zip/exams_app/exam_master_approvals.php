<?php
// exam_master_approvals.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['hod', 'admin']);
$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Handle Submission to Exam Master
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_exam_master') {
    $paper_id = (int)$_POST['paper_id'];
    if ($paper_id > 0 && $role === 'hod') {
        $pq = mysqli_query($conn, "SELECT status FROM exam_papers WHERE id = $paper_id");
        if ($pq && mysqli_num_rows($pq) > 0) {
            $p = mysqli_fetch_assoc($pq);
            if ($p['status'] === 'Approved') {
                $sql_update = "UPDATE exam_papers SET status = 'Hod_approved' WHERE id = $paper_id";
                mysqli_query($conn, $sql_update);
                
                mysqli_query($conn, "INSERT INTO workflow_history (exam_paper_id, action, from_status, to_status, actor_id, actor_role) 
                                     VALUES ($paper_id, 'submitted_to_exam_master', 'Approved', 'Hod_approved', $user_id, '$role')");
                
                set_flash_message('success', "Paper successfully submitted to Exam Master.");
            }
        }
    }
    header("Location: exam_master_approvals.php");
    exit();
}

// Fetch papers approved by HOD but not yet published
$query_where = "ep.deleted_at IS NULL AND ep.status IN ('Approved', 'Hod_approved')";

if ($role === 'hod') {
    $dep_id = (int)($_SESSION['department_id'] ?? 0);
    $query_where .= " AND c.department_id = $dep_id";
}

$sql = "SELECT ep.*, c.code as course_code, c.title as course_title,
        CONCAT(u.first_name, ' ', u.last_name) as creator_name
        FROM exam_papers ep
        JOIN courses c ON ep.course_id = c.id
        LEFT JOIN users u ON ep.created_by = u.id
        WHERE $query_where ORDER BY ep.created_at ASC";

$papers = [];
$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $papers[] = $row;
    }
}
?>

<?php require_once 'includes/header.php'; ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="bi bi-send-check"></i> Exam Master Approvals</h2>
    </div>

<div class="row g-4">
    <?php if (empty($papers)): ?>
        <div class="col-12 text-center py-5">
            <h4 class="text-muted"><i class="bi bi-folder-x"></i> No papers currently pending for Exam Master.</h4>
        </div>
    <?php else: ?>
        <?php foreach ($papers as $p): ?>
            <div class="col-md-6 col-lg-3">
                <div class="card border-0 shadow-sm rounded-4 h-100 hover-shadow transition-all">
                    <div class="card-body p-4 text-center">
                        <div class="display-6 text-warning mb-3"><i class="bi bi-hourglass-split"></i></div>
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($p['course_code']); ?></h5>
                        <p class="text-muted small mb-3"><?php echo htmlspecialchars($p['course_title']); ?></p>
                        <p class="text-secondary small mb-2">
                            <i class="bi bi-person"></i> <?php echo htmlspecialchars($p['creator_name']); ?>
                        </p>
                        <div class="mb-3">
                            <span class="badge <?php echo get_status_badge_class($p['status']); ?> rounded-pill px-3 py-2">
                                <?php echo format_status($p['status']); ?>
                            </span>
                        </div>
                        <div class="d-flex justify-content-center gap-2 flex-wrap">
                            <a href="view_paper.php?id=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-eye"></i> View Paper
                            </a>
                            <?php if ($role === 'hod' && $p['status'] === 'Approved'): ?>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="paper_id" value="<?php echo $p['id']; ?>">
                                    <input type="hidden" name="action" value="submit_exam_master">
                                    <button type="submit" class="btn btn-sm btn-primary" onclick="return confirm('Submit this paper to Exam Master?')">
                                        <i class="bi bi-send"></i> Submit
                                    </button>
                                </form>
                            <?php endif; ?>
                            <?php if ($p['status'] === 'Hod_approved'): ?>
                                <span class="badge bg-info text-dark d-flex align-items-center"><i class="bi bi-check-all me-1"></i> Submitted</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<style>
    .hover-shadow:hover {
        transform: translateY(-5px);
        box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15) !important;
    }
    .transition-all {
        transition: all 0.3s ease;
    }
</style>

<?php require_once 'includes/footer.php'; ?>
