<?php
// exam_papers.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['admin', 'hod', 'lecturer']);
$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Handling Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $id = (int)$_POST['id'];
    if ($id > 0) {
        $stmt = mysqli_prepare($conn, "UPDATE exam_papers SET deleted_at = CURRENT_TIMESTAMP WHERE id = ? AND created_by = ?");
        mysqli_stmt_bind_param($stmt, "ii", $id, $user_id);
        if (mysqli_stmt_execute($stmt)) {
            set_flash_message('success', 'Exam paper deleted successfully.');
        } else {
            set_flash_message('danger', 'Error deleting exam paper.');
        }
    }
    header("Location: exam_papers.php");
    exit();
}

// Query
// Query for 2026 Academic Year examinations only (older years categorized in Question Bank)
$query_where = "ep.deleted_at IS NULL AND ep.academic_year = '2026'";

if ($role === 'lecturer') {
    $query_where .= " AND ep.created_by = $user_id";
} elseif ($role === 'hod') {
    $dep_id = (int)($_SESSION['department_id'] ?? 0);
    $query_where .= " AND c.department_id = $dep_id AND ep.status IN ('Submitted', 'Approved', 'Hod_approved', 'Published')";
} else { // admin
    // Admins serve as Auditors and can only view Published papers for 2026
    $query_where .= " AND ep.status = 'Published'";
}

$dept_filter = isset($_GET['department_id']) ? (int)$_GET['department_id'] : 0;
if ($role === 'admin' && $dept_filter > 0) {
    $query_where .= " AND c.department_id = $dept_filter";
}

$sql = "SELECT ep.*, c.code as course_code, c.title as course_title,
        CONCAT(u.first_name, ' ', u.last_name) as creator_name,
        u.role as creator_role, u.gender as creator_gender
        FROM exam_papers ep
        LEFT JOIN courses c ON ep.course_id = c.id
        LEFT JOIN users u ON ep.created_by = u.id
        WHERE $query_where ORDER BY ep.created_at DESC";

$papers = [];
$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $papers[] = $row;
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-12 text-center">
        <h2><i class="bi bi-file-earmark-text text-primary"></i> Examination Papers</h2>
    </div>
    <?php if ($role === 'lecturer'): ?>
    <div class="col-12 text-end mt-2">
        <a href="create_paper.php" class="btn btn-primary fw-bold px-4 py-2 shadow-sm" style="border-radius: 5px;">
            <i class="bi bi-file-earmark-plus"></i> Create Examination
        </a>
    </div>
    <?php endif; ?>
</div>

<?php if ($role === 'admin'): ?>
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body py-3">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-auto">
                    <label for="department_id" class="col-form-label fw-bold">Filter by Department:</label>
                </div>
                <div class="col-md-4 col-sm-6">
                    <select name="department_id" id="department_id" class="form-select" onchange="this.form.submit()">
                        <option value="0">All Departments</option>
                        <?php
                        $departments = [];
                        $d_res = mysqli_query($conn, "SELECT id, name FROM departments WHERE deleted_at IS NULL ORDER BY name");
                        if ($d_res) {
                            while ($row = mysqli_fetch_assoc($d_res)) {
                                $departments[] = $row;
                            }
                        }
                        $dept_filter = isset($_GET['department_id']) ? (int)$_GET['department_id'] : 0;
                        foreach ($departments as $d): ?>
                            <option value="<?php echo $d['id']; ?>" <?php echo $dept_filter === (int)$d['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($d['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php if ($dept_filter > 0): ?>
                    <div class="col-auto">
                        <a href="exam_papers.php" class="btn btn-primary text-white">Clear</a>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
<?php endif; ?>

<div class="row g-4">
    <?php if (empty($papers)): ?>
        <div class="col-12 text-center py-5">
            <h4 class="text-muted"><i class="bi bi-folder-x"></i> No exam papers found.</h4>
        </div>
    <?php else: ?>
        <?php foreach ($papers as $p): ?>
            <div class="col-md-6 col-lg-3">
                <div class="card border-0 shadow-sm rounded-4 h-100 hover-shadow transition-all">
                    <div class="card-body p-4 text-center">
                        <?php if ((int)$p['academic_year'] >= 2026): ?>
                            <div class="display-6 text-primary mb-3"><i class="bi bi-file-earmark-text"></i></div>
                        <?php endif; ?>
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($p['course_code']); ?></h5>
                        <p class="text-muted small mb-3"><?php echo htmlspecialchars($p['course_title']); ?></p>
                        <?php if ((int)$p['academic_year'] >= 2026): ?>
                            <p class="text-secondary small mb-2">
                                <i class="bi bi-calendar3"></i> Year: <strong><?php echo htmlspecialchars($p['academic_year']); ?></strong>
                            </p>
                            <?php if (in_array($role, ['admin', 'hod'])): ?>
                                <p class="text-secondary small mb-3"><i class="bi bi-person"></i> <?php echo format_user_name(htmlspecialchars($p['creator_name']), $p['creator_role'] ?? '', $p['creator_gender'] ?? ''); ?></p>
                            <?php endif; ?>
                        <?php endif; ?>
                        <div class="mb-3">
                            <span class="badge <?php echo get_status_badge_class($p['status']); ?> rounded-pill px-3 py-2">
                                <?php echo format_status($p['status']); ?>
                            </span>
                        </div>
                        <div class="d-flex justify-content-center gap-2 flex-wrap">
                            <a href="view_paper.php?id=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-eye"></i> View
                            </a>
                            <?php if ($role !== 'admin' && $p['status'] === 'Draft' && $p['created_by'] == $user_id): ?>
                                <a href="paper_questions.php?id=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-list-check"></i> Add Qs
                                </a>
                                <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteModal" data-id="<?php echo $p['id']; ?>" data-code="<?php echo htmlspecialchars($p['exam_type'] ?? ''); ?>">
                                    <i class="bi bi-trash"></i> Delete
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<style>
    .hover-shadow:hover {
        transform: translateY(-5px);
        box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15) !important;
    }

    .transition-all {
        transition: all .3s ease;
    }
</style>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Confirm Deletion</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" id="delete_id">
                    <p>Delete exam paper <strong id="delete_code"></strong>?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var deleteModal = document.getElementById('deleteModal');
        if (deleteModal) {
            deleteModal.addEventListener('show.bs.modal', function(event) {
                var button = event.relatedTarget;
                document.getElementById('delete_id').value = button.getAttribute('data-id');
                document.getElementById('delete_code').textContent = button.getAttribute('data-code');
            });
        }
    });
</script>

<?php require_once 'includes/footer.php'; ?>