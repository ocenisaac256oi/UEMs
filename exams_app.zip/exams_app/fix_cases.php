<?php
$files = [
    'view_past_paper.php',
    'take_exam.php',
    'student_dashboard.php',
    'schedule_exams.php',
    'published.php',
    'index.php',
    'includes/functions.php',
    'approvals.php',
    'reports.php',
    'exam_papers.php',
    'view_paper.php',
    'paper_questions.php',
    'create_paper.php'
];

foreach ($files as $f) {
    if (file_exists($f)) {
        $content = file_get_contents($f);
        // We only want to replace string literals that represent our states:
        $search = ["'draft'", "'submitted'", "'hod_approved'", "'published'", "\"draft\"", "\"submitted\"", "\"hod_approved\"", "\"published\""];
        $replace = ["'Draft'", "'Submitted'", "'Hod_approved'", "'Published'", "\"Draft\"", "\"Submitted\"", "\"Hod_approved\"", "\"Published\""];
        $new_content = str_replace($search, $replace, $content);
        if ($new_content !== $content) {
            file_put_contents($f, $new_content);
            echo "Updated $f\n";
        }
    }
}
?>
