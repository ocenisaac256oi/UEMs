<?php
$files = [
    'take_exam.php',
    'submit_exam.php',
    'student_dashboard.php',
    'api_save_answer.php',
    'student_results.php',
    'student_results_lecturer.php'
];

foreach ($files as $f) {
    if (file_exists($f)) {
        $content = file_get_contents($f);
        
        $search = [
            "'in_progress'", 
            "'completed'", 
            "'expired'",
            "\"in_progress\"",
            "\"completed\"",
            "\"expired\""
        ];
        $replace = [
            "'In_progress'", 
            "'Completed'", 
            "'Expired'",
            "\"In_progress\"",
            "\"Completed\"",
            "\"Expired\""
        ];
        
        $new_content = str_replace($search, $replace, $content);
        if ($new_content !== $content) {
            file_put_contents($f, $new_content);
            echo "Updated $f\n";
        }
    }
}
?>
