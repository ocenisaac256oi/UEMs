<?php
// grade_essays.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['lecturer']);
$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// If dealing with a specific student's submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'grade_submission' && $role !== 'admin') {
    $result_id = (int)$_POST['result_id'];
    $m = (int)$_POST['total_awarded_marks'];

    // Update total score and finalize grading status in exam_results
    mysqli_query($conn, "UPDATE exam_results SET total_score = $m, grading_status = 'graded' WHERE id = $result_id");

    set_flash_message('success', 'Final exam marks have been successfully awarded.');
    header("Location: grade_essays.php");
    exit();
}

// Fetch pending manual reviews
$query_where = "er.grading_status = 'pending_manual_review'";
if ($role === 'lecturer') {
    $query_where .= " AND ep.created_by = $user_id";
} elseif (in_array($role, ['hod', 'exam_master'])) {
    $dep_id = (int)($_SESSION['department_id'] ?? 0);
    $query_where .= " AND c.department_id = $dep_id";
}

$sql = "SELECT er.id as result_id, ep.id as paper_id, c.code as course_code, 
        u.first_name, u.last_name, u.registration_number,
        er.total_score, ep.total_marks
        FROM exam_results er
        JOIN exam_papers ep ON er.exam_paper_id = ep.id
        JOIN courses c ON ep.course_id = c.id
        JOIN users u ON er.student_id = u.id
        WHERE $query_where ORDER BY er.created_at ASC";

$pending_reviews = [];
$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $pending_reviews[] = $row;
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<div class="card border-0 shadow-sm rounded-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="px-4 py-3">Student</th>
                        <th class="py-3">Exam Paper</th>
                        <th class="py-3">Current Auto-Score</th>
                        <th class="px-4 py-3 text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($pending_reviews)): ?>
                        <tr>
                            <td colspan="4" class="text-center py-5 text-muted">No pending manual grading tasks!</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($pending_reviews as $pr): ?>
                            <tr>
                                <td class="px-4">
                                    <strong><?php echo htmlspecialchars($pr['first_name'] . ' ' . $pr['last_name']); ?></strong><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($pr['registration_number'] ?? 'No Reg Num'); ?></small>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($pr['course_code']); ?></strong><br>
                                    <small class="text-muted"></small>
                                </td>
                                <td><span class="badge bg-secondary"><?php echo $pr['total_score']; ?> / <?php echo $pr['total_marks']; ?> pts</span></td>
                                <td class="px-4 text-end">
                                    <?php if ($role === 'admin'): ?>
                                        <a href="grade_essays.php?review_id=<?php echo $pr['result_id']; ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i> View Paper</a>
                                    <?php else: ?>
                                        <a href="grade_essays.php?review_id=<?php echo $pr['result_id']; ?>" class="btn btn-sm btn-primary"><i class="bi bi-list-check"></i> Grade Answers</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
// Grading Interface
if (isset($_GET['review_id']) && (int)$_GET['review_id'] > 0):
    $rid = (int)$_GET['review_id'];

    // Fetch result details
    $r_q = mysqli_query($conn, "SELECT er.*, ep.paper_content, ep.total_marks, c.title as course_title, u.first_name, u.last_name, u.registration_number, er.student_id
                                FROM exam_results er
                                JOIN exam_papers ep ON er.exam_paper_id = ep.id
                                JOIN courses c ON ep.course_id = c.id
                                JOIN users u ON er.student_id = u.id
                                WHERE er.id = $rid LIMIT 1");
    if ($r_q && mysqli_num_rows($r_q) > 0):
        $r_data = mysqli_fetch_assoc($r_q);

        // Fetch unified essay answers from session
        $s_q = mysqli_query($conn, "SELECT session_answers FROM exam_sessions WHERE student_id = {$r_data['student_id']} AND exam_paper_id = {$r_data['exam_paper_id']} LIMIT 1");
        $s_data = mysqli_fetch_assoc($s_q);
        $student_answer = $s_data['session_answers'] ?? 'No answer submitted.';
?>
        <div class="mt-5">
            <h4 class="mb-3">Grading: <?php echo htmlspecialchars($r_data['first_name'] . ' ' . $r_data['last_name']); ?>'s Exam</h4>
            <form method="POST">
                <input type="hidden" name="action" value="grade_submission">
                <input type="hidden" name="result_id" value="<?php echo $rid; ?>">

                <div class="row">
                    <div class="col-lg-6">
                        <div class="card border-0 shadow-sm rounded-4 mb-4">
                            <div class="card-header bg-light"><strong>Examination Paper Reference</strong></div>
                            <div class="card-body bg-white text-start" style="font-family: 'Poppins', sans-serif; white-space: pre-wrap; max-height: 600px; overflow-y: auto;"><?php echo trim(htmlspecialchars($r_data['paper_content'])); ?></div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card border-0 shadow-sm rounded-4 mb-4 border-top border-primary border-4">
                            <div class="card-header bg-light"><strong>Student's Submitted Answer Booklet</strong></div>
                            <div class="card-body bg-light text-start" style="font-family: 'Poppins', sans-serif; white-space: pre-wrap; font-size: 1.05rem; line-height: 1.6; max-height: 500px; overflow-y: auto;"><?php echo trim(htmlspecialchars($student_answer)); ?></div>
                            <div class="card-footer bg-white border-0 pt-4 pb-3">
                                <div class="row align-items-center">
                                    <div class="col-md-7">
                                        <label class="form-label fw-bold text-primary fs-5 mb-0">Total Required Marks</label>
                                        <p class="text-muted small">Input the total final marks this student deserves for this entire paper.</p>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="input-group input-group-lg">
                                            <input type="number" name="total_awarded_marks" class="form-control text-center fw-bold text-primary" min="0" max="<?php echo $r_data['total_marks']; ?>" value="<?php echo $r_data['total_score']; ?>" required>
                                            <span class="input-group-text">/ <?php echo $r_data['total_marks']; ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="text-end mb-5">
                    <a href="grade_essays.php" class="btn btn-light btn-lg me-2">Cancel</a>
                    <?php if ($role !== 'admin'): ?>
                        <button type="submit" class="btn btn-primary btn-lg px-5 fw-bold"><i class="bi bi-check-all"></i> Finalize Grades</button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
<?php endif;
endif; ?>

<?php require_once 'includes/footer.php'; ?>