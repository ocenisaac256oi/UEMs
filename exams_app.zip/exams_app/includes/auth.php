<?php
// includes/auth.php
session_start();

/**
 * Check if the user is authenticated. 
 * If not, redirect to the login page.
 */
function require_login() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }
}

/**
 * Check if the currently authenticated user has the required role.
 * If not, they are redirected to a safe dashboard or shown an error.
 * 
 * @param string|array $allowed_roles A single role or array of roles
 */
function require_role($allowed_roles) {
    require_login();
    
    $user_role = $_SESSION['role'] ?? '';
    
    if (is_array($allowed_roles)) {
        if (!in_array($user_role, $allowed_roles)) {
            header("Location: index.php?error=unauthorized");
            exit();
        }
    } else {
        if ($user_role !== $allowed_roles) {
            header("Location: index.php?error=unauthorized");
            exit();
        }
    }
}

/**
 * Authenticate a user by verifying their password hash and setting session variables.
 */
function attempt_login($conn, $email, $password) {
    $email = mysqli_real_escape_string($conn, $email);
    
    $query = "SELECT id, email, password_hash, role, first_name, last_name, department_id, college_id, is_active FROM users WHERE email = '$email' AND deleted_at IS NULL LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);
        
        // Use password_verify since the seed passwords likely use bcrypt, 
        // Note: we should verify exactly how passwords were hashed in the original Node.js app 
        // (typically bcrypt, which is fully compatible with PHP's password_verify).
        if (password_verify($password, $user['password_hash'])) {
            if (!$user['is_active']) {
                return ['success' => false, 'error' => 'Account is inactive.'];
            }
            
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['first_name'] . ' ' . $user['last_name'];
            $_SESSION['department_id'] = $user['department_id'];
            $_SESSION['college_id'] = $user['college_id'];
            
            return ['success' => true];
        }
    }
    
    return ['success' => false, 'error' => 'Invalid email or password.'];
}

function logout() {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
