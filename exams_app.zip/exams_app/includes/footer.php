    <?php if (isset($_SESSION['user_id'])): ?>
            </div> <!-- End of content-body from header.php -->
        </div> <!-- End of main-content from header.php -->
    </div> <!-- End of main-wrapper from header.php -->
    <?php else: ?>
        </div> <!-- End of standard container from header.php for guest -->
    <?php endif; ?>

<!-- Bootstrap 5 JS Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Script for simple dropdown rotation -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const collapsibles = document.querySelectorAll('.collapse');
    collapsibles.forEach(col => {
        col.addEventListener('show.bs.collapse', function(e) {
            const toggle = document.querySelector(`[href="#${this.id}"] i.bi-chevron-down, [data-bs-target="#${this.id}"] i.bi-chevron-down`);
            if(toggle) toggle.style.transform = 'rotate(180deg)';
        });
        col.addEventListener('hide.bs.collapse', function(e) {
            const toggle = document.querySelector(`[href="#${this.id}"] i.bi-chevron-down, [data-bs-target="#${this.id}"] i.bi-chevron-down`);
            if(toggle) toggle.style.transform = 'rotate(0deg)';
        });
    });
});
</script>

</body>
</html>
