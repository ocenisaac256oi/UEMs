</div> <!-- End of container from header.php -->

    <!-- Bootstrap 5 JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Optional custom scripts could go here -->
    <footer class="bg-white py-4 mt-auto border-top">
        <div class="container text-center text-muted">
            <p class="mb-0">&copy; <?php echo date('Y'); ?> Kampala International University - UEMS. Built by Spider Tabs Ltd.</p>
        </div>
    </footer>
</body>
</html>
