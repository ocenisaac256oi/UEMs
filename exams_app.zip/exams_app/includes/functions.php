<?php
// includes/functions.php

/**
 * Sanitize user input to prevent XSS and SQL injection.
 * Note: For SQL injection, prepared statements are better, 
 * but this is a fallback for simple procedural string escaping.
 */
function sanitize_input($conn, $data) {
    if (is_array($data)) {
        foreach ($data as $key => $value) {
            $data[$key] = sanitize_input($conn, $value);
        }
        return $data;
    }
    
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($conn, $data);
}

/**
 * Handle flashing messages in the session
 */
function set_flash_message($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

function display_flash_message() {
    if (isset($_SESSION['flash'])) {
        $type = $_SESSION['flash']['type'];
        $message = $_SESSION['flash']['message'];
        
        echo "<div class='alert alert-{$type} alert-dismissible fade show' role='alert'>
                {$message}
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
              </div>";
              
        unset($_SESSION['flash']);
    }
}

/**
 * Fetch a single record from a table by ID
 */
function get_record_by_id($conn, $table, $id) {
    $table = mysqli_real_escape_string($conn, $table);
    $id = (int)$id;
    
    $query = "SELECT * FROM {$table} WHERE id = {$id} LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    }
    
    return null;
}

/**
 * Get color badges for different statuses
 */
function get_status_badge_class($status) {
    $classes = [
        'submitted' => 'bg-info text-dark',
        'hod_review' => 'bg-warning text-dark',
        'hod_approved' => 'bg-success',
        'dean_review' => 'bg-purple',
        'ready_for_print' => 'bg-primary',
        'printing' => 'bg-warning',
        'printed' => 'bg-success'
    ];
    return $classes[$status] ?? 'bg-secondary';
}
?>
