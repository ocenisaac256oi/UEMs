<?php
// includes/functions.php

/**
 * Sanitize user input to prevent XSS and SQL injection.
 * Note: For SQL injection, prepared statements are better, 
 * but this is a fallback for simple procedural string escaping.
 */
function sanitize_input($conn, $data) {
    if (is_array($data)) {
        foreach ($data as $key => $value) {
            $data[$key] = sanitize_input($conn, $value);
        }
        return $data;
    }
    
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($conn, $data);
}

/**
 * Handle flashing messages in the session
 */
function set_flash_message($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

function display_flash_message() {
    if (isset($_SESSION['flash'])) {
        $type = $_SESSION['flash']['type'];
        $message = $_SESSION['flash']['message'];
        
        echo "<div class='alert alert-{$type} alert-dismissible fade show' role='alert'>
                {$message}
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
              </div>";
              
        unset($_SESSION['flash']);
    }
}

/**
 * Fetch a single record from a table by ID
 */
function get_record_by_id($conn, $table, $id) {
    $table = mysqli_real_escape_string($conn, $table);
    $id = (int)$id;
    
    $query = "SELECT * FROM {$table} WHERE id = {$id} LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    }
    
    return null;
}

/**
 * Format user name with title based on role and gender
 */
function format_user_name($name, $role, $gender) {
    if (strtolower($role) === 'admin') {
        return 'Admin';
    } elseif (in_array(strtolower($role), ['hod'])) {
        return 'Dr. ' . $name;
    } elseif (in_array(strtolower($role), ['lecturer', 'exam_master'])) {
        if (strtolower($gender) === 'male') {
            return 'Mr. ' . $name;
        } elseif (strtolower($gender) === 'female') {
            return 'Mrs. ' . $name;
        }
    }
    return $name;
}

/**
 * Get color badges for different statuses
 */
function get_status_badge_class($status) {
    if (!$status) return 'bg-secondary';
    
    $classes = [
        'Draft' => 'bg-secondary',
        'Submitted' => 'bg-warning text-dark',
        'Hod_approved' => 'bg-primary',
        'Approved' => 'bg-primary',
        'Published' => 'bg-primary',
        'Ready_for_print' => 'bg-info text-dark',
        'Printing' => 'bg-warning text-dark',
        'Printed' => 'bg-primary'
    ];
    // Case-insensitive fallback
    $status_key = ucwords(strtolower(str_replace('_', ' ', $status)));
    $status_key = str_replace(' ', '_', $status_key);
    
    return $classes[$status] ?? $classes[$status_key] ?? 'bg-secondary';
}

/**
 * Format status text globally to Titlecase
 */
function format_status($status) {
    if (!$status) return 'N/A';
    return ucwords(strtolower(str_replace('_', ' ', $status)));
}
?>
