<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UEMS for PHD</title>

    <!-- Google Fonts: Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/images/logo.png">

    <!-- Custom CSS -->




    <style>
        :root {
            --bs-font-sans-serif: 'Poppins', sans-serif;
            --bs-body-font-family: 'Poppins', sans-serif;
            --bs-primary: #28a745;
            --bs-primary-rgb: 40, 167, 69;
        }

        body {
            font-family: 'Poppins', sans-serif !important;
        }

        .btn-primary,
        .btn-primary {
            --bs-btn-bg: #28a745;
            --bs-btn-border-color: #28a745;
            --bs-btn-hover-bg: #218838;
            --bs-btn-hover-border-color: #1e7e34;
            --bs-btn-active-bg: #1e7e34;
            --bs-btn-active-border-color: #1c7430;
        }

        .btn-outline-primary,
        .btn-outline-primary {
            --bs-btn-color: #28a745;
            --bs-btn-border-color: #28a745;
            --bs-btn-hover-bg: #28a745;
            --bs-btn-hover-border-color: #28a745;
        }

        .bg-primary,
        .bg-primary {
            background-color: #28a745 !important;
        }

        .text-primary,
        .text-primary {
            color: #28a745 !important;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #28a745;
            box-shadow: 0 0 0 0.25rem rgba(40, 167, 69, 0.25);
        }

        /* Sidebar Styles */
        .sidebar {
            height: 100vh;
            width: 280px;
            background: linear-gradient(180deg, #28a745 0%, #1e7e34 100%);
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
            z-index: 100;
            overflow-y: auto;
            flex-shrink: 0;
        }

        /* hide scrollbar for sleekness */
        .sidebar::-webkit-scrollbar {
            width: 5px;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.85);
            font-weight: 500;
            padding: 0.25rem 1rem;
            border-radius: 8px;
            margin-bottom: 0.1rem;
            transition: all 0.3s ease;
        }

        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: #fff;
            background-color: rgba(255, 255, 255, 0.15);
            transform: translateX(4px);
        }

        .sidebar .nav-link i {
            width: 24px;
            font-size: 1.1rem;
            margin-right: 8px;
            text-align: center;
            display: inline-block;
        }

        .sidebar .nav-item .collapse {
            background-color: rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 0.2rem;
            margin-bottom: 0.5rem;
        }

        .sidebar .nav-item .collapse .nav-link {
            padding-left: 3.5rem;
            font-size: 0.9rem;
            margin-bottom: 0;
            background: transparent !important;
        }

        .sidebar .nav-item .collapse .nav-link:hover {
            color: #fff;
            transform: translateX(4px);
        }

        .sidebar hr {
            border-color: rgba(255, 255, 255, 0.2);
            opacity: 1;
        }

        .main-wrapper {
            display: flex;
            height: 100vh;
            overflow: hidden;
            background-color: #f4f6f9;
        }

        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            min-width: 0;
            /* Prevents overflow issues */
            height: 100vh;
            background-color: #f4f6f9;
        }

        .top-header {
            flex-shrink: 0;
            z-index: 10;
        }

        .content-body {
            flex: 1;
            overflow-y: auto;
            position: relative;
        }

        /* Subtle animation for the brand logo */
        .brand-logo {
            transition: transform 0.3s ease;
        }

        .brand-logo:hover {
            transform: scale(1.05);
        }

        .sidebar .nav-link[data-bs-toggle="collapse"] i:last-child {
            transition: transform 0.3s ease;
            width: auto;
            margin-right: 0;
        }

        @media print {

            .sidebar,
            .top-header {
                display: none !important;
            }

            .main-wrapper,
            .main-content,
            .content-body {
                display: block !important;
                height: auto !important;
                overflow: visible !important;
            }

            body,
            .main-wrapper,
            .main-content,
            .content-body {
                background-color: #fff !important;
            }
        }
    </style>
</head>

<body class="bg-light">

    <?php if (isset($_SESSION['user_id'])): ?>
        <div class="main-wrapper">

            <!-- Sidebar -->
            <div class="sidebar d-flex flex-column flex-shrink-0 p-1 text-white">
                <a href="index.php" class="d-flex align-items-center justify-content-center mb-1 mb-md-0 w-100 text-white text-decoration-none px-2 brand-logo mt-1">
                    <span class="fs-4 fw-bold tracking-wide text-center">UEMs for PHD</span>
                </a>
                <hr>

                <!-- Profile Info Section -->
                <div class="text-center mb-3 position-relative">
                    <?php
                    $profile_user_id = $_SESSION['user_id'];
                    $profileUrl = 'assets/images/default-avatar.svg'; // Fallback
                    $has_custom = false;
                    $extensions = ['jpg', 'jpeg', 'png', 'gif'];
                    foreach ($extensions as $ext) {
                        if (file_exists("assets/images/profiles/{$profile_user_id}.$ext")) {
                            $profileUrl = "assets/images/profiles/{$profile_user_id}.$ext" . '?t=' . time();
                            $has_custom = true;
                            break;
                        }
                    }
                    ?>
                    <div class="position-relative d-inline-block mt-2">
                        <div style="cursor: pointer;" onclick="document.getElementById('profileUploadInput').click();">
                            <img src="<?php echo htmlspecialchars($profileUrl); ?>" alt="Profile Picture" class="rounded-circle border border-2 border-white shadow bg-white" style="width: 80px; height: 80px; object-fit: cover;" onerror="this.src='assets/images/default-avatar.svg';">
                            <div class="position-absolute bottom-0 end-0 bg-primary rounded-circle border border-white d-flex align-items-center justify-content-center shadow-sm" style="width: 25px; height: 25px; transform: translate(10%, 10%);" title="Change Profile Picture">
                                <i class="bi bi-camera-fill text-white" style="font-size: 11px;"></i>
                            </div>
                        </div>
                        <?php if ($has_custom): ?>
                            <div class="position-absolute top-0 end-0 bg-danger rounded-circle border border-white d-flex align-items-center justify-content-center shadow-sm" style="width: 22px; height: 22px; transform: translate(20%, -10%); cursor: pointer;" title="Delete Profile Picture" onclick="if(confirm('Delete your profile picture?')) document.getElementById('profileDeleteForm').submit();">
                                <i class="bi bi-x-lg text-white" style="font-size: 11px;"></i>
                            </div>
                        <?php endif; ?>
                    </div>

                    <form id="profileUploadForm" method="POST" action="upload_profile.php" enctype="multipart/form-data" class="d-none">
                        <input type="file" id="profileUploadInput" name="profile_picture" accept="image/*" onchange="document.getElementById('profileUploadForm').submit();">
                    </form>

                    <?php if ($has_custom): ?>
                        <form id="profileDeleteForm" method="POST" action="upload_profile.php" class="d-none">
                            <input type="hidden" name="action" value="delete">
                        </form>
                    <?php endif; ?>

                    <div class="mt-3 text-white text-center px-2">
                        <div class="fs-6 tracking-wide text-truncate fw-bold" style="max-width: 100%;">
                            <?php
                            $sidebar_name = $_SESSION['name'] ?? 'User';
                            $sidebar_role = $_SESSION['role'] ?? '';
                            $sidebar_gender = $_SESSION['gender'] ?? '';

                            if ($sidebar_role === 'admin') {
                                echo 'Admin';
                            } elseif (function_exists('format_user_name')) {
                                echo format_user_name(htmlspecialchars($sidebar_name), $sidebar_role, $sidebar_gender);
                            } else {
                                echo htmlspecialchars($sidebar_name);
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <!-- End Profile Info Section -->

                <hr>
                <ul class="nav nav-pills flex-column mb-auto">
                    <?php if ($_SESSION['role'] === 'student'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="student_dashboard.php"><i class="bi bi-controller"></i> Exams</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="question_bank.php"><i class="bi bi-journal-text"></i> Question Bank</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="student_results.php"><i class="bi bi-award"></i> Results</a>
                        </li>
                    <?php else: ?>
                        <!-- Academic Setup (Flat Links) -->
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="question_bank.php"><i class="bi bi-journal-text"></i> Question Bank</a>
                            </li>
                        <?php endif; ?>
                        <?php if ($_SESSION['role'] !== 'exam_master'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="exam_papers.php"><i class="bi bi-file-earmark-text"></i> Exam Papers</a>
                            </li>
                        <?php endif; ?>

                        <?php if (in_array($_SESSION['role'], ['hod', 'admin', 'exam_master'])): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="approvals.php"><i class="bi bi-check2-circle"></i> <?php echo ($_SESSION['role'] === 'admin') ? 'Approved Exams' : 'Approvals'; ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if ($_SESSION['role'] === 'hod'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="exam_master_approvals.php"><i class="bi bi-send-check"></i> Exam Master Approvals</a>
                            </li>
                        <?php endif; ?>

                        <?php if ($_SESSION['role'] === 'exam_master'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="published.php"><i class="bi bi-cloud-arrow-up"></i> Published</a>
                            </li>
                        <?php endif; ?>

                        <?php if ($_SESSION['role'] === 'lecturer'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="grade_essays.php"><i class="bi bi-pencil-square"></i> Mark Exams</a>
                            </li>
                        <?php endif; ?>

                        <?php if (in_array($_SESSION['role'], ['lecturer', 'hod'])): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="lecturer_students.php"><i class="bi bi-people"></i> Students</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="student_results_lecturer.php"><i class="bi bi-award"></i> Student Results</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="malpractice_list.php"><i class="bi bi-exclamation-octagon"></i> Malpractice Form</a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>



                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <!-- Administration (Flat Links) -->
                        <li class="nav-item">
                            <a class="nav-link" href="users.php"><i class="bi bi-person-gear"></i> Users</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="colleges.php"><i class="bi bi-building"></i> Colleges</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="departments.php"><i class="bi bi-diagram-3"></i> Departments</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="reports.php"><i class="bi bi-bar-chart-line"></i> Reports</a>
                        </li>
                    <?php endif; ?>
                </ul>

                <hr>
                <div class="mt-auto px-2 pb-2">
                    <a href="logout.php" class="btn btn-outline-light w-100 d-flex align-items-center justify-content-center py-2" style="border-radius: 8px;">
                        <i class="bi bi-box-arrow-right me-2"></i> Log Out
                    </a>
                </div>
            </div>


            <!-- Main Content Area -->
            <div class="main-content">
                <!-- Top header bar -->
                <header class="top-header bg-white shadow-sm py-3 px-4 d-flex justify-content-center align-items-center">
                    <h5 class="mb-0 text-primary fw-bold text-center tracking-wide">
                        <?php
                        $role_title_map = [
                            'admin' => 'Admin Portal',
                            'student' => 'Student Portal',
                            'lecturer' => 'Lecturer\'s Portal',
                            'hod' => 'HOD Portal',
                            'exam_master' => 'Examiner Portal'
                        ];
                        $current_role = $_SESSION['role'] ?? 'guest';
                        echo $role_title_map[$current_role] ?? 'UEMS Portal';
                        ?>
                    </h5>
                </header>

                <div class="content-body px-4 pb-5 pt-4">
                    <?php
                    // If functions.php is included before header.php, this will show flash messages
                    if (function_exists('display_flash_message')) {
                        display_flash_message();
                    }
                    ?>
                <?php else: ?>
                    <!-- Guest users don't get the dashboard layout -->
                    <div class="container-fluid min-vh-100 bg-light p-0 m-0 overflow-hidden">
                        <?php
                        if (function_exists('display_flash_message')) {
                            display_flash_message();
                        }
                        ?>
                    <?php endif; ?>