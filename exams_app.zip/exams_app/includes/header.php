<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UEMS - University Exam Management System</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <!-- Custom CSS (optional, we will create this if needed) -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">

<?php if (isset($_SESSION['user_id'])): ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-mortarboard-fill"></i> UEMS
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain" aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <?php if ($_SESSION['role'] === 'student'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="student_dashboard.php"><i class="bi bi-controller"></i> My Exams</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="past_papers.php"><i class="bi bi-journal-text"></i> Past Papers</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="student_results.php"><i class="bi bi-award"></i> Results</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Dashboard</a>
                        </li>
                        <!-- Academic Setup -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"><i class="bi bi-building"></i> Setup</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="question_bank.php">Question Bank</a></li>
                                <li><a class="dropdown-item" href="exam_papers.php">Exam Papers</a></li>
                            </ul>
                        </li>
                        <?php if (in_array($_SESSION['role'], ['hod', 'dean', 'admin'])): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="approvals.php"><i class="bi bi-check2-circle"></i> Approvals</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="schedule_exams.php"><i class="bi bi-calendar-event"></i> Schedule Exams</a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if (in_array($_SESSION['role'], ['lecturer', 'hod', 'dean', 'admin'])): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="grade_essays.php"><i class="bi bi-pencil-square"></i> Manual Grading</a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="bi bi-gear"></i> Administration
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="adminDropdown">
                                    <li><a class="dropdown-item" href="users.php">Users</a></li>
                                    <li><a class="dropdown-item" href="colleges.php">Colleges & Depts</a></li>
                                    <li><a class="dropdown-item" href="admin_results.php">All Student Results</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="reports.php">Reports</a></li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
                
                <div class="d-flex text-white align-items-center">
                    <span class="me-3">
                        <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['name']); ?> 
                        <small class="badge bg-light text-primary ms-1"><?php echo strtoupper(str_replace('_', ' ', $_SESSION['role'])); ?></small>
                    </span>
                    <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </div>
    </nav>
<?php endif; ?>

<div class="container pb-5">
    <?php 
    // If functions.php is included before header.php, this will show flash messages
    if (function_exists('display_flash_message')) {
        display_flash_message();
    }
    ?>
