<?php
// index.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Protect this route
require_login();

// Fetch basic stats
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

if ($role === 'student') {
    header("Location: student_dashboard.php");
    exit();
}

// Prepare stats based on role
$stats = [
    'my_papers' => 0,
    'pending_exams' => 0,
    'pending_approvals' => 0,
    'total_users' => 0
];

if ($role === 'lecturer') {
    $q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM exam_papers WHERE created_by = $user_id AND status IN ('Submitted', 'Hod_approved', 'Approved') AND deleted_at IS NULL");
    if ($q) $stats['pending_exams'] = mysqli_fetch_assoc($q)['cnt'];
} elseif ($role === 'hod') {
    $q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM exam_papers WHERE created_by = $user_id AND deleted_at IS NULL");
    if ($q) $stats['my_papers'] = mysqli_fetch_assoc($q)['cnt'];
}

if ($role === 'hod') {
    $dep_id = (int)($_SESSION['department_id'] ?? 0);
    // Papers waiting for HOD to approve
    $q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM exam_papers ep JOIN courses c ON ep.course_id = c.id WHERE ep.status = 'Submitted' AND ep.deleted_at IS NULL AND c.department_id = $dep_id");
    if ($q) $stats['pending_approvals'] = mysqli_fetch_assoc($q)['cnt'];
} elseif ($role === 'admin') {
    $q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM exam_papers ep JOIN courses c ON ep.course_id = c.id WHERE ep.status IN ('Approved', 'Hod_approved') AND ep.deleted_at IS NULL");
    if ($q) $stats['pending_approvals'] = mysqli_fetch_assoc($q)['cnt'];
}



if ($role === 'admin') {
    $q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM users WHERE deleted_at IS NULL");
    if ($q) $stats['total_users'] = mysqli_fetch_assoc($q)['cnt'];
}

// Fetch 5 recent papers - Published only
$recent_papers = [];
$rp_where = "p.deleted_at IS NULL AND p.status = 'Published' AND p.academic_year = '2026'";
if ($role === 'lecturer') {
    $rp_where .= " AND p.created_by = $user_id";
} elseif (in_array($role, ['hod', 'exam_master'])) {
    $dep_id = (int)($_SESSION['department_id'] ?? 0);
    $rp_where .= " AND c.department_id = $dep_id";
}

$rp_query = "SELECT p.*, c.code as course_code, c.title as course_title FROM exam_papers p JOIN courses c ON p.course_id = c.id WHERE $rp_where ORDER BY p.created_at DESC LIMIT 5";
$rp_res = mysqli_query($conn, $rp_query);
if ($rp_res) {
    while ($row = mysqli_fetch_assoc($rp_res)) {
        $recent_papers[] = $row;
    }
}
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4 g-4">
    <?php if ($role === 'lecturer'): ?>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body d-flex flex-column justify-content-center align-items-center text-center p-4">
                    <div class="display-4 text-warning mb-2"><i class="bi bi-hourglass-split"></i></div>
                    <h3 class="fs-1 fw-bold"><?php echo $stats['pending_exams']; ?></h3>
                    <p class="text-muted mb-0">Pending Exams</p>
                </div>
            </div>
        </div>
    <?php elseif ($role === 'hod'): ?>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body d-flex flex-column justify-content-center align-items-center text-center p-4">
                    <div class="display-4 text-primary mb-2"><i class="bi bi-file-earmark-text"></i></div>
                    <h3 class="fs-1 fw-bold"><?php echo $stats['my_papers']; ?></h3>
                    <p class="text-muted mb-0">Exam Papers</p>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($role === 'hod'): ?>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body d-flex flex-column justify-content-center align-items-center text-center p-4">
                    <div class="display-4 text-warning mb-2"><i class="bi bi-clock-history"></i></div>
                    <h3 class="fs-1 fw-bold"><?php echo $stats['pending_approvals']; ?></h3>
                    <p class="text-muted mb-0">Required Approvals</p>
                </div>
            </div>
        </div>
    <?php endif; ?>



    <?php if ($role === 'admin'): ?>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body d-flex flex-column justify-content-center align-items-center text-center p-4">
                    <div class="display-4 text-primary mb-2"><i class="bi bi-people"></i></div>
                    <h3 class="fs-1 fw-bold"><?php echo $stats['total_users']; ?></h3>
                    <p class="text-muted mb-0">Total Users</p>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-header bg-white border-bottom-0 pt-4 pb-2 px-4 d-flex justify-content-between align-items-center">
                <h5 class="mb-0 fw-bold">Recent Exam Papers</h5>
                <a href="<?php echo $role === 'exam_master' ? 'published.php' : 'exam_papers.php'; ?>" class="btn btn-sm btn-outline-primary rounded-pill">View All</a>
            </div>
            <div class="card-body px-4">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Paper Code</th>
                                <th>Course Unit</th>
                                <th>Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_papers)): ?>
                                <tr>
                                    <td colspan="3" class="text-center py-4">No published papers found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recent_papers as $paper): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($paper['course_code']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($paper['course_title']); ?></td>
                                        <td><?php echo htmlspecialchars($paper['exam_type'] ?? 'N/A'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-white border-bottom-0 pt-4 pb-2 px-4">
                <h5 class="mb-0 fw-bold">Quick Actions</h5>
            </div>
            <div class="card-body px-4 pb-4">
                <div class="d-grid gap-3">
                    <?php if ($role === 'lecturer'): ?>
                        <a href="create_paper.php" class="btn btn-primary btn-lg rounded-3 d-flex align-items-center justify-content-between text-start p-3">
                            <div>
                                <div class="fw-bold fs-5">Create Paper</div>
                                <div class="small text-white-50">Draft a new exam paper</div>
                            </div>
                            <i class="bi bi-plus-circle fs-3"></i>
                        </a>
                    <?php endif; ?>

                    <?php if (in_array($role, ['lecturer', 'hod', 'admin'])): ?>
                        <a href="question_bank.php" class="btn btn-light border btn-lg rounded-3 d-flex align-items-center justify-content-between text-start p-3">
                            <div>
                                <div class="fw-bold fs-5 text-dark">Question Bank</div>
                                <div class="small text-muted">View Papers in the Question Bank</div>
                            </div>
                            <i class="bi bi-journal-text fs-3 text-secondary"></i>
                        </a>
                    <?php endif; ?>

                    <?php if (in_array($role, ['exam_master', 'admin'])): ?>
                        <a href="published.php" class="btn btn-info text-white btn-lg rounded-3 d-flex align-items-center justify-content-between text-start p-3">
                            <div>
                                <div class="fw-bold fs-5">Published</div>
                                <div class="small text-white-50">Manage published exams</div>
                            </div>
                            <i class="bi bi-cloud-arrow-up fs-3"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>

