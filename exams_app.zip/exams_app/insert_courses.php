<?php
// insert_courses.php
require_once 'config/database.php';

$it_courses = [
    1 => [ // Year 1
        1 => [ // Semester 1
            "Introduction to Computer Fundamentals",
            "Introduction to Information Technology",
            "Fundamentals of Information Technology",
            "English Language Skills",
            "Practices and Practices of Management",
            "Mathematical Techniques for IT"
        ],
        2 => [ // Semester 2
            "Communication Skills",
            "Fundamentals of Networking",
            "Introduction to Probability and Statistics",
            "Web Design and Development",
            "Fundamentals of Programming",
            "Electronic Commerce"
        ]
    ],
    2 => [ // Year 2
        1 => [ // Semester 1
            "Database Design, Planning and Management",
            "Object Oriented Programming",
            "System Analysis and Design",
            "Electronic Services",
            "Research Methods",
            "Computer Hardware"
        ],
        2 => [ // Semester 2
            "Operating Systems",
            "Computer Networks and Data-communications",
            "Systems Dynamics and Simulation",
            "Graphics and Multimedia Applications",
            "Software Engineering",
            "Emerging Trends in Information Systems/technology"
        ]
    ],
    3 => [ // Year 3
        1 => [ // Semester 1
            "IT Audit",
            "IT Project Management",
            "Network Administration and Configuration",
            "Enterprise Data Management",
            "Web Design, Programming, and Administration",
            "Information and Network Security"
        ],
        2 => [ // Semester 2
            "Computer and Cyber Forensics",
            "Mobile Application Development",
            "Database Management Systems",
            "Social Issues in Computing",
            "Cloud Computing Principles",
            "Final Project"
        ]
    ]
];

$cs_courses = [
    1 => [ // Year 1
        1 => [ // Semester 1
            "Computer Architecture and Organization",
            "Introduction to Mathematical Analysis",
            "Digital Logic",
            "Computer Fundamentals",
            "English Language Skills",
            "Principles and Practice of Management"
        ],
        2 => [ // Semester 2
            "Computer Hardware",
            "Numerical Analysis",
            "Linear Programming",
            "Structured Programming",
            "Internet Technologies and Webpage Authoring",
            "Communication Skills"
        ]
    ],
    2 => [ // Year 2
        1 => [ // Semester 1
            "Object Oriented Programming",
            "Principles of Electronics",
            "Systems Analysis and Design",
            "Computer Networks and Data Communications",
            "Research Methods",
            "Introduction to Probability and Statistics"
        ],
        2 => [ // Semester 2
            "Application Development",
            "Data Structures and Algorithms",
            "Software Engineering",
            "Operating Systems",
            "Web-based Database Systems",
            "Social and Professional Issues in Computing"
        ]
    ],
    3 => [ // Year 3
        1 => [ // Semester 1
            "Simulation and Modeling",
            "Emerging Trends in Computer Science",
            "Database Management Systems",
            "IT Project Management",
            "Network Administration & Configuration",
            "Application Development By Java"
        ],
        2 => [ // Semester 2
            "Communication Systems",
            "Research Report",
            "Algorithm Analysis and Design",
            "Artificial Intelligence",
            "Mobile Application Development",
            "Network and Information Security",
            "Computer Graphics"
        ]
    ]
];

$it_dept_id = 2;
$cs_dept_id = 1;
$college_id = 1;

function insertCourses($conn, $courses, $dept_id, $prefix, $college_id) {
    $inserted = 0;
    foreach ($courses as $year => $semesters) {
        foreach ($semesters as $semester => $titles) {
            $seq = 1;
            foreach ($titles as $title) {
                $code = sprintf("%s%d%d%02d", $prefix, $year, $semester, $seq);
                $title_esc = mysqli_real_escape_string($conn, $title);
                
                // Check if already exists
                $check = mysqli_query($conn, "SELECT id FROM courses WHERE title = '$title_esc' AND department_id = $dept_id");
                if (mysqli_num_rows($check) == 0) {
                    $sql = "INSERT INTO courses (code, title, level, semester, department_id, college_id, created_at) 
                            VALUES ('$code', '$title_esc', $year, $semester, $dept_id, $college_id, NOW())";
                    if (mysqli_query($conn, $sql)) {
                        $inserted++;
                    } else {
                        echo "Error inserting $title: " . mysqli_error($conn) . "\n";
                    }
                }
                $seq++;
            }
        }
    }
    return $inserted;
}

echo "Starting course insertion...\n";

$it_count = insertCourses($conn, $it_courses, $it_dept_id, "BIT", $college_id);
echo "Inserted $it_count Information Technology courses.\n";

$cs_count = insertCourses($conn, $cs_courses, $cs_dept_id, "BCS", $college_id);
echo "Inserted $cs_count Computer Science courses.\n";

echo "Done.\n";
?>
