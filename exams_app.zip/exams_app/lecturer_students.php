<?php
# lecturer_students.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['lecturer', 'hod', 'admin']);
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

# If lecturer or hod, show students in their department
$dep_id = (int)($_SESSION['department_id'] ?? 0);
$where_clause = "u.role = 'student'";

if (in_array($role, ['lecturer', 'hod'])) {
    $where_clause .= " AND u.department_id = $dep_id";
}

$sql = "SELECT u.id, u.first_name, u.last_name, u.email as student_email, u.registration_number, u.role as student_role, u.gender as student_gender
        FROM users u
        WHERE $where_clause
        ORDER BY u.first_name ASC";

$results = [];
$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $results[] = $row;
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<div class="card border-0 shadow-sm rounded-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="px-4 py-3">Student Name</th>
                        <th class="py-3">Email Address</th>
                        <th class="py-3">Registration Number</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($results)): ?>
                        <tr>
                            <td colspan="3" class="text-center py-5 text-muted">No students found associated with your examinations yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($results as $r): ?>
                            <tr>
                                <td class="px-4">
                                    <strong><?php echo htmlspecialchars($r['first_name'] . ' ' . $r['last_name']); ?></strong>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($r['student_email']); ?>
                                </td>
                                <td>
                                    <?php if (!empty($r['registration_number'])): ?>
                                        <span class="text-secondary fw-bold text-uppercase"><?php echo htmlspecialchars($r['registration_number']); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted fst-italic">N/A</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>