<?php
// login.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// If already logged in, redirect to index
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    // Use default password if none provided, or what they entered
    $password = $_POST['password'] ?? 'uems@123';

    if (empty($email)) {
        $error = 'Email is required.';
    } else {
        $result = attempt_login($conn, $email, $password);
        if ($result['success']) {
            header("Location: index.php");
            exit();
        } else {
            $error = $result['error'];
        }
    }
}
?>
<?php require_once 'includes/header.php'; ?>

<div class="row justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="col-11 col-sm-8 col-md-5 col-lg-3">
        <div class="card shadow border-0 rounded-4">
            <div class="card-header bg-primary text-white text-center py-3 rounded-top-4">
                <h4 class="font-weight-light my-1 mb-0">UEMs for PHD</h4>
            </div>
            <div class="card-body p-4">
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <form method="POST" action="login.php">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold mb-1">Email Address</label>
                        <input class="form-control form-control-sm" type="email" name="email" placeholder="email@uems.ac.ug" required autofocus />
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold mb-1">Password</label>
                        <input class="form-control form-control-sm" type="password" name="password" placeholder="******" value="uems@123" required />
                    </div>

                    <div class="d-grid gap-2 mt-4">
                        <button type="submit" class="btn btn-primary">Login</button>
                    </div>
                </form>
            </div>
            <div class="card-footer text-center py-3 border-0 bg-light rounded-bottom-4">
                <div class="small"><a href="register.php" class="text-decoration-none fw-bold text-primary">No Account??? Create One</a></div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>