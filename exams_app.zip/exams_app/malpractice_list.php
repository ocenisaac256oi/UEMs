<?php
// malpractice_list.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['hod', 'lecturer']);
$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];
$dept_filter = $_SESSION['department_id'] ?? 0;

// Fetch Malpractice Reports based on role
$where_clause = "m.department_id = $dept_filter";
if ($role === 'lecturer') {
    // Lecturer sees reports for papers they created AND ONLY for students in their department
    $where_clause .= " AND ep.created_by = $user_id";
}

$sql = "SELECT m.*, u.first_name, u.last_name, u.registration_number, ep.exam_type, c.code as course_code, d.name as dept_name
        FROM malpractice_reports m
        JOIN users u ON m.student_id = u.id
        JOIN exam_papers ep ON m.exam_paper_id = ep.id
        JOIN courses c ON ep.course_id = c.id
        JOIN departments d ON m.department_id = d.id
        WHERE $where_clause
        ORDER BY m.created_at DESC";

$reports = [];
$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $reports[] = $row;
    }
}

require_once 'includes/header.php';
?>

<style>
    .a4-container {
        width: 210mm;
        min-height: 297mm;
        padding: 15mm 20mm;
        margin: 20px auto;
        background: white;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        position: relative;
        font-size: 13px;
    }

    .form-header {
        text-align: center;
        margin-bottom: 30px;
        border-bottom: 2px solid #333;
        padding-bottom: 15px;
    }

    .university-logo {
        width: 100px;
        height: auto;
        margin-bottom: 10px;
    }

    .university-name {
        font-size: 20px;
        font-weight: 800;
        margin: 0;
        color: #000;
        text-transform: uppercase;
    }

    .form-title {
        font-size: 16px;
        font-weight: 700;
        margin-top: 5px;
        color: #000;
        /* Removed underline as requested */
    }

    .malpractice-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        font-size: 12px;
    }

    .malpractice-table th,
    .malpractice-table td {
        border: 1px solid #000;
        padding: 8px 10px;
        text-align: left;
    }

    .malpractice-table th {
        background-color: #f2f2f2;
        font-weight: 700;
        font-size: 13px;
    }

    .btn-custom {
        border-radius: 5px !important;
        padding: 8px 20px;
        font-weight: bold;
    }

    .controls-wrapper {
        text-align: center;
        margin-bottom: 20px;
        display: flex;
        justify-content: center;
        gap: 15px;
    }

    @media print {
        .a4-container {
            width: 100%;
            margin: 0;
            padding: 0;
            box-shadow: none;
            border: none;
        }

        .no-print {
            display: none !important;
        }

        body {
            background: white !important;
        }
    }
</style>

<div class="controls-wrapper no-print">
    <a href="javascript:history.back()" class="btn btn-light border btn-custom">
        <i class="bi bi-arrow-left me-2"></i> Back
    </a>
    <button onclick="downloadPDF()" class="btn btn-primary btn-custom">
        <i class="bi bi-download me-2"></i> Download Form
    </button>
</div>

<div id="malpracticeFormContent">
    <div class="a4-container">
        <div class="form-header">
            <img src="assets/images/logo.png" alt="KIU Logo" class="university-logo">
            <h1 class="university-name">KAMPALA INTERNATIONAL UNIVERSITY</h1>
            <h2 class="form-title">Malpractice Form</h2>
        </div>

        <div class="mb-3">
            <div class="row">
                <div class="col-12">
                    <p class="mb-1"><strong>Department:</strong>
                        <?php
                        if (!empty($reports)) {
                            echo htmlspecialchars($reports[0]['dept_name']);
                        } else {
                            $d_q = mysqli_query($conn, "SELECT name FROM departments WHERE id = $dept_filter");
                            $d_res = mysqli_fetch_assoc($d_q);
                            echo htmlspecialchars($d_res['name'] ?? 'General');
                        }
                        ?>
                    </p>
                </div>
            </div>
        </div>

        <table class="malpractice-table">
            <thead>
                <tr>
                    <th style="width: 50%;"><strong>Name</strong></th>
                    <th style="width: 50%;"><strong>Registration Number</strong></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($reports)): ?>
                    <tr>
                        <td colspan="2" class="text-center py-4 text-muted fst-italic">No malpractice records found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($reports as $r): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($r['first_name'] . ' ' . $r['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($r['registration_number']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="mt-5">
            <div class="row">
                <div class="col-6">
                    <div class="border-top border-dark pt-2 mt-4" style="width: 150px;">
                        <p class="small fw-bold">HOD Signature</p>
                    </div>
                </div>
                <div class="col-6">
                    <div class="border-top border-dark pt-2 mt-4 ms-auto" style="width: 150px;">
                        <p class="small fw-bold text-end">Lecturer's Signature</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
    function downloadPDF() {
        // We target the a4-container directly for better PDF formatting
        const element = document.querySelector('.a4-container');
        const opt = {
            margin: 0,
            filename: 'Malpractice_Form_<?php echo date('Ymd'); ?>.pdf',
            image: {
                type: 'jpeg',
                quality: 0.98
            },
            html2canvas: {
                scale: 2,
                useCORS: true
            },
            jsPDF: {
                unit: 'mm',
                format: 'a4',
                orientation: 'portrait'
            }
        };
        html2pdf().set(opt).from(element).save();
    }
</script>

<?php require_once 'includes/footer.php'; ?>