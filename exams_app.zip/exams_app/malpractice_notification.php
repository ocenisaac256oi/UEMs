<?php
// malpractice_notification.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['student']);

require_once 'includes/header.php';
?>

<div class="container d-flex align-items-center justify-content-center" style="min-height: 80vh;">
    <div class="row w-100 justify-content-center">
        <div class="col-md-4"> <!-- Reduced width of the box -->
            <!-- Alert Box -->
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden text-center">
                <div class="card-body p-4"> <!-- Reduced padding -->
                    <!-- Logo -->
                    <img src="assets/images/logo.png" alt="KIU Logo" class="mb-3" style="width: 70px; height: auto;"> <!-- Reduced logo size -->
                    
                    <!-- Alert Status -->
                    <div class="text-danger mb-3">
                        <i class="bi bi-exclamation-octagon-fill" style="font-size: 2rem;"></i> <!-- Reduced icon size -->
                        <h4 class="fw-bold mt-2" style="font-size: 1.1rem;">Malpractice Detected</h4> <!-- Title case & reduced font -->
                    </div>

                    <!-- Description & Consequences -->
                    <div class="mb-4" style="font-size: 0.9rem;">
                        <p class="text-dark mb-3"> <!-- Removed bold from description -->
                            The system detected that you attempted to switch tabs, minimize the browser, or lose focus on the examination window.
                        </p>
                        <p class="text-danger fw-bold">
                            You are pending Disciplinary Charges.
                        </p>
                    </div>

                    <!-- Action Button -->
                    <div class="d-grid">
                        <a href="student_dashboard.php" class="btn fw-bold text-white" style="border-radius: 5px; background-color: #28a745; border: none; padding: 10px;"> <!-- Green button resembling logo -->
                            Return to Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    body {
        background-color: #fceaea !important;
    }
    /* Disable all navigation UI */
    .top-header, .sidebar, footer {
        display: none !important;
    }
    .main-content {
        margin-left: 0 !important;
        padding: 0 !important;
        background: transparent !important;
    }
    .content-body {
        padding-top: 0 !important;
    }
</style>

<?php require_once 'includes/footer.php'; ?>
