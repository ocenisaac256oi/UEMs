<?php
// paper_questions.php (Now acting as edit_paper.php)
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['admin', 'hod', 'lecturer']);
$user_id = $_SESSION['user_id'];
$paper_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($paper_id === 0) {
    header("Location: exam_papers.php");
    exit();
}

// Fetch Paper
$p_q = mysqli_query($conn, "SELECT p.*, c.code as course_code, c.title as course_title FROM exam_papers p JOIN courses c ON p.course_id = c.id WHERE p.id = $paper_id");
if (!$p_q || mysqli_num_rows($p_q) === 0) {
    header("Location: exam_papers.php");
    exit();
}
$paper = mysqli_fetch_assoc($p_q);

// Only draft status allowed to be edited usually, and only by author
if ($paper['status'] !== 'Draft') {
    set_flash_message('warning', 'Only draft papers can be modified.');
    header("Location: view_paper.php?id=" . $paper_id);
    exit();
}

// Handle Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $instructions = sanitize_input($conn, $_POST['instructions'] ?? '');
    $paper_content = sanitize_input($conn, $_POST['paper_content'] ?? '');
    $total_marks = (int)$_POST['total_marks'];
    $duration = (int)$_POST['duration'];

    $sql = "UPDATE exam_papers SET instructions = '$instructions', paper_content = '$paper_content', total_marks = $total_marks, duration = $duration WHERE id = $paper_id";
    if (mysqli_query($conn, $sql)) {
        set_flash_message('success', 'Examination paper updated successfully!');
        header("Location: view_paper.php?id=" . $paper_id);
        exit();
    } else {
        set_flash_message('danger', 'Error updating paper: ' . mysqli_error($conn));
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<div class="row text-center mb-4">
    <div class="col-12">
        <h2 class="mb-1"><i class="bi bi-pencil-square"></i> Edit Examination Paper</h2>
        <p class="text-muted mb-0">Updating (<?php echo htmlspecialchars($paper['course_code']); ?>)</p>
        <div class="mt-2">
            <a href="view_paper.php?id=<?php echo $paper_id; ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Cancel Edit</a>
        </div>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-lg-10 col-xl-8">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Duration (Mins) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="duration" value="<?php echo $paper['duration']; ?>" min="30" max="360" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Total Marks <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="total_marks" value="<?php echo $paper['total_marks']; ?>" min="1" max="100" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold">Candidate Instructions (Optional)</label>
                        <textarea class="form-control" name="instructions" rows="3" placeholder="Enter specific instructions for students..."><?php echo htmlspecialchars($paper['instructions']); ?></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold text-primary">Examination Paper Content <span class="text-danger">*</span></label>
                        <div class="alert alert-info py-2 small mb-2"><i class="bi bi-info-circle"></i> Type or paste your full examination questions here. This will be printed exactly as shown.</div>
                        <textarea class="form-control font-monospace" name="paper_content" rows="15" placeholder="Q1. Explain the concepts of..." required style="resize: vertical;"><?php echo htmlspecialchars($paper['paper_content']); ?></textarea>
                    </div>

                    <hr class="my-4">

                    <div class="text-center">
                        <button type="submit" class="btn btn-primary px-5 py-2 fw-bold shadow-sm"><i class="bi bi-save"></i> Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
