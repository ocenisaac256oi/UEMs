<?php
header("Location: question_bank.php");
exit();
?>