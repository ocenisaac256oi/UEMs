<?php
// published.php - Published Exams with Unpublish Button
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['exam_master', 'admin']);
$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Handle Unpublish
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'unpublish_exam') {
    $paper_id = (int)$_POST['paper_id'];
    if ($paper_id > 0) {
        mysqli_query($conn, "UPDATE exam_papers SET status = 'Ready_for_print', published_at = NULL WHERE id = $paper_id");
        set_flash_message('info', 'Exam unpublished and returned to scheduling queue.');
    }
    header("Location: published.php");
    exit();
}

$query_where = "ep.deleted_at IS NULL AND ep.status = 'Published' AND ep.academic_year = '2026'";
if ($role === 'exam_master') {
    $dep_id = (int)($_SESSION['department_id'] ?? 0);
    $query_where .= " AND c.department_id = $dep_id";
}

$sql = "SELECT ep.*, c.code as course_code, c.title as course_title, CONCAT(u.first_name, ' ', u.last_name) as creator_name FROM exam_papers ep JOIN courses c ON ep.course_id = c.id LEFT JOIN users u ON ep.created_by = u.id WHERE $query_where ORDER BY ep.created_at DESC";

$papers = [];
$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $papers[] = $row;
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-12 text-center">
        <h2><i class="bi bi-cloud-arrow-up"></i> Published Exams</h2>
        <p class="text-muted mb-0">Live exams for students.</p>
    </div>
</div>

<div class="row g-4">
    <?php if (empty($papers)): ?>
        <div class="col-12 text-center py-5">
            <h4 class="text-muted"><i class="bi bi-folder-x"></i> No published exams found.</h4>
        </div>
    <?php else: ?>
        <?php foreach ($papers as $p): ?>
            <div class="col-md-6 col-lg-3">
                <div class="card border-0 shadow-sm rounded-4 h-100 hover-shadow transition-all border-primary">
                    <div class="card-body p-4 text-center">
                        <div class="display-6 text-primary mb-3"><i class="bi bi-file-earmark-text"></i></div>
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($p['course_code']); ?></h5>
                        <p class="text-muted small mb-3"><?php echo htmlspecialchars($p['course_title']); ?></p>
                        <p class="text-secondary small mb-2">
                            <i class="bi bi-calendar3"></i> <?php echo date('M j, Y', strtotime($p['published_at'] ?? $p['created_at'])); ?>
                        </p>
                        <p class="text-secondary small mb-3"><i class="bi bi-person"></i> <?php echo htmlspecialchars($p['creator_name']); ?></p>
                        <div class="mb-3">
                            <span class="badge bg-primary rounded-pill px-3 py-2">Published</span>
                        </div>
                        <div class="d-flex justify-content-center gap-2 flex-wrap">
                            <a href="view_paper.php?id=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-primary" target="_blank">
                                <i class="bi bi-eye"></i> View
                            </a>
                            <?php if ($role !== 'admin'): ?>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Unpublish? Students lose access!');">
                                    <input type="hidden" name="paper_id" value="<?php echo $p['id']; ?>">
                                    <input type="hidden" name="action" value="unpublish_exam">
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="bi bi-x-circle"></i> Unpublish
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<style>
.hover-shadow:hover { transform: translateY(-5px); box-shadow: 0 .5rem 1rem rgba(0,0,0,.15)!important; }
.transition-all { transition: all .3s ease; }
</style>

<?php require_once 'includes/footer.php'; ?>

