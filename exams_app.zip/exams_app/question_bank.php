<?php
// question_bank.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Restricted access: Only Admins and Students
require_role(['admin', 'student']);

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];
$user_dept_id = (int)($_SESSION['department_id'] ?? 0);

// Professional Filtering logic
$dept_filter = isset($_GET['department_id']) ? (int)$_GET['department_id'] : 0;
$year_filter = isset($_GET['year_of_study']) ? (int)$_GET['year_of_study'] : 0;
$semester_filter = isset($_GET['semester']) ? (int)$_GET['semester'] : 0;
$ay_filter = isset($_GET['academic_year']) ? mysqli_real_escape_string($conn, $_GET['academic_year']) : '';

// Base query for published papers
$query_where = "ep.deleted_at IS NULL AND ep.status = 'Published'";

// Roles can only see their department's papers
if ($role === 'student') {
    // Student can ALWAYS see legacy past papers (2023-2025) for their department
    // But can ONLY see 2026+ papers after finishing and submitting them
    $query_where .= " AND c.department_id = $user_dept_id AND (
        (ep.academic_year IN ('2023', '2024', '2025')) OR 
        (ep.academic_year >= '2026' AND EXISTS (SELECT 1 FROM exam_sessions es WHERE es.exam_paper_id = ep.id AND es.student_id = $user_id AND es.status = 'Completed'))
    )";
} elseif ($role !== 'admin') {
    $query_where .= " AND c.department_id = $user_dept_id";
} else {
    // Admin can filter by department
    if ($dept_filter > 0) {
        $query_where .= " AND c.department_id = $dept_filter";
    }
}

// Year and Semester filters
if ($year_filter > 0) {
    $query_where .= " AND ep.year_of_study = $year_filter";
}
if ($semester_filter > 0) {
    $query_where .= " AND ep.semester = $semester_filter";
}
if (!empty($ay_filter)) {
    $query_where .= " AND ep.academic_year = '$ay_filter'";
}

$sql = "SELECT ep.*, c.code as course_code, c.title as course_title, d.name as department_name,
        CONCAT(u.first_name, ' ', u.last_name) as creator_name
        FROM exam_papers ep
        LEFT JOIN courses c ON ep.course_id = c.id
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN users u ON ep.created_by = u.id
        WHERE $query_where 
        ORDER BY ep.year_of_study ASC, ep.semester ASC, ep.exam_type DESC, ep.created_at DESC";

$papers_raw = [];
$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $papers_raw[] = $row;
    }
}

// Professional Hierarchical Grouping: Year -> Semester -> Exam Type
$grouped_papers = [];
foreach ($papers_raw as $p) {
    $y = $p['year_of_study'] ?: 1;
    $s = $p['semester'] ?: 1;
    $t = $p['exam_type'] ?: 'Other';

    $grouped_papers[$y][$s][$t][] = $p;
}

// Fetch departments for Admin filter
$departments = [];
if ($role === 'admin') {
    $d_res = mysqli_query($conn, "SELECT id, name FROM departments WHERE deleted_at IS NULL ORDER BY name");
    if ($d_res) {
        while ($row = mysqli_fetch_assoc($d_res)) {
            $departments[] = $row;
        }
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<div class="row align-items-center mb-4">

    <div class="col-md-5 text-md-end mt-3 mt-md-0">
        <?php if ($role === 'lecturer' || $role === 'hod'): ?>
            <a href="create_paper.php" class="btn btn-primary rounded-pill px-4 shadow-sm">
                <i class="bi bi-plus-circle me-1"></i> New Exam Paper
            </a>
        <?php endif; ?>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-lg-11">
        <!-- Filter Bar -->
        <div class="card border-0 shadow-sm rounded-4 mb-5 overflow-hidden">
            <div class="card-header bg-white border-bottom py-3 px-4 text-center">
                <h6 class="mb-0 fw-bold text-dark">Search Question Bank</h6>
            </div>
            <div class="card-body p-4 bg-light">
                <form method="GET" class="row g-3 align-items-end justify-content-center">
                    <?php if ($role === 'admin'): ?>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold text-muted">Department</label>
                            <select name="department_id" class="form-select border-0 shadow-sm">
                                <option value="0">All Departments</option>
                                <?php foreach ($departments as $d): ?>
                                    <option value="<?php echo $d['id']; ?>" <?php echo $dept_filter === (int)$d['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($d['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold text-muted">Year of Study</label>
                        <select name="year_of_study" class="form-select border-0 shadow-sm">
                            <option value="0">All Years</option>
                            <option value="1" <?php echo $year_filter === 1 ? 'selected' : ''; ?>>Year 1</option>
                            <option value="2" <?php echo $year_filter === 2 ? 'selected' : ''; ?>>Year 2</option>
                            <option value="3" <?php echo $year_filter === 3 ? 'selected' : ''; ?>>Year 3</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold text-muted">Semester</label>
                        <select name="semester" class="form-select border-0 shadow-sm">
                            <option value="0">All Semesters</option>
                            <option value="1" <?php echo $semester_filter === 1 ? 'selected' : ''; ?>>Semester 1</option>
                            <option value="2" <?php echo $semester_filter === 2 ? 'selected' : ''; ?>>Semester 2</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold text-muted">Academic Year</label>
                        <select name="academic_year" class="form-select border-0 shadow-sm">
                            <option value="">All Years</option>
                            <option value="2023" <?php echo $ay_filter === '2023' ? 'selected' : ''; ?>>2023</option>
                            <option value="2024" <?php echo $ay_filter === '2024' ? 'selected' : ''; ?>>2024</option>
                            <option value="2025" <?php echo $ay_filter === '2025' ? 'selected' : ''; ?>>2025</option>
                            <option value="2026" <?php echo $ay_filter === '2026' ? 'selected' : ''; ?>>2026</option>
                        </select>
                    </div>
                    <div class="col-md-auto">
                        <button type="submit" class="btn btn-primary px-4 rounded-3 shadow-sm">
                            <i class="bi bi-search me-1"></i> Search
                        </button>
                        <?php if ($dept_filter > 0 || $year_filter > 0 || $semester_filter > 0 || !empty($ay_filter)): ?>
                            <a href="question_bank.php" class="btn btn-light border px-4 rounded-3 shadow-sm ms-2 text-muted">Clear</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php if (empty($grouped_papers)): ?>
    <div class="text-center py-5">
        <div class="display-1 text-muted opacity-25 mb-4"><i class="bi bi-folder2-open"></i></div>
        <h4 class="text-muted fw-bold">No past papers found matching your criteria.</h4>
        <p class="text-muted px-5">The Shared Question Bank is still being populated. Try adjusting your filters or checking back later.</p>
    </div>
<?php else: ?>
    <?php foreach ($grouped_papers as $year => $semesters): ?>
        <div class="year-segment mb-5">
            <div class="d-flex align-items-center mb-4">
                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 45px; height: 45px; font-weight: 800; font-size: 1.2rem;">
                    <?php echo $year; ?>
                </div>
                <h3 class="mb-0 fw-bold text-dark tracking-tight">Year <?php echo $year; ?> <span class="text-muted fw-normal fs-5 fs-md-4">Past Papers</span></h3>
                <div class="flex-grow-1 border-bottom ms-4 opacity-50"></div>
            </div>

            <?php foreach ($semesters as $semester => $types): ?>
                <div class="semester-sub-segment mb-4 ms-md-4">
                    <h5 class="text-primary fw-bold border-start border-primary border-4 ps-3 mb-4">Semester <?php echo $semester; ?></h5>

                    <div class="row g-4">
                        <?php foreach ($types as $type => $papers): ?>
                            <div class="col-12">
                                <div class="small fw-bold text-muted text-uppercase tracking-wider mb-2 ms-1">
                                    <i class="bi bi-caret-right-fill text-primary small me-1"></i> <?php echo $type; ?>
                                </div>
                                <div class="row g-4">
                                    <?php foreach ($papers as $p): ?>
                                        <div class="col-md-6 col-lg-4 col-xl-3">
                                            <div class="card border-0 shadow-sm rounded-4 h-100 paper-card transition-all">
                                                <div class="card-body p-4">
                                                    <div class="d-flex <?php echo ((int)$p['academic_year'] >= 2026) ? 'justify-content-between' : 'justify-content-center'; ?> align-items-start mb-3">
                                                        <?php if ((int)$p['academic_year'] >= 2026): ?>
                                                            <div class="paper-icon bg-primary-subtle text-primary rounded-3 p-2">
                                                                <i class="bi bi-file-earmark-text fs-4"></i>
                                                            </div>
                                                            <span class="badge bg-light text-dark rounded-pill border py-1 px-2 small">
                                                                Year <?php echo $p['academic_year']; ?>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>

                                                    <h6 class="fw-bold mb-1 text-dark <?php echo ((int)$p['academic_year'] < 2026) ? 'text-center' : ''; ?>"><?php echo htmlspecialchars($p['course_code']); ?></h6>
                                                    <p class="text-muted small mb-3 line-clamp-2 <?php echo ((int)$p['academic_year'] < 2026) ? 'text-center' : ''; ?>" style="height: 2.5rem;"><?php echo htmlspecialchars($p['course_title']); ?></p>

                                                    <?php if ((int)$p['academic_year'] >= 2026): ?>
                                                        <div class="d-flex align-items-center mb-4 pt-2 border-top">
                                                            <div class="flex-shrink-0">
                                                                <div class="rounded-circle bg-light d-flex align-items-center justify-content-center" style="width: 32px; height: 32px; font-size: 0.8rem; font-weight: bold; color: #666;">
                                                                    <?php echo strtoupper(substr($p['creator_name'], 0, 1)); ?>
                                                                </div>
                                                            </div>
                                                            <div class="ms-2">
                                                                <div class="small fw-bold text-dark lh-1"><?php echo htmlspecialchars($p['creator_name']); ?></div>
                                                                <div class="text-muted" style="font-size: 0.7rem;">Lecturer</div>
                                                            </div>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="mb-4 pt-2 border-top"></div>
                                                    <?php endif; ?>

                                                    <a href="view_paper.php?id=<?php echo $p['id']; ?>" target="_blank" class="btn btn-outline-primary btn-sm w-100 rounded-pill fw-bold">
                                                        <i class="bi bi-eye me-1"></i> View Paper
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<style>
    .paper-card {
        border: 1px solid transparent !important;
    }

    .paper-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 1rem 3rem rgba(0, 0, 0, .1) !important;
        border-color: rgba(2, 176, 86, 0.2) !important;
    }

    .line-clamp-2 {
        display: -webkit-box;
        line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .bg-primary-subtle {
        background-color: rgba(2, 176, 86, 0.1) !important;
    }

    .tracking-tight {
        letter-spacing: -0.02em;
    }

    .tracking-wider {
        letter-spacing: 0.05em;
    }

    .transition-all {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
</style>

<?php require_once 'includes/footer.php'; ?>