<?php
// register.php
require_once 'config/database.php';
require_once 'includes/functions.php';

// If already logged in, redirect to index
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = '';
$success = '';

// Fetch departments for the dropdown
$deps = [];
$dep_q = mysqli_query($conn, "SELECT id, name FROM departments WHERE deleted_at IS NULL ORDER BY name ASC");
if ($dep_q) {
    while ($row = mysqli_fetch_assoc($dep_q)) {
        $deps[] = $row;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = mysqli_real_escape_string($conn, trim($_POST['first_name'] ?? ''));
    $last_name = mysqli_real_escape_string($conn, trim($_POST['last_name'] ?? ''));
    $email = mysqli_real_escape_string($conn, trim($_POST['email'] ?? ''));
    $password = 'uems@123'; // Default system-wide password
    $phone = mysqli_real_escape_string($conn, trim($_POST['phone'] ?? ''));
    $role = mysqli_real_escape_string($conn, trim($_POST['role'] ?? 'student')); // Default to student
    $department_id = (int)($_POST['department_id'] ?? 0);
    $registration_number = mysqli_real_escape_string($conn, trim($_POST['registration_number'] ?? ''));
    $gender = mysqli_real_escape_string($conn, trim($_POST['gender'] ?? ''));

    // Basic validation
    if (empty($first_name) || empty($last_name) || empty($email) || empty($gender) || $department_id <= 0) {
        $error = 'Please fill in all required fields, including department and gender.';
    } elseif (!in_array($role, ['student', 'lecturer'])) {
        $error = 'Invalid role selected. Only Students and Lecturers can self-register.';
    } else {
        // Check if email already exists
        $check_q = mysqli_query($conn, "SELECT id FROM users WHERE email = '$email'");
        if ($check_q && mysqli_num_rows($check_q) > 0) {
            $error = 'An account with this email already exists.';
        } else {
            // Hash password
            $hashed_pw = password_hash($password, PASSWORD_DEFAULT);

            // Insert user as inactive
            $sql = "INSERT INTO users (first_name, last_name, gender, email, password_hash, role, department_id, phone, registration_number, is_active) 
                    VALUES ('$first_name', '$last_name', '$gender', '$email', '$hashed_pw', '$role', $department_id, '$phone', '$registration_number', 0)";

            if (mysqli_query($conn, $sql)) {
                $success = 'Registration successful! Your account is currently pending activation by an Administrator. You will be able to log in once approved.';
            } else {
                $error = 'A database error occurred during registration. Please try again.';
            }
        }
    }
}
?>
<?php require_once 'includes/header.php'; ?>

<div class="row justify-content-center align-items-center mt-3">
    <div class="col-11 col-sm-9 col-md-6 col-lg-4">
        <div class="card shadow border-0 rounded-4">
            <div class="card-header bg-primary text-white text-center py-3 rounded-top-4">
                <h4 class="font-weight-light my-1 mb-0">UEMs for PHD</h4>
            </div>
            <div class="card-body p-3">
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <?php if (!empty($success)): ?>
                    <div class="alert alert-primary"><i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($success); ?></div>
                    <div class="text-center mt-4">
                        <a href="login.php" class="btn btn-outline-primary px-4 py-1">Back to Login</a>
                    </div>
                <?php else: ?>

                    <form method="POST" action="register.php">
                        <div class="row mb-1">
                            <div class="col-md-6 mb-1 mb-md-0">
                                <label class="form-label text-muted small fw-bold mb-1">First Name *</label>
                                <input class="form-control form-control-sm" type="text" name="first_name" required />
                            </div>
                            <div class="col-md-6">
                                <label class="form-label text-muted small fw-bold mb-1">Last Name *</label>
                                <input class="form-control form-control-sm" type="text" name="last_name" required />
                            </div>
                        </div>

                        <div class="mb-1">
                            <label class="form-label text-muted small fw-bold mb-1">Email Address *</label>
                            <input class="form-control form-control-sm" type="email" name="email" placeholder="example@kiu.ac.ug" required />
                        </div>

                        <div class="row mb-1">
                            <div class="col-md-6 mb-1 mb-md-0">
                                <label class="form-label text-muted small fw-bold mb-1">Phone Number</label>
                                <input class="form-control form-control-sm" type="text" name="phone" />
                            </div>
                            <div class="col-md-6">
                                <label class="form-label text-muted small fw-bold mb-1">Gender *</label>
                                <select class="form-select form-select-sm" name="gender" required>
                                    <option value="">Select Gender...</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                        </div>

                        <hr class="my-2">

                        <div class="row mb-1">
                            <div class="col-md-6">
                                <label class="form-label text-muted small fw-bold mb-1">Role *</label>
                                <select class="form-select form-select-sm" name="role" id="roleSelect" onchange="toggleRegNumber()" required>
                                    <option value="student">Student</option>
                                    <option value="lecturer">Lecturer</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label text-muted small fw-bold mb-1">Department *</label>
                                <select class="form-select form-select-sm" name="department_id" required>
                                    <option value="">Select Department...</option>
                                    <?php foreach ($deps as $d): ?>
                                        <option value="<?php echo $d['id']; ?>"><?php echo htmlspecialchars($d['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="mb-2" id="regNumGroup">
                            <label class="form-label text-muted small fw-bold mb-1">Registration Number (Students Only)</label>
                            <input class="form-control form-control-sm" type="text" name="registration_number" placeholder="2023-08-00000" />
                        </div>

                        <div class="d-grid gap-1 mt-3">
                            <button type="submit" class="btn btn-primary">Register</button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
            <div class="card-footer text-center py-3 border-0 bg-light rounded-bottom-4">
                <div class="small"><a href="login.php" class="text-decoration-none text-primary fw-bold">Have an Account??? Login</a></div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
<script>
    function toggleRegNumber() {
        var role = document.getElementById('roleSelect').value;
        var regGroup = document.getElementById('regNumGroup');
        if (regGroup) {
            if (role === 'lecturer') {
                regGroup.style.display = 'none';
                regGroup.querySelector('input').value = '';
            } else {
                regGroup.style.display = 'block';
            }
        }
    }

    // Initialize state on load
    document.addEventListener('DOMContentLoaded', toggleRegNumber);
</script>