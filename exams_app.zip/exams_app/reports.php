<?php
// reports.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role('admin');

$view_mode = $_GET['mode'] ?? 'dashboard';

// Simple reporting data
$metrics = [
    'total_papers' => 0,
    'papers_by_status' => [],
    'total_questions' => 0,
    'users_by_role' => []
];

// Completed papers (exam sessions completed)
$q_completed = mysqli_query($conn, "SELECT COUNT(DISTINCT exam_paper_id) as cnt FROM exam_sessions WHERE status = 'Completed'");
if ($q_completed) {
    $metrics['completed_papers'] = mysqli_fetch_assoc($q_completed)['cnt'];
} else {
    $metrics['completed_papers'] = 0;
}

// Total papers
$q_papers = mysqli_query($conn, "SELECT status, COUNT(*) as cnt FROM exam_papers WHERE deleted_at IS NULL GROUP BY status");
if ($q_papers) {
    while ($row = mysqli_fetch_assoc($q_papers)) {
        $metrics['papers_by_status'][$row['status']] = $row['cnt'];
        $metrics['total_papers'] += $row['cnt'];
    }
}

// Users by role
$q_users = mysqli_query($conn, "SELECT role, COUNT(*) as cnt FROM users WHERE deleted_at IS NULL AND role != 'admin' GROUP BY role");
if ($q_users) {
    while ($row = mysqli_fetch_assoc($q_users)) {
        $metrics['users_by_role'][$row['role']] = $row['cnt'];
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<style>
    /* Screen styling: dashboard look */
    .dashboard-stats .card {
        transition: transform 0.3s ease;
    }

    .dashboard-stats .card:hover {
        transform: translateY(-5px);
    }

    /* Paper View Styling for Screen */
    .view-mode-container {
        padding: 40px 0;
        background-color: #e4e6e9;
        min-height: 100vh;
    }

    .paper-shadow {
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15) !important;
        margin: 0 auto;
        background: white;
    }

    /* Common Paper/Report Styles */
    .a4-page {
        width: 100%;
        padding: 20mm 25mm !important;
        margin: 0;
        background: white;
        color: #333;
    }

    .report-section-title {
        background-color: #f8f9fa;
        border-left: 5px solid #28a745;
        padding: 8px 15px;
        font-weight: 800;
        text-align: center;
        margin-bottom: 15px;
        font-size: 1.1rem;
        color: #212529;
    }

    .report-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 30px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    }

    .report-table th {
        background-color: #28a745;
        color: white;
        font-weight: 700;
        padding: 12px 15px;
        text-align: left;
        text-transform: capitalize;
        font-size: 9pt;
        border: 1px solid #1e7e34;
    }

    .report-table td {
        border: 1px solid #dee2e6;
        padding: 12px 15px;
        font-size: 10.5pt;
    }

    .report-table tr:nth-child(even) {
        background-color: #fcfcfc;
    }

    .count-column {
        text-align: center;
        font-weight: 800;
        font-size: 11pt;
        width: 120px;
        color: #28a745;
    }

    .details-column {
        color: #495057;
        font-weight: 500;
    }

    /* Print styling: A4 Paper look */
    @media print {
        @page {
            size: A4;
            margin: 0;
        }

        body {
            background: white !important;
            font-family: 'Poppins', sans-serif !important;
            margin: 0;
            padding: 0;
        }

        .main-wrapper,
        .main-content,
        .content-body {
            display: block !important;
            padding: 0 !important;
            margin: 0 !important;
            background: white !important;
        }

        .no-print,
        .view-controls {
            display: none !important;
        }

        .print-only {
            display: block !important;
        }
    }

    <?php if ($view_mode === 'view'): ?>
    /* Ensure print-only container is styled as a paper in view mode */

    .print-only {
        display: block !important;
        position: relative;
        left: 0;
        margin: 0 auto;
        width: 210mm;
        background: white;
        padding: 0;
        z-index: 1;
    }

    <?php else: ?>.print-only {
        position: absolute;
        left: -9999px;
        top: 0;
        width: 210mm;
        background: white;
        z-index: -1000;
        visibility: visible;
    }

    <?php endif; ?>
</style>

<div class="view-controls no-print mb-4">
    <div class="row align-items-center">
        <div class="col-12 text-center">
            <h2 class="fw-bold mb-3"><i class="bi bi-bar-chart-line text-primary"></i> Admin Reports</h2>
            <div class="d-flex justify-content-center gap-3">
                <?php if ($view_mode === 'dashboard'): ?>
                    <a href="reports.php?mode=view" class="btn btn-outline-primary px-4 shadow-sm" style="border-radius: 5px;">
                        <i class="bi bi-eye"></i> View Report
                    </a>
                <?php else: ?>
                    <a href="reports.php?mode=dashboard" class="btn btn-outline-secondary px-4 rounded-pill shadow-sm">
                        <i class="bi bi-speedometer2"></i> Dashboard View
                    </a>
                    <button onclick="downloadReport()" class="btn btn-primary px-4 rounded-pill shadow-sm">
                        <i class="bi bi-download"></i> Download PDF
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Normal View (No Print) -->
<?php if ($view_mode === 'dashboard'): ?>
    <div class="no-print">
        <div class="row g-4 mb-4 dashboard-stats">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100 bg-primary text-white">
                    <div class="card-body p-4 text-center">
                        <h3 class="display-5 fw-bold"><?php echo $metrics['completed_papers']; ?></h3>
                        <p class="mb-0 text-white-50 fw-bold small uppercase">Completed papers</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100 bg-info text-white">
                    <div class="card-body p-4 text-center">
                        <h3 class="display-5 fw-bold"><?php echo $metrics['total_papers']; ?></h3>
                        <p class="mb-0 text-white-50 fw-bold small uppercase">Papers in question bank</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100 bg-success text-white">
                    <div class="card-body p-4 text-center">
                        <h3 class="display-5 fw-bold"><?php echo $metrics['papers_by_status']['Published'] ?? 0; ?></h3>
                        <p class="mb-0 text-white-50 fw-bold small uppercase">Published papers</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-header bg-white border-bottom-0 pt-4 px-4">
                        <h5 class="fw-bold mb-0">Status Distribution</h5>
                    </div>
                    <div class="card-body p-4 pt-2">
                        <ul class="list-group list-group-flush">
                            <?php foreach ($metrics['papers_by_status'] as $status => $count): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                    <?php echo format_status($status); ?>
                                    <span class="badge bg-primary rounded-pill"><?php echo $count; ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-header bg-white border-bottom-0 pt-4 px-4">
                        <h5 class="fw-bold mb-0">Users Registered</h5>
                    </div>
                    <div class="card-body p-4 pt-2">
                        <ul class="list-group list-group-flush">
                            <?php foreach ($metrics['users_by_role'] as $role => $count): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0 text-capitalize">
                                    <?php echo str_replace('_', ' ', $role); ?>s
                                    <span class="badge bg-dark rounded-pill"><?php echo $count; ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Stylized View / Print View -->
<div class="print-only <?php echo ($view_mode === 'view') ? 'paper-shadow mb-5' : ''; ?>" id="printableReport">
    <div class="a4-page">
        <!-- Branding Header -->
        <div class="text-center mb-4">
            <img src="assets/images/logo.png" alt="KIU Logo" class="mb-2" style="width: 100px;">
            <h1 class="fw-bold mb-1" style="font-size: 18pt; font-family: 'Poppins', sans-serif;">KAMPALA INTERNATIONAL UNIVERSITY</h1>
            <h3 class="fw-semibold text-secondary" style="font-size: 14pt; font-family: 'Poppins', sans-serif;">Admin Report</h3>
            <hr class="mt-3 border-2 opacity-100 mx-auto w-75">
        </div>

        <!-- Table 1: Papers -->
        <div class="mb-4">
            <h5 class="report-section-title">Papers overview</h5>
            <table class="report-table">
                <thead>
                    <tr>
                        <th>Metric Description</th>
                        <th class="text-center">Value</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="details-column">Completed papers</td>
                        <td class="count-column"><?php echo $metrics['completed_papers']; ?></td>
                    </tr>
                    <tr>
                        <td class="details-column">Papers in question bank</td>
                        <td class="count-column"><?php echo $metrics['total_papers']; ?></td>
                    </tr>
                    <tr>
                        <td class="details-column">Published papers</td>
                        <td class="count-column"><?php echo $metrics['papers_by_status']['Published'] ?? 0; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Table 2: Users -->
        <div class="mb-4">
            <h5 class="report-section-title">User statistics</h5>
            <table class="report-table">
                <thead>
                    <tr>
                        <th>Role / Designation</th>
                        <th class="text-center">Count</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="details-column">Lecturers</td>
                        <td class="count-column"><?php echo $metrics['users_by_role']['lecturer'] ?? 0; ?></td>
                    </tr>
                    <tr>
                        <td class="details-column">HODs</td>
                        <td class="count-column"><?php echo $metrics['users_by_role']['hod'] ?? 0; ?></td>
                    </tr>
                    <tr>
                        <td class="details-column">Exam Masters</td>
                        <td class="count-column"><?php echo $metrics['users_by_role']['exam_master'] ?? 0; ?></td>
                    </tr>
                    <tr>
                        <td class="details-column">Students</td>
                        <td class="count-column"><?php echo $metrics['users_by_role']['student'] ?? 0; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="text-center mt-4 pt-3 text-muted small">
            <p style="font-size: 8pt;">Kampala International University</p>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>

<!-- PDF Generation Script -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
    function downloadReport() {
        // Ensure the element is targeted correctly for PDF capture
        const element = document.getElementById('printableReport');

        // Configuration for html2pdf
        const opt = {
            margin: 0,
            filename: 'KIU_Admin_Report_<?php echo date('Y-m-d'); ?>.pdf',
            image: {
                type: 'jpeg',
                quality: 1
            },
            html2canvas: {
                scale: 3,
                useCORS: true,
                logging: false,
                letterRendering: true
            },
            jsPDF: {
                unit: 'mm',
                format: 'a4',
                orientation: 'portrait'
            }
        };

        // Trigger the download
        html2pdf().set(opt).from(element).save();
    }
</script>