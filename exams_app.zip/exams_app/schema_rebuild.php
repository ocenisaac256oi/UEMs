<?php
require_once 'config/database.php';

echo "Starting full database rebuild...\n";

// Drop views first
mysqli_query($conn, "DROP VIEW IF EXISTS hod_pending_approvals, lecturer_permissions_summary, papers_by_programme, papers_by_status_summary, papers_ready_for_print, programmes_summary, vw_paper_questions_hierarchy");

// Drop all tables
$tables = ['audit_logs', 'malpractice_reports', 'student_answers', 'exam_sessions', 'exam_results', 'workflow_history', 'paper_comments', 'exam_paper_versions', 'exam_paper_programmes', 'exam_paper_questions', 'exam_papers', 'questions', 'lecturer_permissions', 'programmes', 'study_units', 'courses', 'departments', 'colleges', 'notifications', 'sessions', 'users'];
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS=0");
foreach ($tables as $table) {
    mysqli_query($conn, "DROP TABLE IF EXISTS `$table`");
}
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS=1");

$schemas = [
    "CREATE TABLE `users` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `email` varchar(150) NOT NULL,
      `password_hash` varchar(255) NOT NULL,
      `role` enum('admin','student','lecturer','hod','exam_master') NOT NULL,
      `first_name` varchar(100) NOT NULL,
      `last_name` varchar(100) NOT NULL,
      `gender` enum('Male','Female') DEFAULT NULL,
      `phone` varchar(20) NOT NULL,
      `registration_number` varchar(50) DEFAULT NULL,
      `department_id` int(11) DEFAULT NULL,
      `college_id` int(11) DEFAULT NULL,
      `is_active` tinyint(1) NOT NULL DEFAULT 1,
      `deleted_at` timestamp NULL DEFAULT NULL,
      `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (`id`),
      UNIQUE KEY `email` (`email`)
    )",
    "CREATE TABLE `colleges` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `name` varchar(255) NOT NULL,
      `deleted_at` timestamp NULL DEFAULT NULL,
      `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `departments` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `name` varchar(255) NOT NULL,
      `college_id` int(11) NOT NULL,
      `deleted_at` timestamp NULL DEFAULT NULL,
      `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `courses` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `code` varchar(20) NOT NULL,
      `title` varchar(255) NOT NULL,
      `level` int(11) NOT NULL,
      `semester` int(11) NOT NULL,
      `department_id` int(11) NOT NULL,
      `college_id` int(11) NOT NULL,
      `deleted_at` timestamp NULL DEFAULT NULL,
      `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `programmes` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `code` varchar(50) NOT NULL,
        `name` varchar(255) NOT NULL,
        `level` varchar(50) NOT NULL,
        `duration_years` int(11) NOT NULL DEFAULT 3,
        `department_id` int(11) NOT NULL,
        `college_id` int(11) DEFAULT NULL,
        `is_active` tinyint(1) DEFAULT 1,
        `deleted_at` timestamp NULL DEFAULT NULL,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `study_units` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `unit_code` varchar(50) NOT NULL,
        `title` varchar(255) NOT NULL,
        `name` varchar(255) DEFAULT NULL,
        `description` text,
        `course_id` int(11) NOT NULL,
        `deleted_at` timestamp NULL DEFAULT NULL,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `questions` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `course_id` int(11) NOT NULL,
        `study_unit_id` int(11) DEFAULT NULL,
        `question_text` text NOT NULL,
        `question_type` varchar(50) NOT NULL,
        `difficulty_level` varchar(50) DEFAULT NULL,
        `bloom_taxonomy` varchar(50) DEFAULT NULL,
        `options` json DEFAULT NULL,
        `marks` int(11) NOT NULL,
        `usage_count` int(11) DEFAULT 0,
        `created_by` int(11) NOT NULL,
        `deleted_at` timestamp NULL DEFAULT NULL,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `exam_papers` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `course_id` int(11) NOT NULL,
      `academic_year` varchar(20) NOT NULL,
      `semester` int(11) NOT NULL,
      `year_of_study` int(11) NOT NULL,
      `exam_type` varchar(50) NOT NULL,
      `duration` int(11) NOT NULL,
      `total_marks` int(11) NOT NULL,
      `instructions` text DEFAULT NULL,
      `paper_content` longtext DEFAULT NULL,
      `status` enum('Draft','Submitted','Hod_review','Hod_approved','Hod_rejected','Dean_review','Dean_approved','Dean_rejected','Ready_for_print','Printing','Printed','Published') DEFAULT 'Draft',
      `created_by` int(11) DEFAULT NULL,
      `hod_id` int(11) DEFAULT NULL,
      `print_quantity` int(11) DEFAULT 0,
      `paper_code` varchar(50) DEFAULT NULL,
      `exam_date` date DEFAULT NULL,
      `submitted_at` timestamp NULL DEFAULT NULL,
      `hod_approved_at` timestamp NULL DEFAULT NULL,
      `published_at` timestamp NULL DEFAULT NULL,
      `deleted_at` timestamp NULL DEFAULT NULL,
      `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `exam_paper_questions` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `exam_paper_id` int(11) NOT NULL,
        `question_id` int(11) NOT NULL,
        `section` varchar(10) DEFAULT 'A',
        `question_number` varchar(10) NOT NULL,
        `sub_question_label` varchar(10) DEFAULT NULL,
        `display_number` varchar(20) DEFAULT NULL,
        `marks` int(11) NOT NULL,
        `sub_marks` int(11) DEFAULT NULL,
        `is_required` tinyint(1) DEFAULT 1,
        `is_choice` tinyint(1) DEFAULT 0,
        `choice_group` varchar(50) DEFAULT NULL,
        `choice_instructions` text DEFAULT NULL,
        `sequence_order` int(11) NOT NULL,
        `parent_question_id` int(11) DEFAULT NULL,
        `parent_question_key` varchar(50) DEFAULT NULL,
        `indentation_level` int(11) DEFAULT 0,
        `can_have_sub_questions` tinyint(1) DEFAULT 0,
        `option_order` json DEFAULT NULL,
        `custom_instructions` text DEFAULT NULL,
        `notes` text DEFAULT NULL,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `exam_paper_programmes` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `exam_paper_id` int(11) NOT NULL,
        `programme_id` int(11) NOT NULL,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `exam_sessions` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `exam_paper_id` int(11) NOT NULL,
      `student_id` int(11) NOT NULL,
      `start_time` datetime NOT NULL,
      `end_time` datetime DEFAULT NULL,
      `status` varchar(50) DEFAULT 'In_progress',
      `deleted_at` timestamp NULL DEFAULT NULL,
      `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `exam_results` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `exam_paper_id` int(11) NOT NULL,
      `student_id` int(11) NOT NULL,
      `total_score` int(11) NOT NULL,
      `grading_status` varchar(50) DEFAULT NULL,
      `deleted_at` timestamp NULL DEFAULT NULL,
      `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `student_answers` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `session_id` int(11) NOT NULL,
        `question_id` int(11) NOT NULL,
        `submitted_answer` text,
        `marks_awarded` int(11) DEFAULT NULL,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `workflow_history` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `exam_paper_id` int(11) NOT NULL,
        `action` varchar(100) NOT NULL,
        `from_status` varchar(50) NOT NULL,
        `to_status` varchar(50) NOT NULL,
        `actor_id` int(11) NOT NULL,
        `actor_role` varchar(50) NOT NULL,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `malpractice_reports` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `student_id` int(11) NOT NULL,
        `exam_paper_id` int(11) NOT NULL,
        `session_id` int(11) NOT NULL,
        `department_id` int(11) NOT NULL,
        `incident_type` varchar(100) NOT NULL,
        `details` text,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `lecturer_permissions` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `lecturer_id` int(11) NOT NULL,
        `course_id` int(11) NOT NULL,
        `can_add_questions` tinyint(1) DEFAULT 0,
        `can_create_papers` tinyint(1) DEFAULT 0,
        `granted_by` int(11) NOT NULL,
        `granted_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        `expires_at` datetime DEFAULT NULL,
        `is_active` tinyint(1) DEFAULT 1,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `paper_comments` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `exam_paper_id` int(11) NOT NULL,
        `user_id` int(11) NOT NULL,
        `comment` text NOT NULL,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `audit_logs` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) DEFAULT NULL,
        `action` varchar(255) NOT NULL,
        `details` text,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `exam_paper_versions` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `exam_paper_id` int(11) NOT NULL,
        `version_number` int(11) NOT NULL,
        `paper_content` longtext NOT NULL,
        `created_by` int(11) NOT NULL,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `notifications` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) NOT NULL,
        `title` varchar(255) NOT NULL,
        `message` text NOT NULL,
        `is_read` tinyint(1) DEFAULT 0,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )",
    "CREATE TABLE `sessions` (
        `id` varchar(128) NOT NULL,
        `data` text,
        `last_accessed` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    )"
];

foreach ($schemas as $sql) {
    if (!mysqli_query($conn, $sql)) {
        echo "Error creating table: " . mysqli_error($conn) . "\nSQL: $sql\n";
    }
}

echo "Tables recreated successfully!\n";

// Execute uems.sql to restore views and triggers (ignoring the table errors since we already created them)
$uems_sql = file_get_contents('uems.sql');
// Remove the problematic table definitions that throw errors from the uems.sql file
$uems_sql_clean = preg_replace('/-- Table structure for table.*?-- --------------------------------------------------------/s', '', $uems_sql);

// We'll execute the views manually to ensure it works
$views_triggers = [
    "CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `hod_pending_approvals`  AS SELECT `ep`.`id` AS `id`, `ep`.`paper_code` AS `paper_code`, `ep`.`status` AS `status`, `ep`.`exam_type` AS `exam_type`, `c`.`code` AS `course_code`, `c`.`title` AS `course_name`, concat(`u`.`first_name`,' ',`u`.`last_name`) AS `lecturer_name`, `ep`.`submitted_at` AS `submitted_at`, `ep`.`hod_id` AS `hod_id`, `d`.`name` AS `department_name`, group_concat(distinct `p`.`code` order by `p`.`code` ASC separator ', ') AS `programmes` FROM (((((`exam_papers` `ep` join `courses` `c` on(`ep`.`course_id` = `c`.`id`)) join `users` `u` on(`ep`.`created_by` = `u`.`id`)) left join `departments` `d` on(`c`.`department_id` = `d`.`id`)) left join `exam_paper_programmes` `epp` on(`ep`.`id` = `epp`.`exam_paper_id`)) left join `programmes` `p` on(`epp`.`programme_id` = `p`.`id`)) WHERE `ep`.`status` in ('Submitted','Hod_review') AND `ep`.`deleted_at` is null GROUP BY `ep`.`id`, `ep`.`paper_code`, `ep`.`status`, `ep`.`exam_type`, `c`.`code`, `c`.`title`, `u`.`first_name`, `u`.`last_name`, `ep`.`submitted_at`, `ep`.`hod_id`, `d`.`name`",
    "CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `lecturer_permissions_summary`  AS SELECT `u`.`id` AS `lecturer_id`, concat(`u`.`first_name`,' ',`u`.`last_name`) AS `lecturer_name`, `c`.`code` AS `course_code`, `c`.`title` AS `course_name`, `lp`.`can_add_questions` AS `can_add_questions`, `lp`.`can_create_papers` AS `can_create_papers`, `lp`.`granted_at` AS `granted_at`, `lp`.`expires_at` AS `expires_at`, concat(`hod`.`first_name`,' ',`hod`.`last_name`) AS `granted_by_name` FROM (((`lecturer_permissions` `lp` join `users` `u` on(`lp`.`lecturer_id` = `u`.`id`)) join `courses` `c` on(`lp`.`course_id` = `c`.`id`)) join `users` `hod` on(`lp`.`granted_by` = `hod`.`id`)) WHERE `lp`.`is_active` = 1 AND `u`.`deleted_at` is null AND `c`.`deleted_at` is null",
    "CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `papers_by_programme`  AS SELECT `p`.`code` AS `programme_code`, `p`.`name` AS `programme_name`, `ep`.`status` AS `status`, `ep`.`exam_type` AS `exam_type`, `ep`.`academic_year` AS `academic_year`, `ep`.`semester` AS `semester`, `c`.`code` AS `course_code`, `c`.`title` AS `course_title`, `ep`.`paper_code` AS `paper_code`, `ep`.`exam_date` AS `exam_date`, concat(`u`.`first_name`,' ',`u`.`last_name`) AS `created_by_name` FROM ((((`programmes` `p` join `exam_paper_programmes` `epp` on(`p`.`id` = `epp`.`programme_id`)) join `exam_papers` `ep` on(`epp`.`exam_paper_id` = `ep`.`id`)) join `courses` `c` on(`ep`.`course_id` = `c`.`id`)) join `users` `u` on(`ep`.`created_by` = `u`.`id`)) WHERE `p`.`deleted_at` is null AND `ep`.`deleted_at` is null ORDER BY `p`.`code` ASC, `ep`.`academic_year` DESC, `ep`.`semester` DESC",
    "CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `papers_by_status_summary`  AS SELECT `exam_papers`.`status` AS `status`, `exam_papers`.`exam_type` AS `exam_type`, count(0) AS `count`, min(`exam_papers`.`created_at`) AS `oldest_paper`, max(`exam_papers`.`created_at`) AS `newest_paper` FROM `exam_papers` WHERE `exam_papers`.`deleted_at` is null GROUP BY `exam_papers`.`status`, `exam_papers`.`exam_type`",
    "CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `papers_ready_for_print`  AS SELECT `ep`.`id` AS `id`, `ep`.`paper_code` AS `paper_code`, `ep`.`status` AS `status`, `ep`.`exam_type` AS `exam_type`, `ep`.`exam_date` AS `exam_date`, `c`.`code` AS `course_code`, `c`.`title` AS `course_name`, `ep`.`total_marks` AS `total_marks`, `ep`.`duration` AS `duration`, `ep`.`hod_approved_at` AS `hod_approved_at`, `ep`.`print_quantity` AS `print_quantity`, `d`.`name` AS `department_name`, `col`.`name` AS `college_name`, group_concat(distinct `p`.`code` order by `p`.`code` ASC separator ', ') AS `programmes`, group_concat(distinct `p`.`name` order by `p`.`code` ASC separator ' | ') AS `programme_names` FROM (((((`exam_papers` `ep` join `courses` `c` on(`ep`.`course_id` = `c`.`id`)) left join `departments` `d` on(`c`.`department_id` = `d`.`id`)) left join `colleges` `col` on(`c`.`college_id` = `col`.`id`)) left join `exam_paper_programmes` `epp` on(`ep`.`id` = `epp`.`exam_paper_id`)) left join `programmes` `p` on(`epp`.`programme_id` = `p`.`id`)) WHERE `ep`.`status` in ('Ready_for_print','Printing') AND `ep`.`deleted_at` is null GROUP BY `ep`.`id`, `ep`.`paper_code`, `ep`.`status`, `ep`.`exam_type`, `ep`.`exam_date`, `c`.`code`, `c`.`title`, `ep`.`total_marks`, `ep`.`duration`, `ep`.`hod_approved_at`, `ep`.`print_quantity`, `d`.`name`, `col`.`name`",
    "CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `programmes_summary`  AS SELECT `p`.`id` AS `id`, `p`.`code` AS `code`, `p`.`name` AS `name`, `p`.`level` AS `level`, `p`.`duration_years` AS `duration_years`, `d`.`name` AS `department_name`, `col`.`name` AS `college_name`, count(distinct `epp`.`exam_paper_id`) AS `total_exam_papers`, `p`.`is_active` AS `is_active` FROM (((`programmes` `p` left join `departments` `d` on(`p`.`department_id` = `d`.`id`)) left join `colleges` `col` on(`p`.`college_id` = `col`.`id`)) left join `exam_paper_programmes` `epp` on(`p`.`id` = `epp`.`programme_id`)) WHERE `p`.`deleted_at` is null GROUP BY `p`.`id`, `p`.`code`, `p`.`name`, `p`.`level`, `p`.`duration_years`, `d`.`name`, `col`.`name`, `p`.`is_active`",
    "CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_paper_questions_hierarchy`  AS SELECT `epq`.`id` AS `id`, `epq`.`exam_paper_id` AS `exam_paper_id`, `epq`.`question_id` AS `question_id`, `epq`.`section` AS `section`, `epq`.`question_number` AS `question_number`, `epq`.`sub_question_label` AS `sub_question_label`, `epq`.`display_number` AS `display_number`, `epq`.`marks` AS `marks`, `epq`.`sub_marks` AS `sub_marks`, `epq`.`is_required` AS `is_required`, `epq`.`is_choice` AS `is_choice`, `epq`.`choice_group` AS `choice_group`, `epq`.`choice_instructions` AS `choice_instructions`, `epq`.`sequence_order` AS `sequence_order`, `epq`.`parent_question_id` AS `parent_question_id`, `epq`.`parent_question_key` AS `parent_question_key`, `epq`.`indentation_level` AS `indentation_level`, `epq`.`can_have_sub_questions` AS `can_have_sub_questions`, `epq`.`option_order` AS `option_order`, `epq`.`custom_instructions` AS `custom_instructions`, `epq`.`notes` AS `notes`, `epq`.`created_at` AS `created_at`, `epq`.`updated_at` AS `updated_at`, `q`.`question_text` AS `question_text`, `q`.`question_type` AS `question_type`, `q`.`difficulty_level` AS `difficulty_level`, `q`.`bloom_taxonomy` AS `bloom_taxonomy`, `q`.`options` AS `options`, `c`.`code` AS `course_code`, `c`.`title` AS `course_title`, `su`.`name` AS `study_unit_title`, concat(`u`.`first_name`,' ',`u`.`last_name`) AS `created_by_name`, concat('Q',`epq`.`question_number`,case when `epq`.`sub_question_label` is not null then concat('(',`epq`.`sub_question_label`,')') else '' end) AS `full_question_number` FROM (((((`exam_paper_questions` `epq` join `questions` `q` on(`epq`.`question_id` = `q`.`id`)) join `exam_papers` `ep` on(`epq`.`exam_paper_id` = `ep`.`id`)) join `courses` `c` on(`ep`.`course_id` = `c`.`id`)) left join `study_units` `su` on(`q`.`study_unit_id` = `su`.`id`)) left join `users` `u` on(`q`.`created_by` = `u`.`id`)) WHERE `ep`.`deleted_at` is null AND `q`.`deleted_at` is null ORDER BY `epq`.`exam_paper_id` ASC, `epq`.`section` ASC, `epq`.`sequence_order` ASC, `epq`.`indentation_level` ASC"
];

foreach ($views_triggers as $sql) {
    if (!mysqli_query($conn, $sql)) {
        echo "Error creating view: " . mysqli_error($conn) . "\nSQL: $sql\n";
    }
}

// Add triggers
$triggers = [
    "CREATE TRIGGER `decrement_question_usage` AFTER DELETE ON `exam_paper_questions` FOR EACH ROW UPDATE questions SET usage_count = GREATEST(usage_count - 1, 0) WHERE id = OLD.question_id;",
    "CREATE TRIGGER `increment_question_usage` AFTER INSERT ON `exam_paper_questions` FOR EACH ROW UPDATE questions SET usage_count = usage_count + 1 WHERE id = NEW.question_id;",
    "CREATE TRIGGER `update_paper_total_marks_after_delete` AFTER DELETE ON `exam_paper_questions` FOR EACH ROW UPDATE exam_papers SET total_marks = (SELECT COALESCE(SUM(marks), 0) FROM exam_paper_questions WHERE exam_paper_id = OLD.exam_paper_id) WHERE id = OLD.exam_paper_id;",
    "CREATE TRIGGER `update_paper_total_marks_after_insert` AFTER INSERT ON `exam_paper_questions` FOR EACH ROW UPDATE exam_papers SET total_marks = (SELECT COALESCE(SUM(marks), 0) FROM exam_paper_questions WHERE exam_paper_id = NEW.exam_paper_id) WHERE id = NEW.exam_paper_id;",
    "CREATE TRIGGER `update_paper_total_marks_after_update` AFTER UPDATE ON `exam_paper_questions` FOR EACH ROW UPDATE exam_papers SET total_marks = (SELECT COALESCE(SUM(marks), 0) FROM exam_paper_questions WHERE exam_paper_id = NEW.exam_paper_id) WHERE id = NEW.exam_paper_id;"
];

foreach ($triggers as $sql) {
    if (!mysqli_query($conn, $sql)) {
        echo "Error creating trigger: " . mysqli_error($conn) . "\nSQL: $sql\n";
    }
}

echo "Database rebuild complete.\n";
?>
