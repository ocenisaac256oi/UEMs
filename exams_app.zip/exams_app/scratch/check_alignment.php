<?php
require_once 'config/database.php';
$res = mysqli_query($conn, "SELECT * FROM users LIMIT 1");
if ($res) {
    $row = mysqli_fetch_assoc($res);
    foreach ($row as $col => $val) {
        echo "$col: $val\n";
    }
} else {
    echo "Query failed: " . mysqli_error($conn) . "\n";
}
?>
