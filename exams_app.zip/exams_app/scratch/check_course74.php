<?php
require_once __DIR__ . '/../config/database.php';
$r = mysqli_query($conn, "SELECT * FROM courses WHERE id=74");
print_r(mysqli_fetch_assoc($r));

// Let's also check if there are any papers for IT dept (department_id = 2)
$r = mysqli_query($conn, "SELECT * FROM exam_papers p JOIN courses c ON p.course_id = c.id WHERE c.department_id = 2");
echo "\nIT Papers:\n";
while ($row = mysqli_fetch_assoc($r)) {
    print_r($row);
}
