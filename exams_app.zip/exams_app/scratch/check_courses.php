<?php
require_once 'config/database.php';
$res = mysqli_query($conn, "SELECT * FROM courses LIMIT 10");
while ($row = mysqli_fetch_assoc($res)) {
    print_r($row);
}
?>
