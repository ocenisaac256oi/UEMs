<?php
require_once 'config/database.php';

echo "Departments:\n";
$res = mysqli_query($conn, "SELECT id, name FROM departments");
while ($row = mysqli_fetch_assoc($res)) {
    echo "ID: {$row['id']} | Name: {$row['name']}\n";
}

echo "\nColleges:\n";
$res = mysqli_query($conn, "SELECT id, name FROM colleges");
while ($row = mysqli_fetch_assoc($res)) {
    echo "ID: {$row['id']} | Name: {$row['name']}\n";
}
?>
