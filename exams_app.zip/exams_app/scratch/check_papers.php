<?php
require_once __DIR__ . '/../config/database.php';
$r = mysqli_query($conn, "SELECT * FROM exam_papers");
while ($row = mysqli_fetch_assoc($r)) {
    print_r($row);
}
