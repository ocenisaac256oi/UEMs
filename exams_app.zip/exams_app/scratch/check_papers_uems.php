<?php
require_once 'config/database.php';

echo "PAPER COUNTS BY ACADEMIC YEAR (uems db):\n";
$res = mysqli_query($conn, "SELECT academic_year, COUNT(*) as cnt FROM exam_papers WHERE deleted_at IS NULL GROUP BY academic_year");
while ($row = mysqli_fetch_assoc($res)) {
    echo "Year {$row['academic_year']}: {$row['cnt']} papers\n";
}

echo "\nSESSION COUNTS:\n";
$res = mysqli_query($conn, "SELECT status, COUNT(*) as cnt FROM exam_sessions GROUP BY status");
while ($row = mysqli_fetch_assoc($res)) {
    echo "Status {$row['status']}: {$row['cnt']} sessions\n";
}
?>
