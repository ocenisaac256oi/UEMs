<?php
require_once 'config/database.php';
$res = mysqli_query($conn, "SELECT email, role, department_id FROM users");
while ($row = mysqli_fetch_assoc($res)) {
    print_r($row);
}
?>
