<?php
require_once 'config/database.php';

echo "Database: " . DB_NAME . "\n";

$result = mysqli_query($conn, "SHOW TABLES");
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

echo "Tables in " . DB_NAME . ":\n";
while ($row = mysqli_fetch_row($result)) {
    $table = $row[0];
    $status_result = mysqli_query($conn, "CHECK TABLE `$table` FAST");
    $status = mysqli_fetch_assoc($status_result);
    echo "- $table: " . ($status['Msg_text'] ?? 'Unknown status') . "\n";
}

echo "\nDetailed status for users table:\n";
$detail_result = mysqli_query($conn, "SHOW TABLE STATUS LIKE 'users'");
$detail = mysqli_fetch_assoc($detail_result);
print_r($detail);
?>
