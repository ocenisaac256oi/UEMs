<?php
require_once __DIR__ . '/../config/database.php';

echo "Departments:\n";
$res = mysqli_query($conn, "SELECT id, name FROM departments");
while ($r = mysqli_fetch_assoc($res)) print_r($r);

echo "\nUsers (hod):\n";
$res = mysqli_query($conn, "SELECT id, email, role, department_id FROM users WHERE role='hod'");
while ($r = mysqli_fetch_assoc($res)) print_r($r);

echo "\nUsers (lecturer):\n";
$res = mysqli_query($conn, "SELECT id, email, role, department_id FROM users WHERE role='lecturer'");
while ($r = mysqli_fetch_assoc($res)) print_r($r);

echo "\nCourses:\n";
$res = mysqli_query($conn, "SELECT id, code, department_id FROM courses LIMIT 5");
while ($r = mysqli_fetch_assoc($res)) print_r($r);

echo "\nExam Papers:\n";
$res = mysqli_query($conn, "SELECT id, course_id, status, created_by, academic_year FROM exam_papers");
while ($r = mysqli_fetch_assoc($res)) print_r($r);

