<?php
require_once __DIR__ . '/../config/database.php';
mysqli_query($conn, "DELETE FROM exam_papers WHERE id=2");
echo "Mock paper deleted.\n";
