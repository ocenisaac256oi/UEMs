<?php
require_once 'config/database.php';

echo "Discovery for 'courses'...\n";
mysqli_query($conn, "DROP TABLE IF EXISTS courses_discovery");

$create_sql = "CREATE TABLE `courses_discovery` (
  `c1` varchar(255),
  `c2` varchar(255),
  `c3` varchar(255),
  `c4` varchar(255),
  `c5` varchar(255),
  `c6` varchar(255),
  `c7` varchar(255),
  `c8` varchar(255),
  `c9` varchar(255),
  `c10` varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE courses_discovery DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\courses.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\courses_discovery.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE courses_discovery IMPORT TABLESPACE")) {
    echo "SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT * FROM courses_discovery LIMIT 1");
    $row = mysqli_fetch_assoc($res);
    foreach ($row as $k => $v) {
        echo "$k: " . bin2hex($v) . " ($v)\n";
    }
} else {
    echo "FAILED: " . mysqli_error($conn) . "\n";
}
?>
