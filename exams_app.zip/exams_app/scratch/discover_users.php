<?php
require_once 'config/database.php';

echo "Discovery mode for 'users'...\n";
mysqli_query($conn, "DROP TABLE IF EXISTS users_discovery");

$cols = [];
for ($i = 1; $i <= 20; $i++) {
    $cols[] = "`col$i` TEXT";
}
$create_sql = "CREATE TABLE `users_discovery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  " . implode(",\n  ", $cols) . ",
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE users_discovery DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\users.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\users_discovery.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE users_discovery IMPORT TABLESPACE")) {
    echo "IMPORT SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT * FROM users_discovery LIMIT 1");
    $row = mysqli_fetch_assoc($res);
    foreach ($row as $k => $v) {
        echo "$k: " . bin2hex($v) . " (" . substr($v, 0, 50) . ")\n";
    }
} else {
    echo "IMPORT FAILED: " . mysqli_error($conn) . "\n";
}
?>
