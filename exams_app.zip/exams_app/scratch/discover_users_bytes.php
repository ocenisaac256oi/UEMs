<?php
require_once 'config/database.php';

echo "Byte Discovery for 'users'...\n";
mysqli_query($conn, "DROP TABLE IF EXISTS users_bytes");

$cols = [];
for ($i = 1; $i <= 100; $i++) {
    $cols[] = "`b$i` BINARY(1)";
}
$create_sql = "CREATE TABLE `users_bytes` (
  `id` int(11) NOT NULL,
  " . implode(",\n  ", $cols) . ",
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE users_bytes DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\users.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\users_bytes.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE users_bytes IMPORT TABLESPACE")) {
    echo "SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT * FROM users_bytes LIMIT 1");
    $row = mysqli_fetch_assoc($res);
    foreach ($row as $k => $v) {
        if ($k === 'id') {
            echo "$k: $v\n";
        } else {
            echo "$k: " . bin2hex($v) . " (" . (ctype_print($v) ? $v : '.') . ")\n";
        }
    }
} else {
    echo "FAILED: " . mysqli_error($conn) . "\n";
}
?>
