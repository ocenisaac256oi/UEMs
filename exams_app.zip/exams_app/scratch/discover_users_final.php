<?php
require_once 'config/database.php';

echo "Final Discovery for 'users'...\n";
mysqli_query($conn, "DROP TABLE IF EXISTS users_final_discovery");

$cols = [];
for ($i = 1; $i <= 40; $i++) {
    $cols[] = "`c$i` VARCHAR(255)";
}
$create_sql = "CREATE TABLE `users_final_discovery` (
  " . implode(",\n  ", $cols) . "
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE users_final_discovery DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\users.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\users_final_discovery.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE users_final_discovery IMPORT TABLESPACE")) {
    echo "SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT * FROM users_final_discovery LIMIT 1");
    $row = mysqli_fetch_assoc($res);
    foreach ($row as $k => $v) {
        echo "$k: " . bin2hex($v) . " ($v)\n";
    }
} else {
    echo "FAILED: " . mysqli_error($conn) . "\n";
}
?>
