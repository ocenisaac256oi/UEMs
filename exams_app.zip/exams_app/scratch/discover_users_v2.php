<?php
require_once 'config/database.php';

echo "Flexible Discovery for 'users'...\n";
mysqli_query($conn, "DROP TABLE IF EXISTS users_discovery");

$create_sql = "CREATE TABLE `users_discovery` (
  `id` int(11) NOT NULL,
  `c2` varchar(255),
  `c3` varchar(255),
  `c4` varchar(255),
  `c5` varchar(255),
  `c6` varchar(255),
  `c7` varchar(255),
  `c8` varchar(255),
  `c9` varchar(255),
  `c10` varchar(255),
  `c11` varchar(255),
  `c12` varchar(255),
  `c13` varchar(255),
  `c14` varchar(255),
  `c15` varchar(255),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE users_discovery DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\users.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\users_discovery.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE users_discovery IMPORT TABLESPACE")) {
    echo "IMPORT SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT * FROM users_discovery LIMIT 1");
    $row = mysqli_fetch_assoc($res);
    foreach ($row as $k => $v) {
        echo "$k: " . bin2hex($v) . " ($v)\n";
    }
} else {
    echo "IMPORT FAILED: " . mysqli_error($conn) . "\n";
}
?>
