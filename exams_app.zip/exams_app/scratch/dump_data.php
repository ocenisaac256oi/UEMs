<?php
require_once 'config/database.php';

echo "USERS (first 2):\n";
$res = mysqli_query($conn, "SELECT id, first_name, last_name, role FROM users LIMIT 2");
while ($row = mysqli_fetch_assoc($res)) print_r($row);

echo "\nEXAM PAPERS (first 2):\n";
$res = mysqli_query($conn, "SELECT id, academic_year, status FROM exam_papers LIMIT 2");
while ($row = mysqli_fetch_assoc($res)) print_r($row);

echo "\nQUESTIONS COUNT:\n";
$res = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM questions");
$row = mysqli_fetch_assoc($res);
echo $row['cnt'] . "\n";
?>
