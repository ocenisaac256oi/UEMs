<?php
$file = 'C:\\xampp\\mysql\\data\\uems_backup\\users.ibd';
$data = file_get_contents($file);

$inserts = [];

// Search for the password hash signature to find user records
$offset = 0;
while (($pos = strpos($data, '$2y$10$', $offset)) !== false) {
    // The password hash is 60 bytes. It's preceded by the email.
    // Let's find the email by looking backwards.
    // We know the email ends right before the hash.
    // And the email has an '@' symbol.
    $email_end = $pos;
    $email_start = $pos - 1;
    while ($email_start > 0 && preg_match('/^[a-zA-Z0-9.@_-]$/', $data[$email_start])) {
        $email_start--;
    }
    $email_start++; // Move back to the first valid char
    
    $email = substr($data, $email_start, $email_end - $email_start);
    
    if (strpos($email, '@') === false) {
        $offset = $pos + 60;
        continue;
    }

    $hash = substr($data, $pos, 60);
    
    // Role is 1 byte after hash
    $role_val = ord($data[$pos + 60]);
    $roles = [1 => 'admin', 2 => 'student', 3 => 'lecturer', 4 => 'hod', 5 => 'exam_master'];
    $role = $roles[$role_val] ?? 'student';

    // First name and last name follow. We can extract them using the header lengths, 
    // or just assume standard characters and look for the phone number.
    
    // Let's scan forward for a phone number (10 digits starting with 07)
    $phone_pos = $pos + 61;
    $phone = '';
    for ($i = $phone_pos; $i < $phone_pos + 100; $i++) {
        $sub = substr($data, $i, 10);
        if (preg_match('/^07[0-9]{8}$/', $sub)) {
            $phone = $sub;
            $phone_pos = $i;
            break;
        }
    }

    $names_str = substr($data, $pos + 61, $phone_pos - ($pos + 61));
    // Remove non-printable chars
    $names_clean = preg_replace('/[^a-zA-Z]/', ' ', $names_str);
    $names_parts = array_filter(explode(' ', $names_clean));
    
    $first_name = array_shift($names_parts) ?? 'Unknown';
    $last_name = array_pop($names_parts) ?? 'Unknown';
    if (empty($last_name) && !empty($names_parts)) {
        $last_name = array_pop($names_parts);
    }
    if ($last_name == 'Unknown' && $first_name != 'Unknown') {
        // Maybe it's one word like SystemAdmin
        // Try to split by CamelCase
        preg_match_all('/[A-Z][a-z]*/', $first_name, $matches);
        if (count($matches[0]) >= 2) {
            $first_name = $matches[0][0];
            $last_name = $matches[0][1];
        } else {
            $last_name = $first_name;
        }
    }

    $inserts[] = "INSERT INTO users (email, password_hash, role, first_name, last_name, phone) VALUES ('" . addslashes($email) . "', '" . addslashes($hash) . "', '$role', '" . addslashes($first_name) . "', '" . addslashes($last_name) . "', '$phone');";

    $offset = $pos + 60;
}

echo "Found " . count($inserts) . " users.\n";
file_put_contents('C:\\xampp\\htdocs\\exams_app\\scratch\\users_recovered.sql', implode("\n", $inserts));
echo "Saved to scratch/users_recovered.sql\n";
?>
