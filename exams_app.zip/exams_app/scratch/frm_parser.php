<?php
// frm_parser.php
$file = $argv[1] ?? 'C:\\xampp\\mysql\\data\\uems\\users.frm';
$data = file_get_contents($file);

echo "Parsing $file...\n";

// The column names are usually stored towards the end, separated by null bytes or 0xFF
// But first, let's look for the "new" section which has more metadata.
$pos = strpos($data, "\x03\x00\x00\x00"); // A common marker for MariaDB/MySQL 5.6+
if ($pos === false) $pos = 0;

$strings = [];
$current = '';
for ($i = $pos; $i < strlen($data); $i++) {
    $c = ord($data[$i]);
    if ($c >= 32 && $c <= 126) {
        $current .= chr($c);
    } else {
        if (strlen($current) > 1) {
            $strings[] = $current;
        }
        $current = '';
    }
}

// Filter out common metadata
$ignored = ['PRIMARY', 'InnoDB', 'PARTITION', 'utf8mb4', 'utf8mb4_general_ci'];
$columns = array_filter($strings, function($s) use ($ignored) {
    return !in_array($s, $ignored) && !preg_match('/^[0-9]+$/', $s);
});

echo "Possible columns in order:\n";
print_r(array_values(array_unique($columns)));
?>
