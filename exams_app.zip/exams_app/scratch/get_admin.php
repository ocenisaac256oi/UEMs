<?php
require_once 'config/database.php';
$r = mysqli_query($conn, "SELECT email FROM users WHERE role='admin' LIMIT 1");
$user = mysqli_fetch_assoc($r);
echo "ADMIN_EMAIL:" . ($user['email'] ?? 'NOT_FOUND');
?>
