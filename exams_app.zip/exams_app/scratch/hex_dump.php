<?php
$file = $argv[1] ?? 'C:\\xampp\\mysql\\data\\uems_backup\\courses.ibd';
$data = file_get_contents($file);
// Search for the first record. Records usually start after the page header (0x38 bytes)
// But let's just search for the "ITC111" string to find a record.
$pos = strpos($data, "ITC111");
if ($pos !== false) {
    echo "Found ITC111 at offset $pos (0x" . dechex($pos) . ")\n";
    $start = $pos - 20;
    $len = 100;
    echo bin2hex(substr($data, $start, $len)) . "\n";
} else {
    echo "String not found.\n";
}
?>
