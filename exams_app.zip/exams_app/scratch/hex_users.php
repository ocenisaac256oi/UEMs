<?php
$file = 'C:\\xampp\\mysql\\data\\uems_backup\\users.ibd';
$data = file_get_contents($file);
$pos = strpos($data, "admin@uems.ac.ug");
if ($pos !== false) {
    echo "Found at offset $pos (0x" . dechex($pos) . ")\n";
    $start = $pos - 32;
    $len = 200;
    echo bin2hex(substr($data, $start, $len)) . "\n";
} else {
    echo "Not found.\n";
}
?>
