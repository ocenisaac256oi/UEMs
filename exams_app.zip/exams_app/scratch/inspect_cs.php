<?php
require_once 'config/database.php';
$res = mysqli_query($conn, "SELECT title, code FROM courses WHERE department_id=1 AND level=1 AND semester=1");
while ($row = mysqli_fetch_assoc($res)) {
    echo "{$row['code']} - {$row['title']}\n";
}
?>
