<?php
require_once __DIR__ . '/../config/database.php';
// IT Lecturer id=8, IT HOD id=6, IT course BIT1101 id=2
// Let's create an exam paper for IT course
$sql = "INSERT INTO exam_papers (course_id, created_by, exam_type, academic_year, semester, year_of_study, duration, total_marks, instructions, paper_content, status, hod_id, created_at) 
                    VALUES (2, 8, 'End of Semester', 2026, 1, 1, 180, 60, 'None', 'Q1. Test IT', 'Submitted', 6, NOW())";
mysqli_query($conn, $sql);
echo "Created IT paper.\n";

$dep_id = 2; // IT department
$sql = "SELECT ep.*, c.code as course_code, c.title as course_title,
        CONCAT(u.first_name, ' ', u.last_name) as creator_name
        FROM exam_papers ep
        JOIN courses c ON ep.course_id = c.id
        LEFT JOIN users u ON ep.created_by = u.id
        WHERE ep.deleted_at IS NULL AND ep.academic_year = '2026' AND ep.status = 'Submitted' AND c.department_id = $dep_id ORDER BY ep.created_at ASC";

$res = mysqli_query($conn, $sql);
echo "Query for IT HOD:\n";
while ($row = mysqli_fetch_assoc($res)) {
    print_r($row);
}
