<?php
require_once 'config/database.php';

// Optimization: Large transactions
mysqli_autocommit($conn, false);

echo "Starting massive data population...\n";

// Configuration
$years = [2023, 2024, 2025];
$exam_types = [
    'CAT' => ['q_count' => 4, 'marks' => 40],
    'End of Semester' => ['q_count' => 6, 'marks' => 60]
];
$creator_id = 1; // System Admin

// Generic Question Templates by Keywords in Course Title
$templates = [
    'network' => [
        "Explain the differences between the OSI model and the TCP/IP model.",
        "Describe the function of a router in a local area network.",
        "What is the physical layer responsible for in network communication?",
        "Discuss the advantages of using a star topology over a bus topology.",
        "Explain the concept of IP addressing and subnet masking.",
        "How does DNS resolve a domain name to an IP address?",
        "Describe the purpose of the DHCP protocol.",
        "What is the difference between IPv4 and IPv6?",
        "Explain the role of a firewall in network security.",
        "Discuss the concept of VLANs and their benefits."
    ],
    'program' => [
        "What is the difference between a compiled language and an interpreted language?",
        "Explain the concept of 'object-oriented programming'.",
        "Describe the purpose of a constructor in a class.",
        "How do arrays differ from linked lists in data storage?",
        "Explain the role of local and global variables in a function.",
        "What is recursion? Provide a scenario where it is useful.",
        "Discuss the importance of commenting and documentation in code.",
        "Describe how exception handling works in high-level languages.",
        "Explain the difference between 'call by value' and 'call by reference'.",
        "What is a debugger and how does it assist in software development?"
    ],
    'datab' => [
        "Explain the concept of relational database management systems (RDBMS).",
        "What is a primary key and why is it important in a table?",
        "Describe the process of database normalization (1NF, 2NF, 3NF).",
        "Explain the difference between a left join and an inner join in SQL.",
        "What is an index in a database and how does it improve performance?",
        "Describe the purpose of a database transaction and the ACID properties.",
        "Explain the role of a database administrator (DBA).",
        "What is a foreign key and how does it maintain referential integrity?",
        "Discuss the use of stored procedures in modern databases.",
        "How does data redundancy affect database efficiency?"
    ],
    'security' => [
        "Define cybersecurity and its importance in the digital age.",
        "Explain the CIA triad (Confidentiality, Integrity, Availability).",
        "What is the difference between symmetric and asymmetric encryption?",
        "Describe the risks associated with phishing attacks.",
        "How does a multi-factor authentication (MFA) system improve security?",
        "Explain the concept of social engineering in hacking.",
        "What is malware? List and describe three different types.",
        "Discuss the role of digital signatures in securing communications.",
        "How can a company protect itself from SQL injection attacks?",
        "Explain the concept of 'Least Privilege' in access control."
    ],
    'system' => [
        "Describe the phases of the Software Development Life Cycle (SDLC).",
        "What is the difference between sequential and parallel processing?",
        "Explain the role of an operating system as a resource manager.",
        "What is virtual memory and how does it benefit a system?",
        "Describe the concept of 'deadlock' in operating systems.",
        "Explain the difference between a process and a thread.",
        "Discuss the importance of requirements gathering in system analysis.",
        "What are the benefits of using a cloud-based system architecture?",
        "Describe how an interrupt handler works in a CPU.",
        "Explain the concept of 'Scalability' in system design."
    ],
    'default' => [
        "Explain the fundamental concepts associated with this course unit.",
        "Discuss the significance of this subject in the field of Computing.",
        "Describe the historical evolution of technologies related to this unit.",
        "Explain three key principles that govern successful implementation in this area.",
        "Discuss the ethical considerations relevant to this specific course.",
        "How has modern innovation changed the utility of these concepts?",
        "Describe a real-world application of the theories studied in this unit.",
        "Identify and explain the major challenges faced in this field today.",
        "What is the future outlook for technologies related to this course?",
        "Analyze the impact of artificial intelligence on this specific subject area."
    ]
];

// Fetch targeted courses
$courses_sql = "SELECT id, code, title, level, semester, department_id FROM courses 
                WHERE level IN (1, 2, 3) AND department_id IN (2, 3) AND deleted_at IS NULL";
$courses_res = mysqli_query($conn, $courses_sql);
$courses = [];
while ($row = mysqli_fetch_assoc($courses_res)) {
    $courses[] = $row;
}

$paper_count = 0;
$question_count = 0;

foreach ($courses as $course) {
    echo "Processing Course: {$course['code']} - {$course['title']}...\n";
    
    // Choose template
    $theme = 'default';
    foreach (array_keys($templates) as $key) {
        if (stripos($course['title'], $key) !== false) {
            $theme = $key;
            break;
        }
    }
    $pool = $templates[$theme];
    shuffle($pool);

    foreach ($years as $year) {
        foreach ($exam_types as $type => $config) {
            // 1. Create Paper
            $status = 'Published';
            // Realistic date
            $month = ($course['semester'] == 1) ? 12 : 5; // Dec or May
            $day = rand(10, 25);
            $pub_date = "$year-$month-$day 09:00:00";
            
            $duration = ($type === 'CAT') ? 60 : 180;
            $instr = "1. Answer all questions.\n2. Attempting to cheat leads to disqualification.";
            
            $insert_paper = "INSERT INTO exam_papers (course_id, academic_year, semester, year_of_study, exam_type, duration, total_marks, instructions, status, created_by, published_at, created_at) 
                             VALUES ({$course['id']}, $year, {$course['semester']}, {$course['level']}, '$type', $duration, {$config['marks']}, '$instr', '$status', $creator_id, '$pub_date', '$pub_date')";
            
            if (mysqli_query($conn, $insert_paper)) {
                $paper_id = mysqli_insert_id($conn);
                $paper_count++;
                
                // 2. Generate and Associate Questions
                // We pick questions from the pool
                $num_to_pick = $config['q_count'];
                // If pool too small, default to generic
                $current_q_pool = (count($pool) >= $num_to_pick) ? array_slice($pool, 0, $num_to_pick) : array_slice($templates['default'], 0, $num_to_pick);
                // Rotate pool slightly for next year
                shuffle($pool);

                foreach ($current_q_pool as $idx => $q_text) {
                    $q_marks = floor($config['marks'] / $num_to_pick);
                    $q_num = $idx + 1;
                    
                    // Insert Question
                    $insert_q = "INSERT INTO questions (course_id, question_text, marks, created_by, question_type, created_at) 
                                 VALUES ({$course['id']}, '" . mysqli_real_escape_string($conn, $q_text) . "', $q_marks, $creator_id, 'essay', '$pub_date')";
                    mysqli_query($conn, $insert_q);
                    $question_id = mysqli_insert_id($conn);
                    $question_count++;
                    
                    // Associate with Paper
                    $insert_assoc = "INSERT INTO exam_paper_questions (exam_paper_id, question_id, question_number, marks, section, sequence_order) 
                                     VALUES ($paper_id, $question_id, '$q_num', $q_marks, 'A', $q_num)";
                    mysqli_query($conn, $insert_assoc);
                }
            } else {
                echo "Failed to create paper for {$course['code']} ($year $type): " . mysqli_error($conn) . "\n";
            }
        }
    }
}

// Final commit
mysqli_commit($conn);
echo "\nPopulation Finished!\n";
echo "Total Papers Created: $paper_count\n";
echo "Total Questions Created: $question_count\n";

?>
