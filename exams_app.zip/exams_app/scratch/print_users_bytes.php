<?php
require_once 'config/database.php';
$res = mysqli_query($conn, "SELECT * FROM users_bytes LIMIT 1");
$row = mysqli_fetch_assoc($res);
$i = 0;
foreach ($row as $k => $v) {
    echo "$k: " . bin2hex($v) . " (" . (ctype_print($v) ? $v : '.') . ")\n";
    if ($i++ > 30) break;
}
