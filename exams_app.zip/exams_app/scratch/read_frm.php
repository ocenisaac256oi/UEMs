<?php
$file = $argv[1] ?? 'C:\\xampp\\mysql\\data\\uems\\users.frm';
$data = file_get_contents($file);
preg_match_all('/[a-zA-Z0-9_]{3,}/', $data, $matches);
foreach (array_unique($matches[0]) as $m) {
    echo "$m\n";
}
?>
