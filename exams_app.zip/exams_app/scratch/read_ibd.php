<?php
$file = $argv[1] ?? 'C:\\xampp\\mysql\\data\\uems_backup\\users.ibd';
$data = file_get_contents($file);
preg_match_all('/[a-zA-Z0-9.@$]{5,}/', $data, $matches);
$i = 0;
foreach ($matches[0] as $m) {
    echo "$m\n";
    if ($i++ > 100) break;
}
?>
