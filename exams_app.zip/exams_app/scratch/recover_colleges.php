<?php
require_once 'config/database.php';

echo "Restoring 'colleges'...\n";
mysqli_query($conn, "DROP TABLE IF EXISTS colleges");

// Re-creating from strings analysis: colleges.frm has: id, name, deleted_at, created_at
$create_sql = "CREATE TABLE `colleges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (file_exists("C:\\xampp\\mysql\\data\\uems\\colleges.ibd")) unlink("C:\\xampp\\mysql\\data\\uems\\colleges.ibd");
if (file_exists("C:\\xampp\\mysql\\data\\uems\\colleges.frm")) unlink("C:\\xampp\\mysql\\data\\uems\\colleges.frm");

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE colleges DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\colleges.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\colleges.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE colleges IMPORT TABLESPACE")) {
    echo "SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT * FROM colleges LIMIT 5");
    while ($row = mysqli_fetch_assoc($res)) {
        print_r($row);
    }
} else {
    echo "FAILED: " . mysqli_error($conn) . "\n";
}
?>
