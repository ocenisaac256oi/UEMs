<?php
require_once 'config/database.php';

echo "Restoring 'courses'...\n";
if (file_exists("C:\\xampp\\mysql\\data\\uems\\courses.ibd")) unlink("C:\\xampp\\mysql\\data\\uems\\courses.ibd");
if (file_exists("C:\\xampp\\mysql\\data\\uems\\courses.frm")) unlink("C:\\xampp\\mysql\\data\\uems\\courses.frm");

mysqli_query($conn, "DROP TABLE IF EXISTS courses");

$create_sql = "CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `level` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE courses DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\courses.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\courses.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE courses IMPORT TABLESPACE")) {
    echo "SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT * FROM courses LIMIT 5");
    while ($row = mysqli_fetch_assoc($res)) {
        print_r($row);
    }
} else {
    echo "FAILED: " . mysqli_error($conn) . "\n";
}
?>
