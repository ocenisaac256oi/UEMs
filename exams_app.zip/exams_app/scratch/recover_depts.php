<?php
require_once 'config/database.php';

echo "Restoring 'departments'...\n";
if (file_exists("C:\\xampp\\mysql\\data\\uems\\departments.ibd")) unlink("C:\\xampp\\mysql\\data\\uems\\departments.ibd");
if (file_exists("C:\\xampp\\mysql\\data\\uems\\departments.frm")) unlink("C:\\xampp\\mysql\\data\\uems\\departments.frm");

mysqli_query($conn, "DROP TABLE IF EXISTS departments");

$create_sql = "CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `college_id` int(11) NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE departments DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\departments.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\departments.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE departments IMPORT TABLESPACE")) {
    echo "SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT * FROM departments LIMIT 5");
    while ($row = mysqli_fetch_assoc($res)) {
        print_r($row);
    }
} else {
    echo "FAILED: " . mysqli_error($conn) . "\n";
}
?>
