<?php
require_once 'config/database.php';

echo "Restoring 'exam_papers'...\n";
if (file_exists("C:\\xampp\\mysql\\data\\uems\\exam_papers.ibd")) unlink("C:\\xampp\\mysql\\data\\uems\\exam_papers.ibd");
if (file_exists("C:\\xampp\\mysql\\data\\uems\\exam_papers.frm")) unlink("C:\\xampp\\mysql\\data\\uems\\exam_papers.frm");

mysqli_query($conn, "DROP TABLE IF EXISTS exam_papers");

// Exactly from frm_parser order:
$create_sql = "CREATE TABLE `exam_papers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `exam_type` enum('CAT','End of Semester') NOT NULL,
  `academic_year` varchar(20) NOT NULL,
  `semester` int(11) NOT NULL,
  `year_of_study` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `instructions` text DEFAULT NULL,
  `paper_content` longtext DEFAULT NULL,
  `footer_text` varchar(255) DEFAULT NULL,
  `status` enum('Draft','Submitted','Approved','Hod_review','Hod_approved','Hod_rejected','Dean_review','Dean_approved','Dean_rejected','Ready_for_print','Printing','Printed','Published') DEFAULT 'Draft',
  `hod_id` int(11) DEFAULT NULL,
  `hod_approved_at` datetime DEFAULT NULL,
  `dean_id` int(11) DEFAULT NULL,
  `exam_master_id` int(11) DEFAULT NULL,
  `printed_at` datetime DEFAULT NULL,
  `print_quantity` int(11) DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `version` int(11) DEFAULT 1,
  `is_locked` tinyint(1) DEFAULT 0,
  `metadata` longtext DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE exam_papers DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\exam_papers.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\exam_papers.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE exam_papers IMPORT TABLESPACE")) {
    echo "SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT * FROM exam_papers LIMIT 1");
    print_r(mysqli_fetch_assoc($res));
} else {
    echo "FAILED: " . mysqli_error($conn) . "\n";
}
?>
