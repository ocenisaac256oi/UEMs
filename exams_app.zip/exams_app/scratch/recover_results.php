<?php
require_once 'config/database.php';

echo "Restoring 'exam_results'...\n";
if (file_exists("C:\\xampp\\mysql\\data\\uems\\exam_results.ibd")) unlink("C:\\xampp\\mysql\\data\\uems\\exam_results.ibd");
if (file_exists("C:\\xampp\\mysql\\data\\uems\\exam_results.frm")) unlink("C:\\xampp\\mysql\\data\\uems\\exam_results.frm");

mysqli_query($conn, "DROP TABLE IF EXISTS exam_results");

$create_sql = "CREATE TABLE `exam_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_paper_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `total_score` decimal(5,2) DEFAULT NULL,
  `grading_status` enum('Pending','Graded') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE exam_results DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\exam_results.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\exam_results.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE exam_results IMPORT TABLESPACE")) {
    echo "SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT * FROM exam_results LIMIT 5");
    while ($row = mysqli_fetch_assoc($res)) {
        print_r($row);
    }
} else {
    echo "FAILED: " . mysqli_error($conn) . "\n";
}
?>
