<?php
require_once 'config/database.php';

echo "Restoring 'exam_sessions'...\n";
if (file_exists("C:\\xampp\\mysql\\data\\uems\\exam_sessions.ibd")) unlink("C:\\xampp\\mysql\\data\\uems\\exam_sessions.ibd");
if (file_exists("C:\\xampp\\mysql\\data\\uems\\exam_sessions.frm")) unlink("C:\\xampp\\mysql\\data\\uems\\exam_sessions.frm");

mysqli_query($conn, "DROP TABLE IF EXISTS exam_sessions");

// From frm_parser: id, exam_paper_id, student_id, start_time, end_time, session_answers, status
$create_sql = "CREATE TABLE `exam_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_paper_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `session_answers` longtext DEFAULT NULL,
  `status` enum('In_progress','Completed','Expired') DEFAULT 'In_progress',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE exam_sessions DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\exam_sessions.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\exam_sessions.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE exam_sessions IMPORT TABLESPACE")) {
    echo "SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT * FROM exam_sessions LIMIT 1");
    print_r(mysqli_fetch_assoc($res));
} else {
    echo "FAILED: " . mysqli_error($conn) . "\n";
}
?>
