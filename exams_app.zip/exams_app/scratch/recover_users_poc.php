<?php
// recover_users_poc.php
require_once 'config/database.php';

echo "Attempting to restore 'users' table...\n";

// 1. Reconstruct Schema (Order is critical!)
$drop_sql = "DROP TABLE IF EXISTS users";
$create_sql = "CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','student','lecturer','hod','exam_master') NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `c7` tinyint(4) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Note: I based the order on the registration/update queries and db_updates.sql

if (!mysqli_query($conn, $drop_sql)) {
    echo "Warning: Error dropping table: " . mysqli_error($conn) . "\n";
}

// Physically remove orphan files if they exist to prevent CREATE TABLE from failing
$active_ibd = "C:\\xampp\\mysql\\data\\uems\\users.ibd";
$active_frm = "C:\\xampp\\mysql\\data\\uems\\users.frm";
if (file_exists($active_ibd)) unlink($active_ibd);
if (file_exists($active_frm)) unlink($active_frm);

if (!mysqli_query($conn, $create_sql)) {
    die("Error creating table: " . mysqli_error($conn));
}

echo "Table 'users' created. Discarding tablespace...\n";

if (!mysqli_query($conn, "ALTER TABLE users DISCARD TABLESPACE")) {
    die("Error discarding tablespace: " . mysqli_error($conn));
}

echo "Tablespace discarded. Copying backup .ibd file...\n";

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\users.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\users.ibd";

if (!copy($backup_file, $active_file)) {
    die("Failed to copy .ibd file from backup.");
}

echo "File copied. Importing tablespace (this is the moment of truth)...\n";

if (!mysqli_query($conn, "ALTER TABLE users IMPORT TABLESPACE")) {
    echo "ERROR IMPORTING TABLESPACE: " . mysqli_error($conn) . "\n";
    echo "This usually means the schema doesn't match exactly. Check column types/order.\n";
} else {
    echo "SUCCESS! 'users' table restored.\n";
    
    echo "Re-adding secondary indexes...\n";
    if (!mysqli_query($conn, "ALTER TABLE users ADD UNIQUE KEY `email` (`email`)")) {
        echo "Error adding UNIQUE KEY: " . mysqli_error($conn) . "\n";
    }

    $res = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM users");
    if ($res) {
        $row = mysqli_fetch_assoc($res);
        echo "Found " . $row['cnt'] . " users in the database.\n";
    }
}
?>
