<?php
require_once 'config/database.php';

echo "DEPARTMENTS:\n";
$res = mysqli_query($conn, "SELECT id, name FROM departments");
while ($row = mysqli_fetch_assoc($res)) {
    echo "ID: {$row['id']}, Name: {$row['name']}\n";
}

echo "\nCOURSES (First 10):\n";
$res = mysqli_query($conn, "SELECT id, code, title, department_id, year_of_study, semester FROM courses LIMIT 10");
while ($row = mysqli_fetch_assoc($res)) {
    print_r($row);
}

echo "\nEXAM_PAPERS SCHEMA:\n";
$res = mysqli_query($conn, "DESCRIBE exam_papers");
while ($row = mysqli_fetch_assoc($res)) print_r($row);

echo "\nQUESTIONS SCHEMA:\n";
$res = mysqli_query($conn, "DESCRIBE questions");
while ($row = mysqli_fetch_assoc($res)) print_r($row);

echo "\nEXAM_PAPER_QUESTIONS SCHEMA:\n";
$res = mysqli_query($conn, "DESCRIBE exam_paper_questions");
while ($row = mysqli_fetch_assoc($res)) print_r($row);

?>
