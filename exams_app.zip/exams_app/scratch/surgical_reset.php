<?php
require_once 'config/database.php';

echo "STARTING SURGICAL RESET...\n";

// Disable FK checks to avoid deletion order issues
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS=0");

echo "1. Purging student attempt data (responses, results, malpractice, sessions)...\n";
mysqli_query($conn, "TRUNCATE TABLE student_answers");
mysqli_query($conn, "TRUNCATE TABLE exam_results");
mysqli_query($conn, "TRUNCATE TABLE malpractice_reports");
mysqli_query($conn, "TRUNCATE TABLE exam_sessions");

echo "2. Identifying current papers (Academic Year 2026+)...\n";
// Instead of TRUNCATE for exam_papers, we DELETE based on year to preserve past papers
$delete_papers = mysqli_query($conn, "DELETE FROM exam_papers WHERE academic_year >= '2026' OR academic_year IS NULL");
if ($delete_papers) {
    echo "Successfully deleted current exam papers.\n";
} else {
    echo "Failed to delete current papers: " . mysqli_error($conn) . "\n";
}

echo "3. Cleaning up orphan associations...\n";
// Clean up workflow history and exam_paper_questions where the paper no longer exists
mysqli_query($conn, "DELETE FROM workflow_history WHERE exam_paper_id NOT IN (SELECT id FROM exam_papers)");
mysqli_query($conn, "DELETE FROM exam_paper_questions WHERE exam_paper_id NOT IN (SELECT id FROM exam_papers)");

// Re-enable FK checks
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS=1");

echo "\nRESET COMPLETE.\n";

echo "\n--- VERIFICATION ---\n";
$res = mysqli_query($conn, "SELECT academic_year, COUNT(*) as cnt FROM exam_papers GROUP BY academic_year");
echo "REMAINING PAPERS:\n";
while ($row = mysqli_fetch_assoc($res)) {
    echo "AY {$row['academic_year']}: {$row['cnt']}\n";
}

$res = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM exam_sessions");
$row = mysqli_fetch_assoc($res);
echo "SESSIONS: " . $row['cnt'] . "\n";
?>
