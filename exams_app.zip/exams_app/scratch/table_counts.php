<?php
require_once 'config/database.php';
$res = mysqli_query($conn, "SHOW TABLES");
while ($row = mysqli_fetch_array($res)) {
    $table = $row[0];
    $c_res = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM `$table`");
    $c_row = mysqli_fetch_assoc($c_res);
    echo "$table: " . $c_row['cnt'] . "\n";
}
?>
