<?php
require_once 'config/database.php';
$res = mysqli_query($conn, "SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
while ($row = mysqli_fetch_array($res)) {
    $table = $row[0];
    $c_res = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM `$table` shadow");
    $c_row = mysqli_fetch_assoc($c_res);
    echo "$table: " . $c_row['cnt'] . "\n";
}
?>
