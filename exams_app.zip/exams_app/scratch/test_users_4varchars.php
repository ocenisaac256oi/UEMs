<?php
require_once 'config/database.php';

echo "Restoring 'users' with 4 VARCHARs...\n";
if (file_exists("C:\\xampp\\mysql\\data\\uems\\users.ibd")) unlink("C:\\xampp\\mysql\\data\\uems\\users.ibd");
if (file_exists("C:\\xampp\\mysql\\data\\uems\\users.frm")) unlink("C:\\xampp\\mysql\\data\\uems\\users.frm");

mysqli_query($conn, "DROP TABLE IF EXISTS users");

// We saw 4 length prefixes: 16 (email), 60 (hash), 6 (first), 5 (last)
// The remaining columns must be fixed-length (INT, ENUM, TINYINT, TIMESTAMP)
// Or if they are VARCHAR, they must be NULL in the first record. But phone is not NULL.
// So let's make phone a CHAR(10) in latin1 so it's fixed length!

$create_sql = "CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','student','lecturer','hod','exam_master') NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `c7` tinyint(4) NOT NULL,
  `phone` char(10) CHARACTER SET latin1 NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

mysqli_query($conn, $create_sql);
mysqli_query($conn, "ALTER TABLE users DISCARD TABLESPACE");

$backup_file = "C:\\xampp\\mysql\\data\\uems_backup\\users.ibd";
$active_file = "C:\\xampp\\mysql\\data\\uems\\users.ibd";
copy($backup_file, $active_file);

if (mysqli_query($conn, "ALTER TABLE users IMPORT TABLESPACE")) {
    echo "SUCCESS!\n";
    $res = mysqli_query($conn, "SELECT id, email, first_name, last_name, phone FROM users LIMIT 2");
    while ($row = mysqli_fetch_assoc($res)) {
        print_r($row);
    }
} else {
    echo "FAILED: " . mysqli_error($conn) . "\n";
}
?>
