<?php
require_once dirname(__DIR__) . '/config/database.php';

$sql = "ALTER TABLE exam_results ADD COLUMN IF NOT EXISTS grading_status VARCHAR(50) DEFAULT NULL";
if (mysqli_query($conn, $sql)) {
    echo "Column grading_status added or already exists.\n";
} else {
    echo "Error: " . mysqli_error($conn) . "\n";
}

// Also ensure existing malpractice results are marked if possible
// (Checking malpractice_reports to backfill might be overkill but let's do a basic one)
$sql_update = "UPDATE exam_results er 
              JOIN malpractice_reports mr ON er.student_id = mr.student_id AND er.exam_paper_id = mr.exam_paper_id
              SET er.grading_status = 'malpractice_detected', er.total_score = 0";
if (mysqli_query($conn, $sql_update)) {
    echo "Updated existing malpractice results.\n";
}
?>
