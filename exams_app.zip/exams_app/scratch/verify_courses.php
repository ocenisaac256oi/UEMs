<?php
require_once 'config/database.php';
$res = mysqli_query($conn, "SELECT department_id, level, semester, COUNT(*) as count FROM courses GROUP BY department_id, level, semester ORDER BY department_id, level, semester");
echo "Dept | Year | Sem | Count\n";
echo "---------------------------\n";
while ($row = mysqli_fetch_assoc($res)) {
    echo "{$row['department_id']}    | {$row['level']}    | {$row['semester']}   | {$row['count']}\n";
}
?>
