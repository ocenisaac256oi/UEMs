<?php
require_once 'config/database.php';
$res = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM exam_papers");
$row = mysqli_fetch_assoc($res);
echo "TOTAL PAPERS: " . ($row['cnt'] ?? 0) . "\n";

$res = mysqli_query($conn, "SELECT academic_year, COUNT(*) as cnt FROM exam_papers GROUP BY academic_year");
while($row = mysqli_fetch_assoc($res)) {
    echo "AY {$row['academic_year']}: {$row['cnt']}\n";
}
?>
