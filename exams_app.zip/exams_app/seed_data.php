<?php
require_once 'config/database.php';

echo "Starting data seeding...\n";

// Insert Admin User
$admin_password = password_hash('admin123', PASSWORD_DEFAULT);
$sql_admin = "INSERT INTO users (email, password_hash, role, first_name, last_name, phone, is_active) VALUES ('admin@uems.edu', '$admin_password', 'admin', 'System', 'Administrator', '1234567890', 1)";
if (mysqli_query($conn, $sql_admin)) {
    echo "Admin user created (admin@uems.edu / admin123)\n";
} else {
    echo "Error creating admin: " . mysqli_error($conn) . "\n";
}

// 2. Insert College (updated name)
$sql_college = "INSERT INTO colleges (name) VALUES ('School of Mathematics and Computing')";
if (mysqli_query($conn, $sql_college)) {
    $college_id = mysqli_insert_id($conn);
    echo "College created (ID: $college_id)\n";

    // 3. Insert Departments
    // Computer Science Department
    $sql_dept_cs = "INSERT INTO departments (name, college_id) VALUES ('Computer Science', $college_id)";
    if (mysqli_query($conn, $sql_dept_cs)) {
        $dept_cs_id = mysqli_insert_id($conn);
        echo "Computer Science Department created (ID: $dept_cs_id)\n";
    } else {
        echo "Error creating Computer Science department: " . mysqli_error($conn) . "\n";
    }

    // Information Technology Department
    $sql_dept_it = "INSERT INTO departments (name, college_id) VALUES ('Information Technology', $college_id)";
    if (mysqli_query($conn, $sql_dept_it)) {
        $dept_it_id = mysqli_insert_id($conn);
        echo "Information Technology Department created (ID: $dept_it_id)\n";
    } else {
        echo "Error creating Information Technology department: " . mysqli_error($conn) . "\n";
    }

    // 4. Insert Programme for Computer Science (example)
    $sql_prog_cs = "INSERT INTO programmes (code, name, level, duration_years, department_id, college_id, is_active) VALUES ('BSC-CS', 'BSc Computer Science', 'Undergraduate', 4, $dept_cs_id, $college_id, 1)";
    if (mysqli_query($conn, $sql_prog_cs)) {
        echo "Computer Science Programme created\n";
    } else {
        echo "Error creating Computer Science programme: " . mysqli_error($conn) . "\n";
    }

    // 5. Insert Courses for Information Technology
    $it_courses = [
        // Year 1 Semester 1
        ['IT101', 'Introduction to Computer Fundamentals', 1, 1],
        ['IT102', 'Introduction to Information Technology', 1, 1],
        ['IT103', 'Fundamentals of Information Technology', 1, 1],
        ['IT104', 'English Language Skills', 1, 1],
        ['IT105', 'Practices and Practices of Management', 1, 1],
        ['IT106', 'Mathematical Techniques for IT', 1, 1],
        // Year 1 Semester 2
        ['IT201', 'Communication Skills', 1, 2],
        ['IT202', 'Fundamentals of Networking', 1, 2],
        ['IT203', 'Introduction to Probability and Statistics', 1, 2],
        ['IT204', 'Web Design and Development', 1, 2],
        ['IT205', 'Fundamentals of Programming', 1, 2],
        ['IT206', 'Electronic Commerce', 1, 2],
        // Year 2 Semester 1
        ['IT301', 'Database Design, Planning and Management', 2, 1],
        ['IT302', 'Object Oriented Programming', 2, 1],
        ['IT303', 'System Analysis and Design', 2, 1],
        ['IT304', 'Electronic Services', 2, 1],
        ['IT305', 'Research Methods', 2, 1],
        ['IT306', 'Computer Hardware', 2, 1],
        // Year 2 Semester 2
        ['IT401', 'Operating Systems', 2, 2],
        ['IT402', 'Computer Networks and Data-communications', 2, 2],
        ['IT403', 'Systems Dynamics and Simulation', 2, 2],
        ['IT404', 'Graphics and Multimedia Applications', 2, 2],
        ['IT405', 'Software Engineering', 2, 2],
        ['IT406', 'Emerging Trends in Information Systems/technology', 2, 2],
        // Year 3 Semester 1
        ['IT501', 'IT Audit', 3, 1],
        ['IT502', 'IT Project Management', 3, 1],
        ['IT503', 'Network Administration and Configuration', 3, 1],
        ['IT504', 'Enterprise Data Management', 3, 1],
        ['IT505', 'Web Design, Programming, and Administration', 3, 1],
        ['IT506', 'Information and Network Security', 3, 1],
        // Year 3 Semester 2
        ['IT601', 'Computer and Cyber Forensics', 3, 2],
        ['IT602', 'Mobile Application Development', 3, 2],
        ['IT603', 'Database Management Systems', 3, 2],
        ['IT604', 'Social Issues in Computing', 3, 2],
        ['IT605', 'Cloud Computing Principles', 3, 2],
        ['IT606', 'Final Project', 3, 2]
    ];
    foreach ($it_courses as $c) {
        $sql_it_course = "INSERT INTO courses (code, title, level, semester, department_id, college_id) VALUES ('$c[0]', '$c[1]', $c[2], $c[3], $dept_it_id, $college_id)";
        if (!mysqli_query($conn, $sql_it_course)) {
            echo "Error creating IT course {$c[0]}: " . mysqli_error($conn) . "\n";
        }
    }

    // 6. Insert Courses for Computer Science (selected subset example)
    $cs_courses = [
        // Year 1 Semester I
        ['CS101', 'Computer Architecture and Organization', 1, 1],
        ['CS102', 'Introduction to Mathematical Analysis', 1, 1],
        ['CS103', 'Digital Logic', 1, 1],
        ['CS104', 'Computer Fundamentals', 1, 1],
        ['CS105', 'English Language Skills', 1, 1],
        ['CS106', 'Principles and Practice of Management', 1, 1],
        // Year 1 Semester II
        ['CS201', 'Computer Hardware', 1, 2],
        ['CS202', 'Numerical Analysis', 1, 2],
        ['CS203', 'Linear Programming', 1, 2],
        ['CS204', 'Structured Programming', 1, 2],
        ['CS205', 'Internet Technologies and Webpage Authoring', 1, 2],
        ['CS206', 'Communication Skills', 1, 2],
        // Year 2 Semester I
        ['CS301', 'Object Oriented Programming', 2, 1],
        ['CS302', 'Principles of Electronics', 2, 1],
        ['CS303', 'Systems Analysis and Design', 2, 1],
        ['CS304', 'Computer Networks and Data Communications', 2, 1],
        ['CS305', 'Research Methods', 2, 1],
        ['CS306', 'Introduction to Probability and Statistics', 2, 1],
        // Year 2 Semester II
        ['CS401', 'Application Development', 2, 2],
        ['CS402', 'Data Structures and Algorithms', 2, 2],
        ['CS403', 'Software Engineering', 2, 2],
        ['CS404', 'Operating Systems', 2, 2],
        ['CS405', 'Web-based Database Systems', 2, 2],
        ['CS406', 'Social and Professional Issues in Computing', 2, 2],
        // Year 3 Semester I
        ['CS501', 'Simulation and Modeling', 3, 1],
        ['CS502', 'Emerging Trends in Computer Science', 3, 1],
        ['CS503', 'Database Management Systems', 3, 1],
        ['CS504', 'IT Project Management', 3, 1],
        ['CS505', 'Network Administration & Configuration', 3, 1],
        ['CS506', 'Application Development By Java', 3, 1],
        // Year 3 Semester II
        ['CS601', 'Communication Systems', 3, 2],
        ['CS602', 'Research Report', 3, 2],
        ['CS603', 'Algorithm Analysis and Design', 3, 2],
        ['CS604', 'Artificial Intelligence', 3, 2],
        ['CS605', 'Mobile Application Development', 3, 2],
        ['CS606', 'Network and Information Security', 3, 2],
        ['CS607', 'Computer Graphics', 3, 2]
    ];
    foreach ($cs_courses as $c) {
        $sql_cs_course = "INSERT INTO courses (code, title, level, semester, department_id, college_id) VALUES ('$c[0]', '$c[1]', $c[2], $c[3], $dept_cs_id, $college_id)";
        if (!mysqli_query($conn, $sql_cs_course)) {
            echo "Error creating CS course {$c[0]}: " . mysqli_error($conn) . "\n";
        }
    }

    echo "All departments and courses seeded successfully.\n";
} else {
    echo "Error creating college: " . mysqli_error($conn) . "\n";
}

echo "Data seeding completed!\n";
?>
require_once 'config/database.php';

echo "Starting data seeding...\n";

// 1. Insert Admin User
$admin_password = password_hash('admin123', PASSWORD_DEFAULT);
$sql_admin = "INSERT INTO users (email, password_hash, role, first_name, last_name, phone, is_active) 
              VALUES ('admin@uems.edu', '$admin_password', 'admin', 'System', 'Administrator', '1234567890', 1)";
if (mysqli_query($conn, $sql_admin)) {
    echo "Admin user created (admin@uems.edu / admin123)\n";
} else {
    echo "Error creating admin: " . mysqli_error($conn) . "\n";
}

// 2. Insert College
$sql_college = "INSERT INTO colleges (name) VALUES ('School of Mathematics and Computing')";
if (mysqli_query($conn, $sql_college)) {
    $college_id = mysqli_insert_id($conn);
    echo "College created (ID: $college_id)\n";
    
    // 3. Insert Department
    $sql_dept = "INSERT INTO departments (name, college_id) VALUES ('Computer Science', $college_id)";
    if (mysqli_query($conn, $sql_dept)) {
$dept_id = mysqli_insert_id($conn);
    echo "Department created (ID: $dept_id)\n";

            ['IT105','Practices and Practices of Management',1,1],
            ['IT106','Mathematical Techniques for IT',1,1],
            // Year 1 Semester 2
            ['IT201','Communication Skills',1,2],
            ['IT202','Fundamentals of Networking',1,2],
            ['IT203','Introduction to Probability and Statistics',1,2],
            ['IT204','Web Design and Development',1,2],
            ['IT205','Fundamentals of Programming',1,2],
            ['IT206','Electronic Commerce',1,2],
            // Year 2 Semester 1
            ['IT301','Database Design, Planning and Management',2,1],
            ['IT302','Object Oriented Programming',2,1],
            ['IT303','System Analysis and Design',2,1],
            ['IT304','Electronic Services',2,1],
            ['IT305','Research Methods',2,1],
            ['IT306','Computer Hardware',2,1],
            // Year 2 Semester 2
            ['IT401','Operating Systems',2,2],
            ['IT402','Computer Networks and Data-communications',2,2],
            ['IT403','Systems Dynamics and Simulation',2,2],
            ['IT404','Graphics and Multimedia Applications',2,2],
            ['IT405','Software Engineering',2,2],
            ['IT406','Emerging Trends in Information Systems/technology',2,2],
            // Year 3 Semester 1
            ['IT501','IT Audit',3,1],
            ['IT502','IT Project Management',3,1],
            ['IT503','Network Administration and Configuration',3,1],
            ['IT504','Enterprise Data Management',3,1],
            ['IT505','Web Design, Programming, and Administration',3,1],
            ['IT506','Information and Network Security',3,1],
            // Year 3 Semester 2
            ['IT601','Computer and Cyber Forensics',3,2],
            ['IT602','Mobile Application Development',3,2],
            ['IT603','Database Management Systems',3,2],
            ['IT604','Social Issues in Computing',3,2],
            ['IT605','Cloud Computing Principles',3,2],
            ['IT606','Final Project',3,2],
        ];
        foreach ($it_courses as $c) {
            $sql_it_course = "INSERT INTO courses (code, title, level, semester, department_id, college_id) VALUES ('$c[0]', '$c[1]', $c[2], $c[3], $dept_it_id, $college_id)";
            if (!mysqli_query($conn, $sql_it_course)) {
                echo "Error creating IT course {$c[0]}: " . mysqli_error($conn) . "\n";
            }
        }
    } else {
        echo "Error creating IT department: " . mysqli_error($conn) . "\n";
    }

    // Additional CS courses (beyond CSC101)
    $cs_courses = [
        ['CSC102','Data Structures',1,1],
        ['CSC103','Algorithms',1,2],
        ['CSC201','Operating Systems',2,1],
        ['CSC202','Computer Networks',2,2],
        // add more as needed
    ];
    foreach ($cs_courses as $c) {
        $sql_cs_course = "INSERT INTO courses (code, title, level, semester, department_id, college_id) VALUES ('$c[0]', '$c[1]', $c[2], $c[3], $dept_id, $college_id)";
        if (!mysqli_query($conn, $sql_cs_course)) {
            echo "Error creating CS course {$c[0]}: " . mysqli_error($conn) . "\n";
        }
    }
        
        // 4. Insert Programme
        $sql_prog = "INSERT INTO programmes (code, name, level, duration_years, department_id, college_id, is_active) 
                     VALUES ('BSC-CS', 'BSc Computer Science', 'Undergraduate', 4, $dept_id, $college_id, 1)";
        if (mysqli_query($conn, $sql_prog)) {
            echo "Programme created\n";
        } else {
            echo "Error creating programme: " . mysqli_error($conn) . "\n";
        }
        
        // 5. Insert Course
        // CS course CSC101 already inserted above via cs_courses array.
        if (mysqli_query($conn, $sql_course)) {
            echo "Course created\n";
        } else {
            echo "Error creating course: " . mysqli_error($conn) . "\n";
        }
    } else {
        echo "Error creating department: " . mysqli_error($conn) . "\n";
    }
} else {
    echo "Error creating college: " . mysqli_error($conn) . "\n";
}

echo "Data seeding completed!\n";
?>
