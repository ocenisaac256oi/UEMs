<?php
require_once 'config/database.php';
$res = mysqli_query($conn, "SHOW COLUMNS FROM exam_sessions");
while($row = mysqli_fetch_assoc($res)) {
    print_r($row);
}
?>
