<?php
require_once 'config/database.php';
$res = mysqli_query($conn, "SELECT DISTINCT status FROM exam_papers");
while ($row = mysqli_fetch_assoc($res)) {
    echo $row['status'] . "\n";
}
?>
