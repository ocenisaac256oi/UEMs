
 = Get-ChildItem -Path "C:\xampp\htdocs\exams_app" -Filter "*.php" -Recurse
foreach ($file in $files) {
    $content = Get-Content $file.FullName -Raw
    $newContent = $content -replace "'draft'", "'Draft'" 
                           -replace "'submitted'", "'Submitted'" 
                           -replace "'hod_review'", "'Hod_review'" 
                           -replace "'hod_approved'", "'Hod_approved'" 
                           -replace "'hod_rejected'", "'Hod_rejected'" 
                           -replace "'dean_review'", "'Dean_review'" 
                           -replace "'dean_approved'", "'Dean_approved'" 
                           -replace "'dean_rejected'", "'Dean_rejected'" 
                           -replace "'ready_for_print'", "'Ready_for_print'" 
                           -replace "'printing'", "'Printing'" 
                           -replace "'printed'", "'Printed'" 
                           -replace "'published'", "'Published'" 
                           -replace "'in_progress'", "'In_progress'" 
                           -replace "'completed'", "'Completed'" 
                           -replace "'expired'", "'Expired'" 
                           -replace ""draft"", ""Draft"" 
                           -replace ""submitted"", ""Submitted"" 
                           -replace ""hod_review"", ""Hod_review"" 
                           -replace ""hod_approved"", ""Hod_approved"" 
                           -replace ""hod_rejected"", ""Hod_rejected"" 
                           -replace ""dean_review"", ""Dean_review"" 
                           -replace ""dean_approved"", ""Dean_approved"" 
                           -replace ""dean_rejected"", ""Dean_rejected"" 
                           -replace ""ready_for_print"", ""Ready_for_print"" 
                           -replace ""printing"", ""Printing"" 
                           -replace ""printed"", ""Printed"" 
                           -replace ""published"", ""Published"" 
                           -replace ""in_progress"", ""In_progress"" 
                           -replace ""completed"", ""Completed"" 
                           -replace ""expired"", ""Expired""
                           
    if ($content -cne $newContent) {
        Set-Content -Path $file.FullName -Value $newContent
    }
}

