<?php
// student_results.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['student']);
$user_id = $_SESSION['user_id'];

// Fetch all results for this student
$sql = "SELECT er.*, ep.exam_type, ep.total_marks as max_total, c.code as course_code, c.title as course_title,
        ep.academic_year
        FROM exam_results er
        JOIN exam_papers ep ON er.exam_paper_id = ep.id
        JOIN courses c ON ep.course_id = c.id
        WHERE er.student_id = $user_id
        ORDER BY er.created_at DESC";

// Wait, I need to make sure I have grading_status. Looking at my previous implementation it should be there.

$students = [];
$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $c_code = $row['course_code'];
        if (!isset($students[$c_code])) {
            $students[$c_code] = [
                'title' => $row['course_title'],
                'cats' => null,
                'cats_malpractice' => false,
                'eos' => null,
                'eos_malpractice' => false
            ];
        }

        $is_mal = (isset($row['grading_status']) && $row['grading_status'] === 'malpractice_detected');

        if (stripos($row['exam_type'], 'CAT') !== false) {
            $percentage = ($row['max_total'] > 0) ? ($row['total_score'] / $row['max_total']) * 40 : 0;
            $students[$c_code]['cats'] = $percentage;
            if ($is_mal) $students[$c_code]['cats_malpractice'] = true;
        } else {
            $percentage = ($row['max_total'] > 0) ? ($row['total_score'] / $row['max_total']) * 60 : 0;
            $students[$c_code]['eos'] = $percentage;
            if ($is_mal) $students[$c_code]['eos_malpractice'] = true;
        }
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<div class="card border-0 shadow-sm rounded-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="px-4 py-3">Course Code</th>
                        <th class="py-3">Course Unit</th>
                        <th class="py-3">CATs</th>
                        <th class="py-3">End of Semester</th>
                        <th class="px-4 py-3 text-end">Total Marks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($students)): ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">You have not completed any exams yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($students as $c_code => $course):
                            $c_mal = $course['cats_malpractice'] ?? false;
                            $e_mal = $course['eos_malpractice'] ?? false;
                            
                            $cats = $c_mal ? 0 : ($course['cats'] ?? null);
                            $eos = $e_mal ? 0 : ($course['eos'] ?? null);
                            
                            $final = null;
                            $bg_class = '';
                            
                            if ($cats !== null || $eos !== null) {
                                $final = ($cats ?? 0) + ($eos ?? 0);
                                if ($final >= 70) $bg_class = 'text-primary';
                                elseif ($final < 50) $bg_class = 'text-danger';
                                
                                // If either is malpractice, total is still valid from other part but we might want to flag it
                                if ($c_mal || $e_mal) $bg_class = 'text-danger';
                            }
                        ?>
                            <tr>
                                <td class="px-4"><strong><?php echo htmlspecialchars($c_code); ?></strong></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($course['title']); ?></strong>
                                    <?php if ($c_mal || $e_mal): ?>
                                        <br><span class="badge bg-danger rounded-pill px-2" style="font-size: 0.7rem;">Malpractice Reported</span>
                                    <?php endif; ?>
                                </td>
                                <td class="<?php echo $c_mal ? 'text-danger fw-bold' : ''; ?>">
                                    <?php if ($c_mal): ?>
                                        <span title="Examination Malpractice Detect">Malpractice</span>
                                    <?php else: ?>
                                        <?php echo $course['cats'] !== null ? number_format($course['cats'], 1) : '<span class="text-muted fst-italic">N/A</span>'; ?>
                                    <?php endif; ?>
                                </td>
                                <td class="<?php echo $e_mal ? 'text-danger fw-bold' : ''; ?>">
                                    <?php if ($e_mal): ?>
                                        <span title="Examination Malpractice Detect">Malpractice</span>
                                    <?php else: ?>
                                        <?php echo $course['eos'] !== null ? number_format($course['eos'], 1) : '<span class="text-muted fst-italic">N/A</span>'; ?>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 text-end">
                                    <?php if ($final !== null): ?>
                                        <h5 class="mb-0 fw-bold <?php echo $bg_class; ?>"><?php echo number_format($final, 1); ?></h5>
                                        <?php if ($c_mal || $e_mal): ?>
                                            <span class="text-danger small fw-bold">Malpractice Penalty</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-warning small"><i class="bi bi-hourglass-split"></i> Awaiting Marks</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>