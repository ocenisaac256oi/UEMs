<?php
// lecturer_students.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['lecturer', 'hod', 'admin']);
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Base query for student performance based on exams created by this lecturer
$where_clause = "ep.deleted_at IS NULL";

// If lecturer or hod, strictly only students from their department.
$dep_id = (int)($_SESSION['department_id'] ?? 0);
if ($role === 'lecturer') {
    $where_clause .= " AND ep.created_by = $user_id AND u.department_id = $dep_id";
} elseif ($role === 'hod') {
    $where_clause .= " AND c.department_id = $dep_id AND u.department_id = $dep_id";
}

$sql = "SELECT er.*, ep.exam_type, ep.total_marks as max_total, c.code as course_code, c.title as course_title,
        u.id as student_id, u.first_name, u.last_name, u.email as student_email, u.registration_number
        FROM exam_results er
        JOIN exam_papers ep ON er.exam_paper_id = ep.id
        JOIN courses c ON ep.course_id = c.id
        JOIN users u ON er.student_id = u.id
        WHERE $where_clause
        ORDER BY u.first_name, u.last_name, c.title";

$students = [];
$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $sid = $row['student_id'];
        $c_code = $row['course_code'];
        
        if (!isset($students[$sid])) {
            $students[$sid] = [
                'name' => $row['first_name'] . ' ' . $row['last_name'],
                'courses' => []
            ];
        }
        
        if (!isset($students[$sid]['courses'][$c_code])) {
            $students[$sid]['courses'][$c_code] = [
                'title' => $row['course_title'],
                'cats' => null,
                'cats_malpractice' => false,
                'eos' => null,
                'eos_malpractice' => false
            ];
        }

        $is_mal = (isset($row['grading_status']) && $row['grading_status'] === 'malpractice_detected');

        if (stripos($row['exam_type'], 'CAT') !== false) {
            $percentage = ($row['max_total'] > 0) ? ($row['total_score'] / $row['max_total']) * 40 : 0;
            $students[$sid]['courses'][$c_code]['cats'] = $percentage;
            if ($is_mal) $students[$sid]['courses'][$c_code]['cats_malpractice'] = true;
        } else {
            $percentage = ($row['max_total'] > 0) ? ($row['total_score'] / $row['max_total']) * 60 : 0;
            $students[$sid]['courses'][$c_code]['eos'] = $percentage;
            if ($is_mal) $students[$sid]['courses'][$c_code]['eos_malpractice'] = true;
        }
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<div class="card border-0 shadow-sm rounded-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="px-4 py-3">Name</th>
                        <th class="py-3">Course Unit</th>
                        <th class="py-3">CATs</th>
                        <th class="py-3">End of Semester</th>
                        <th class="px-4 py-3 text-end">Total Marks</th>
                    </tr>
                </thead>
                <?php if (empty($students)): ?>
                    <tbody>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">No student results available for your examinations yet.</td>
                        </tr>
                    </tbody>
                <?php else: ?>
                    <?php foreach ($students as $sid => $student): ?>
                        <tbody style="border-bottom: 2px solid #dee2e6;">
                            <tr style="cursor:pointer;" data-bs-toggle="collapse" data-bs-target=".student-<?php echo $sid; ?>" title="Click to view scores">
                                <td class="px-4"><strong><?php echo htmlspecialchars($student['name']); ?></strong> <i class="bi bi-chevron-down text-muted ms-2" style="font-size: 0.8em;"></i></td>
                                <td colspan="4" class="text-muted text-start align-middle">
                                    <span class="badge bg-light text-dark border"><i class="bi bi-eye"></i> View scores in <?php echo count($student['courses']); ?> course(s)</span>
                                </td>
                            </tr>
                            <?php foreach ($student['courses'] as $c_code => $course):
                                $c_mal = $course['cats_malpractice'] ?? false;
                                $e_mal = $course['eos_malpractice'] ?? false;
                                
                                $cats = $c_mal ? 0 : ($course['cats'] ?? null);
                                $eos = $e_mal ? 0 : ($course['eos'] ?? null);
                                
                                $final = null;
                                $bg_class = '';
                                
                                if ($cats !== null || $eos !== null) {
                                    $final = ($cats ?? 0) + ($eos ?? 0);
                                    if ($final >= 70) $bg_class = 'text-primary';
                                    elseif ($final < 50) $bg_class = 'text-danger';
                                    
                                    if ($c_mal || $e_mal) $bg_class = 'text-danger';
                                }
                            ?>
                                <tr class="collapse student-<?php echo $sid; ?> bg-light">
                                    <td class="px-4 border-end border-white"></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($course['title']); ?></strong>
                                        <?php if ($c_mal || $e_mal): ?>
                                            <span class="badge bg-danger rounded-pill px-2 ms-1" style="font-size: 0.65rem;">Malpractice Reported</span>
                                        <?php endif; ?>
                                        <br>
                                        <small class="text-muted"><?php echo htmlspecialchars($c_code); ?></small>
                                    </td>
                                    <td class="<?php echo $c_mal ? 'text-danger fw-bold' : ''; ?>">
                                        <?php if ($c_mal): ?>
                                            <span title="Examination Malpractice Detect">Malpractice</span>
                                        <?php else: ?>
                                            <?php echo $course['cats'] !== null ? number_format($course['cats'], 1) : '<span class="text-muted fst-italic">N/A</span>'; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="<?php echo $e_mal ? 'text-danger fw-bold' : ''; ?>">
                                        <?php if ($e_mal): ?>
                                            <span title="Examination Malpractice Detect">Malpractice</span>
                                        <?php else: ?>
                                            <?php echo $course['eos'] !== null ? number_format($course['eos'], 1) : '<span class="text-muted fst-italic">N/A</span>'; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 text-end">
                                        <?php if ($final !== null): ?>
                                            <h5 class="mb-0 fw-bold <?php echo $bg_class; ?>"><?php echo number_format($final, 1); ?></h5>
                                            <?php if ($c_mal || $e_mal): ?>
                                                <span class="text-danger small fw-bold" style="font-size: 0.7rem;">Malpractice Penalty</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-warning small fst-italic">Awaiting Marks</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    <?php endforeach; ?>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>

<style>
    tbody tr[data-bs-toggle="collapse"] {
        transition: background-color 0.2s ease;
    }

    tbody tr[data-bs-toggle="collapse"]:hover {
        background-color: #f8f9fa;
    }
</style>

<?php require_once 'includes/footer.php'; ?>