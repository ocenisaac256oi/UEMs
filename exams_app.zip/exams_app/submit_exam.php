<?php
// submit_exam.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['student']);
$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['session_id'])) {
    $session_id = (int)$_POST['session_id'];

    // Verify session
    $sq = mysqli_query($conn, "SELECT * FROM exam_sessions WHERE id = $session_id AND student_id = $user_id LIMIT 1");
    if (!$sq || mysqli_num_rows($sq) === 0) {
        set_flash_message('danger', 'Invalid session.');
        header("Location: student_dashboard.php");
        exit();
    }
    $session = mysqli_fetch_assoc($sq);
    $paper_id = $session['exam_paper_id'];
    
    // Save any submitted answers from the form POST (fallback/primary submission)
    if (isset($_POST['q_0'])) {
        $clean_answer = mysqli_real_escape_string($conn, trim($_POST['q_0']));
        mysqli_query($conn, "UPDATE exam_sessions SET session_answers = '$clean_answer' WHERE id = $session_id");
    }

    // Close session if it isn't already
    if ($session['status'] === 'In_progress') {
        mysqli_query($conn, "UPDATE exam_sessions SET status = 'Completed' WHERE id = $session_id");
    }

    // Auto-grading is bypassed for paperless thesis mode. All papers are pending manual review.
    $total_score = 0;
    $needs_manual_review = true;

    // Create or update result record
    $grading_status = $needs_manual_review ? 'pending_manual_review' : 'graded';
    
    $r_check = mysqli_query($conn, "SELECT id FROM exam_results WHERE exam_paper_id = $paper_id AND student_id = $user_id");
    if ($r_check && mysqli_num_rows($r_check) > 0) {
        mysqli_query($conn, "UPDATE exam_results SET total_score = $total_score, grading_status = '$grading_status' WHERE exam_paper_id = $paper_id AND student_id = $user_id");
    } else {
        mysqli_query($conn, "INSERT INTO exam_results (exam_paper_id, student_id, total_score, grading_status) VALUES ($paper_id, $user_id, $total_score, '$grading_status')");
    }
    
    set_flash_message('success', 'Your exam has been submitted successfully!');
    header("Location: student_results.php");
    exit();
}

header("Location: student_dashboard.php");
exit();
