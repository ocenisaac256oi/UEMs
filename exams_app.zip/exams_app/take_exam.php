<?php
// take_exam.php
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_role(['student']);
$user_id = $_SESSION['user_id'];

// 1. Determine the paper being taken
$paper_id = 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'start') {
    $paper_id = (int)$_POST['paper_id'];

    // Check if exam is published and in student's department
    $dept_id = (int)($_SESSION['department_id'] ?? 0);
    $p_check = mysqli_query($conn, "SELECT ep.* FROM exam_papers ep JOIN courses c ON ep.course_id = c.id WHERE ep.id = $paper_id AND ep.status = 'Published' AND ep.deleted_at IS NULL AND c.department_id = $dept_id");
    if (!$p_check || mysqli_num_rows($p_check) === 0) {
        set_flash_message('danger', 'Exam is not available for your department.');
        header("Location: student_dashboard.php");
        exit();
    }
    $paper = mysqli_fetch_assoc($p_check);

    // Check if session exists
    $s_check = mysqli_query($conn, "SELECT id, status FROM exam_sessions WHERE exam_paper_id = $paper_id AND student_id = $user_id");
    if ($s_check && mysqli_num_rows($s_check) > 0) {
        // Resume existing
        $session = mysqli_fetch_assoc($s_check);
        if ($session['status'] !== 'In_progress') {
            set_flash_message('warning', 'You have already completed this exam.');
            header("Location: student_dashboard.php");
            exit();
        }
    } else {
        // Create new session
        $duration = (int)$paper['duration'];
        mysqli_query($conn, "INSERT INTO exam_sessions (exam_paper_id, student_id, start_time, end_time, status) 
                             VALUES ($paper_id, $user_id, NOW(), DATE_ADD(NOW(), INTERVAL $duration MINUTE), 'In_progress')");
    }

    // Redirect to GET standard
    header("Location: take_exam.php?id=$paper_id");
    exit();
}

$paper_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($paper_id <= 0) {
    header("Location: student_dashboard.php");
    exit();
}

// 2. Load Active Session and Paper Info
$dept_id = (int)($_SESSION['department_id'] ?? 0);
$pq = mysqli_query($conn, "SELECT ep.*, c.title as course_title, c.code as course_code FROM exam_papers ep JOIN courses c ON ep.course_id = c.id WHERE ep.id = $paper_id AND c.department_id = $dept_id");
$paper = mysqli_fetch_assoc($pq);

if (!$paper) {
    set_flash_message('danger', 'Access denied to this exam.');
    header("Location: student_dashboard.php");
    exit();
}

$sq = mysqli_query($conn, "SELECT * FROM exam_sessions WHERE exam_paper_id = $paper_id AND student_id = $user_id LIMIT 1");
$session = mysqli_fetch_assoc($sq);

if (!$session || $session['status'] !== 'In_progress') {
    set_flash_message('danger', 'Invalid or expired exam session.');
    header("Location: student_dashboard.php");
    exit();
}

// Calculate remaining seconds
$end_time = strtotime($session['end_time']);
$now = time();
$seconds_left = $end_time - $now;

if ($seconds_left <= 0) {
    // Session expired
    mysqli_query($conn, "UPDATE exam_sessions SET status = 'Expired' WHERE id = {$session['id']}");
    set_flash_message('warning', 'Exam time has expired.');
    header("Location: student_dashboard.php");
    exit();
}

// 3. Load Questions if paper_content is empty
$questions = [];
if (empty($paper['paper_content'])) {
    $q_res = mysqli_query($conn, "SELECT epq.section, q.* FROM exam_paper_questions epq JOIN questions q ON epq.question_id = q.id 
                                  WHERE epq.exam_paper_id = $paper_id ORDER BY epq.section, epq.sequence_order");
    if ($q_res) {
        while ($row = mysqli_fetch_assoc($q_res)) {
            $questions[] = $row;
        }
    }
}

// 4. Load the student's current monolithic answer blob
$saved_answer = $session['session_answers'] ?? '';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($paper['course_code']); ?> Exam - UEMS Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root {
            --bs-primary: #28a745;
            --bs-primary-rgb: 40, 167, 69;
        }

        body {
            background-color: #f8f9fa;
        }

        .text-primary { color: #28a745 !important; }
        .bg-primary { background-color: #28a745 !important; }
        .btn-primary { 
            background-color: #28a745 !important; 
            border-color: #28a745 !important;
        }
        .btn-primary:hover {
            background-color: #218838 !important;
            border-color: #1e7e34 !important;
        }

        .exam-header {
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, .1);
        }

        .timer-box {
            font-family: monospace;
            font-size: 1.5rem;
            font-weight: bold;
            background: #212529;
            color: #fff;
            padding: 10px 20px;
            border-radius: 8px;
        }

        .timer-danger {
            background: #dc3545;
            animation: pulse 1s infinite alternate;
        }

        @keyframes pulse {
            from {
                opacity: 1;
            }

            to {
                opacity: 0.8;
            }
        }
    </style>
</head>

<body>

    <div class="bg-white exam-header py-3 px-4 mb-4">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h5 class="mb-0 fw-bold text-primary"><?php echo htmlspecialchars($paper['course_code']); ?>: <?php echo htmlspecialchars($paper['course_title']); ?></h5>
                <small class="text-muted"><?php echo $paper['exam_type']; ?></small>
            </div>
            <div class="col-md-4 text-center">
                <div class="timer-box d-inline-block" id="examTimer">--:--:--</div>
            </div>
            <div class="col-md-4 text-end">
                <button type="button" class="btn btn-primary px-4 fw-bold" onclick="submitFinalExam()">Finish & Submit Exam</button>
            </div>
        </div>
    </div>

    <div class="container mb-5">
        <?php if (!empty($paper['instructions'])): ?>
            <div class="alert alert-info border-0 shadow-sm rounded-4 mb-4">
                <strong><i class="bi bi-info-circle"></i> Instructions:</strong><br>
                <?php echo nl2br(htmlspecialchars($paper['instructions'])); ?>
            </div>
        <?php endif; ?>

        <form id="examForm" method="POST" action="submit_exam.php">
            <input type="hidden" name="session_id" value="<?php echo $session['id']; ?>">
            
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-header bg-primary text-white py-3">
                    <h5 class="mb-0 fw-bold"><i class="bi bi-file-text"></i> Examination Paper</h5>
                </div>
                <div class="card-body p-4 bg-white" style="font-family: inherit; font-size: 1.1rem; line-height: 1.6;">
                    <?php if (!empty($paper['paper_content'])): ?>
                        <div style="font-family: monospace; white-space: pre-wrap;"><?php echo htmlspecialchars($paper['paper_content']); ?></div>
                    <?php else: ?>
                        <?php 
                        $current_section = '';
                        $q_num = 1;
                        foreach ($questions as $q): 
                            if ($current_section !== $q['section']) {
                                $current_section = $q['section'];
                                echo "<h6 class='border-bottom pb-2 mb-3 text-uppercase fw-bold text-primary mt-4'>SECTION {$current_section}</h6>";
                            }
                        ?>
                            <div class="d-flex mb-3">
                                <div class="fw-bold me-2" style="width: 25px;"><?php echo $q_num++; ?>.</div>
                                <div class="flex-grow-1 text-justify"><?php echo nl2br(htmlspecialchars($q['question_text'])); ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 mb-4 border-top border-primary border-4">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between mb-3">
                        <strong class="text-primary fs-5"><i class="bi bi-pencil-square"></i> Student Answer Booklet</strong>
                        <span class="badge bg-light text-dark border">Total Marks: <?php echo $paper['total_marks']; ?></span>
                    </div>

                    <h6 class="mb-3 lh-base text-muted">Type all your answers in the space provided below. Ensure you number your answers correctly according to the questions above. Your work is saved automatically as you type.</h6>

                    <div class="options-container">
                        <textarea class="form-control async-save bg-light rounded-3 p-3 fs-5" name="q_0" data-qid="0" rows="18" placeholder="Begin typing your exam answers here...&#10;&#10;1) ...&#10;2) ..."><?php echo htmlspecialchars($saved_answer); ?></textarea>
                    </div>

                    <div class="text-end mt-2">
                        <small class="text-primary save-status d-none" id="status_0"><i class="bi bi-cloud-check"></i> Saved</small>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 mt-5 mb-4 bg-white">
                <div class="card-body p-4 text-center">
                    <h5 class="mb-3">Finished answering all questions?</h5>
                    <button type="button" class="btn btn-primary btn-lg px-5 py-3 fw-bold shadow" onclick="submitFinalExam()">
                        <i class="bi bi-send-check-fill"></i> Finish & Submit Exam
                    </button>
                </div>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Timer Logic
        let timeLeft = <?php echo $seconds_left; ?>;
        const timerDisplay = document.getElementById('examTimer');

        function updateTimer() {
            if (timeLeft <= 0) {
                timerDisplay.innerHTML = "00:00:00";
                document.getElementById('examForm').submit();
                return;
            }

            const h = Math.floor(timeLeft / 3600).toString().padStart(2, '0');
            const m = Math.floor((timeLeft % 3600) / 60).toString().padStart(2, '0');
            const s = (timeLeft % 60).toString().padStart(2, '0');

            timerDisplay.innerHTML = `${h}:${m}:${s}`;

            if (timeLeft < 300) { // last 5 minutes
                timerDisplay.classList.add('timer-danger');
            }

            timeLeft--;
            setTimeout(updateTimer, 1000);
        }

        updateTimer();

        // Async Save Logic
        const inputs = document.querySelectorAll('.async-save');
        let timeoutId;

        inputs.forEach(input => {
            const eventType = input.type === 'radio' ? 'change' : 'input';

            input.addEventListener(eventType, function() {
                const qid = this.getAttribute('data-qid');
                const val = this.value;
                const statusEl = document.getElementById('status_' + qid);

                statusEl.classList.remove('d-none', 'text-primary', 'text-danger');
                statusEl.classList.add('text-muted');
                statusEl.innerHTML = '<i class="bi bi-arrow-repeat spin"></i> Saving...';

                // Debounce for textareas
                clearTimeout(timeoutId);
                timeoutId = setTimeout(() => {
                    const formData = new FormData();
                    formData.append('session_id', '<?php echo $session['id']; ?>');
                    formData.append('question_id', qid);
                    formData.append('answer', val);

                    fetch('api_save_answer.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                statusEl.classList.remove('text-muted');
                                statusEl.classList.add('text-primary');
                                statusEl.innerHTML = '<i class="bi bi-cloud-check"></i> Saved';
                                setTimeout(() => statusEl.classList.add('d-none'), 2000);
                            } else {
                                statusEl.classList.remove('text-muted');
                                statusEl.classList.add('text-danger');
                                statusEl.innerHTML = '<i class="bi bi-exclamation-triangle"></i> Save Failed';
                            }
                        }).catch(err => {
                            statusEl.classList.add('text-danger');
                            statusEl.innerHTML = '<i class="bi bi-exclamation-triangle"></i> Network Error';
                        });
                }, eventType === 'input' ? 1000 : 0);
            });
        });

        function submitFinalExam() {
            if (confirm("Are you sure you want to finish and submit your exam? You cannot undo this action.")) {
                document.getElementById('examForm').submit();
            }
        }

        // Zero Tolerance Anti-Cheating Logic
        let malpracticeReported = false;

        function reportMalpractice() {
            if (malpracticeReported) return;
            malpracticeReported = true;

            const formData = new FormData();
            formData.append('session_id', '<?php echo $session['id']; ?>');

            fetch('api_report_malpractice.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                // Redirect regardless of success to lock the student out
                window.location.href = 'malpractice_notification.php';
            })
            .catch(err => {
                window.location.href = 'malpractice_notification.php';
            });
        }

        // Detect Tab Switching or Minimizing
        document.addEventListener('visibilitychange', function() {
            if (document.visibilityState === 'hidden') {
                reportMalpractice();
            }
        });

        // Detect Window Losing Focus (e.g., clicking another app)
        window.addEventListener('blur', function() {
            reportMalpractice();
        });
    </script>
</body>

</html>
