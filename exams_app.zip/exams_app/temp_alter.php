<?php
require_once 'config/database.php';
$sql = "ALTER TABLE exam_papers MODIFY status ENUM('Draft', 'Submitted', 'Approved', 'Hod_review', 'Hod_approved', 'Hod_rejected', 'Dean_review', 'Dean_approved', 'Dean_rejected', 'Ready_for_print', 'Printing', 'Printed', 'Published') DEFAULT 'Draft'";
if (mysqli_query($conn, $sql)) {
    echo "Successfully updated enum.";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
