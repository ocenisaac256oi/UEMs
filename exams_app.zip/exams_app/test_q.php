<?php
require_once 'config/database.php';
$q = mysqli_query($conn, "SELECT role, department_id, first_name, last_name FROM users WHERE role = 'exam_master'");
while ($r = mysqli_fetch_assoc($q)) {
    print_r($r);
}
