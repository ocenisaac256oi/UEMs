-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2026 at 02:51 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uems`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--
-- Error reading structure for table uems.audit_logs: #1932 - Table &#039;uems.audit_logs&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.audit_logs: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`audit_logs`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `colleges`
--
-- Error reading structure for table uems.colleges: #1932 - Table &#039;uems.colleges&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.colleges: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`colleges`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--
-- Error reading structure for table uems.courses: #1932 - Table &#039;uems.courses&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.courses: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`courses`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--
-- Error reading structure for table uems.departments: #1932 - Table &#039;uems.departments&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.departments: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`departments`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `exam_papers`
--
-- Error reading structure for table uems.exam_papers: #1932 - Table &#039;uems.exam_papers&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.exam_papers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`exam_papers`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `exam_paper_programmes`
--
-- Error reading structure for table uems.exam_paper_programmes: #1932 - Table &#039;uems.exam_paper_programmes&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.exam_paper_programmes: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`exam_paper_programmes`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `exam_paper_questions`
--
-- Error reading structure for table uems.exam_paper_questions: #1932 - Table &#039;uems.exam_paper_questions&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.exam_paper_questions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`exam_paper_questions`&#039; at line 1

--
-- Triggers `exam_paper_questions`
--
DELIMITER $$
CREATE TRIGGER `decrement_question_usage` AFTER DELETE ON `exam_paper_questions` FOR EACH ROW BEGIN
    UPDATE questions
    SET usage_count = GREATEST(usage_count - 1, 0)
    WHERE id = OLD.question_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `increment_question_usage` AFTER INSERT ON `exam_paper_questions` FOR EACH ROW BEGIN
    UPDATE questions
    SET usage_count = usage_count + 1
    WHERE id = NEW.question_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `prevent_subquestions_when_disabled` BEFORE INSERT ON `exam_paper_questions` FOR EACH ROW BEGIN
    DECLARE parent_allows_subs BOOLEAN;

    IF NEW.parent_question_id IS NOT NULL THEN
        SELECT can_have_sub_questions
        INTO parent_allows_subs
        FROM exam_paper_questions
        WHERE id = NEW.parent_question_id;

        IF parent_allows_subs = FALSE THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'Cannot add sub-question: parent does not allow sub-questions';
        END IF;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_paper_total_marks_after_delete` AFTER DELETE ON `exam_paper_questions` FOR EACH ROW BEGIN
    UPDATE exam_papers
    SET total_marks = (
        SELECT COALESCE(SUM(marks), 0)
        FROM exam_paper_questions
        WHERE exam_paper_id = OLD.exam_paper_id
    )
    WHERE id = OLD.exam_paper_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_paper_total_marks_after_insert` AFTER INSERT ON `exam_paper_questions` FOR EACH ROW BEGIN
    UPDATE exam_papers
    SET total_marks = (
        SELECT COALESCE(SUM(marks), 0)
        FROM exam_paper_questions
        WHERE exam_paper_id = NEW.exam_paper_id
    )
    WHERE id = NEW.exam_paper_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_paper_total_marks_after_update` AFTER UPDATE ON `exam_paper_questions` FOR EACH ROW BEGIN
    UPDATE exam_papers
    SET total_marks = (
        SELECT COALESCE(SUM(marks), 0)
        FROM exam_paper_questions
        WHERE exam_paper_id = NEW.exam_paper_id
    )
    WHERE id = NEW.exam_paper_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `validate_option_order_json_insert` BEFORE INSERT ON `exam_paper_questions` FOR EACH ROW BEGIN
    IF NEW.option_order IS NOT NULL
       AND JSON_VALID(NEW.option_order) = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid JSON in option_order';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `validate_option_order_json_update` BEFORE UPDATE ON `exam_paper_questions` FOR EACH ROW BEGIN
    IF NEW.option_order IS NOT NULL
       AND JSON_VALID(NEW.option_order) = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid JSON in option_order';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `exam_paper_versions`
--
-- Error reading structure for table uems.exam_paper_versions: #1932 - Table &#039;uems.exam_paper_versions&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.exam_paper_versions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`exam_paper_versions`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `exam_results`
--
-- Error reading structure for table uems.exam_results: #1932 - Table &#039;uems.exam_results&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.exam_results: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`exam_results`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `exam_sessions`
--
-- Error reading structure for table uems.exam_sessions: #1932 - Table &#039;uems.exam_sessions&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.exam_sessions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`exam_sessions`&#039; at line 1

-- --------------------------------------------------------

--
-- Stand-in structure for view `hod_pending_approvals`
-- (See below for the actual view)
--
CREATE TABLE `hod_pending_approvals` (
);

-- --------------------------------------------------------

--
-- Table structure for table `lecturer_permissions`
--
-- Error reading structure for table uems.lecturer_permissions: #1932 - Table &#039;uems.lecturer_permissions&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.lecturer_permissions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`lecturer_permissions`&#039; at line 1

-- --------------------------------------------------------

--
-- Stand-in structure for view `lecturer_permissions_summary`
-- (See below for the actual view)
--
CREATE TABLE `lecturer_permissions_summary` (
);

-- --------------------------------------------------------

--
-- Table structure for table `malpractice_reports`
--
-- Error reading structure for table uems.malpractice_reports: #1932 - Table &#039;uems.malpractice_reports&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.malpractice_reports: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`malpractice_reports`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--
-- Error reading structure for table uems.notifications: #1932 - Table &#039;uems.notifications&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.notifications: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`notifications`&#039; at line 1

-- --------------------------------------------------------

--
-- Stand-in structure for view `papers_by_programme`
-- (See below for the actual view)
--
CREATE TABLE `papers_by_programme` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `papers_by_status_summary`
-- (See below for the actual view)
--
CREATE TABLE `papers_by_status_summary` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `papers_ready_for_print`
-- (See below for the actual view)
--
CREATE TABLE `papers_ready_for_print` (
);

-- --------------------------------------------------------

--
-- Table structure for table `paper_comments`
--
-- Error reading structure for table uems.paper_comments: #1932 - Table &#039;uems.paper_comments&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.paper_comments: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`paper_comments`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `programmes`
--
-- Error reading structure for table uems.programmes: #1932 - Table &#039;uems.programmes&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.programmes: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`programmes`&#039; at line 1

-- --------------------------------------------------------

--
-- Stand-in structure for view `programmes_summary`
-- (See below for the actual view)
--
CREATE TABLE `programmes_summary` (
);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--
-- Error reading structure for table uems.questions: #1932 - Table &#039;uems.questions&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.questions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`questions`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--
-- Error reading structure for table uems.sessions: #1932 - Table &#039;uems.sessions&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.sessions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`sessions`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `student_answers`
--
-- Error reading structure for table uems.student_answers: #1932 - Table &#039;uems.student_answers&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.student_answers: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`student_answers`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `study_units`
--
-- Error reading structure for table uems.study_units: #1932 - Table &#039;uems.study_units&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.study_units: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`study_units`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table uems.users: #1932 - Table &#039;uems.users&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`users`&#039; at line 1

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_paper_questions_hierarchy`
-- (See below for the actual view)
--
CREATE TABLE `vw_paper_questions_hierarchy` (
);

-- --------------------------------------------------------

--
-- Table structure for table `workflow_history`
--
-- Error reading structure for table uems.workflow_history: #1932 - Table &#039;uems.workflow_history&#039; doesn&#039;t exist in engine
-- Error reading data for table uems.workflow_history: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `uems`.`workflow_history`&#039; at line 1

-- --------------------------------------------------------

--
-- Structure for view `hod_pending_approvals`
--
DROP TABLE IF EXISTS `hod_pending_approvals`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `hod_pending_approvals`  AS SELECT `ep`.`id` AS `id`, `ep`.`paper_code` AS `paper_code`, `ep`.`status` AS `status`, `ep`.`exam_type` AS `exam_type`, `c`.`code` AS `course_code`, `c`.`title` AS `course_name`, concat(`u`.`first_name`,' ',`u`.`last_name`) AS `lecturer_name`, `ep`.`submitted_at` AS `submitted_at`, `ep`.`hod_id` AS `hod_id`, `d`.`name` AS `department_name`, group_concat(distinct `p`.`code` order by `p`.`code` ASC separator ', ') AS `programmes` FROM (((((`exam_papers` `ep` join `courses` `c` on(`ep`.`course_id` = `c`.`id`)) join `users` `u` on(`ep`.`created_by` = `u`.`id`)) left join `departments` `d` on(`c`.`department_id` = `d`.`id`)) left join `exam_paper_programmes` `epp` on(`ep`.`id` = `epp`.`exam_paper_id`)) left join `programmes` `p` on(`epp`.`programme_id` = `p`.`id`)) WHERE `ep`.`status` in ('submitted','hod_review') AND `ep`.`deleted_at` is null GROUP BY `ep`.`id`, `ep`.`paper_code`, `ep`.`status`, `ep`.`exam_type`, `c`.`code`, `c`.`title`, `u`.`first_name`, `u`.`last_name`, `ep`.`submitted_at`, `ep`.`hod_id`, `d`.`name` ;

-- --------------------------------------------------------

--
-- Structure for view `lecturer_permissions_summary`
--
DROP TABLE IF EXISTS `lecturer_permissions_summary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `lecturer_permissions_summary`  AS SELECT `u`.`id` AS `lecturer_id`, concat(`u`.`first_name`,' ',`u`.`last_name`) AS `lecturer_name`, `c`.`code` AS `course_code`, `c`.`title` AS `course_name`, `lp`.`can_add_questions` AS `can_add_questions`, `lp`.`can_create_papers` AS `can_create_papers`, `lp`.`granted_at` AS `granted_at`, `lp`.`expires_at` AS `expires_at`, concat(`hod`.`first_name`,' ',`hod`.`last_name`) AS `granted_by_name` FROM (((`lecturer_permissions` `lp` join `users` `u` on(`lp`.`lecturer_id` = `u`.`id`)) join `courses` `c` on(`lp`.`course_id` = `c`.`id`)) join `users` `hod` on(`lp`.`granted_by` = `hod`.`id`)) WHERE `lp`.`is_active` = 1 AND `u`.`deleted_at` is null AND `c`.`deleted_at` is null ;

-- --------------------------------------------------------

--
-- Structure for view `papers_by_programme`
--
DROP TABLE IF EXISTS `papers_by_programme`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `papers_by_programme`  AS SELECT `p`.`code` AS `programme_code`, `p`.`name` AS `programme_name`, `ep`.`status` AS `status`, `ep`.`exam_type` AS `exam_type`, `ep`.`academic_year` AS `academic_year`, `ep`.`semester` AS `semester`, `c`.`code` AS `course_code`, `c`.`title` AS `course_title`, `ep`.`paper_code` AS `paper_code`, `ep`.`exam_date` AS `exam_date`, concat(`u`.`first_name`,' ',`u`.`last_name`) AS `created_by_name` FROM ((((`programmes` `p` join `exam_paper_programmes` `epp` on(`p`.`id` = `epp`.`programme_id`)) join `exam_papers` `ep` on(`epp`.`exam_paper_id` = `ep`.`id`)) join `courses` `c` on(`ep`.`course_id` = `c`.`id`)) join `users` `u` on(`ep`.`created_by` = `u`.`id`)) WHERE `p`.`deleted_at` is null AND `ep`.`deleted_at` is null ORDER BY `p`.`code` ASC, `ep`.`academic_year` DESC, `ep`.`semester` DESC ;

-- --------------------------------------------------------

--
-- Structure for view `papers_by_status_summary`
--
DROP TABLE IF EXISTS `papers_by_status_summary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `papers_by_status_summary`  AS SELECT `exam_papers`.`status` AS `status`, `exam_papers`.`exam_type` AS `exam_type`, count(0) AS `count`, min(`exam_papers`.`created_at`) AS `oldest_paper`, max(`exam_papers`.`created_at`) AS `newest_paper` FROM `exam_papers` WHERE `exam_papers`.`deleted_at` is null GROUP BY `exam_papers`.`status`, `exam_papers`.`exam_type` ;

-- --------------------------------------------------------

--
-- Structure for view `papers_ready_for_print`
--
DROP TABLE IF EXISTS `papers_ready_for_print`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `papers_ready_for_print`  AS SELECT `ep`.`id` AS `id`, `ep`.`paper_code` AS `paper_code`, `ep`.`status` AS `status`, `ep`.`exam_type` AS `exam_type`, `ep`.`exam_date` AS `exam_date`, `c`.`code` AS `course_code`, `c`.`title` AS `course_name`, `ep`.`total_marks` AS `total_marks`, `ep`.`duration` AS `duration`, `ep`.`hod_approved_at` AS `hod_approved_at`, `ep`.`print_quantity` AS `print_quantity`, `d`.`name` AS `department_name`, `col`.`name` AS `college_name`, group_concat(distinct `p`.`code` order by `p`.`code` ASC separator ', ') AS `programmes`, group_concat(distinct `p`.`name` order by `p`.`code` ASC separator ' | ') AS `programme_names` FROM (((((`exam_papers` `ep` join `courses` `c` on(`ep`.`course_id` = `c`.`id`)) left join `departments` `d` on(`c`.`department_id` = `d`.`id`)) left join `colleges` `col` on(`c`.`college_id` = `col`.`id`)) left join `exam_paper_programmes` `epp` on(`ep`.`id` = `epp`.`exam_paper_id`)) left join `programmes` `p` on(`epp`.`programme_id` = `p`.`id`)) WHERE `ep`.`status` in ('ready_for_print','printing') AND `ep`.`deleted_at` is null GROUP BY `ep`.`id`, `ep`.`paper_code`, `ep`.`status`, `ep`.`exam_type`, `ep`.`exam_date`, `c`.`code`, `c`.`title`, `ep`.`total_marks`, `ep`.`duration`, `ep`.`hod_approved_at`, `ep`.`print_quantity`, `d`.`name`, `col`.`name` ;

-- --------------------------------------------------------

--
-- Structure for view `programmes_summary`
--
DROP TABLE IF EXISTS `programmes_summary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `programmes_summary`  AS SELECT `p`.`id` AS `id`, `p`.`code` AS `code`, `p`.`name` AS `name`, `p`.`level` AS `level`, `p`.`duration_years` AS `duration_years`, `d`.`name` AS `department_name`, `col`.`name` AS `college_name`, count(distinct `epp`.`exam_paper_id`) AS `total_exam_papers`, `p`.`is_active` AS `is_active` FROM (((`programmes` `p` left join `departments` `d` on(`p`.`department_id` = `d`.`id`)) left join `colleges` `col` on(`p`.`college_id` = `col`.`id`)) left join `exam_paper_programmes` `epp` on(`p`.`id` = `epp`.`programme_id`)) WHERE `p`.`deleted_at` is null GROUP BY `p`.`id`, `p`.`code`, `p`.`name`, `p`.`level`, `p`.`duration_years`, `d`.`name`, `col`.`name`, `p`.`is_active` ;

-- --------------------------------------------------------

--
-- Structure for view `vw_paper_questions_hierarchy`
--
DROP TABLE IF EXISTS `vw_paper_questions_hierarchy`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_paper_questions_hierarchy`  AS SELECT `epq`.`id` AS `id`, `epq`.`exam_paper_id` AS `exam_paper_id`, `epq`.`question_id` AS `question_id`, `epq`.`section` AS `section`, `epq`.`question_number` AS `question_number`, `epq`.`sub_question_label` AS `sub_question_label`, `epq`.`display_number` AS `display_number`, `epq`.`marks` AS `marks`, `epq`.`sub_marks` AS `sub_marks`, `epq`.`is_required` AS `is_required`, `epq`.`is_choice` AS `is_choice`, `epq`.`choice_group` AS `choice_group`, `epq`.`choice_instructions` AS `choice_instructions`, `epq`.`sequence_order` AS `sequence_order`, `epq`.`parent_question_id` AS `parent_question_id`, `epq`.`parent_question_key` AS `parent_question_key`, `epq`.`indentation_level` AS `indentation_level`, `epq`.`can_have_sub_questions` AS `can_have_sub_questions`, `epq`.`option_order` AS `option_order`, `epq`.`custom_instructions` AS `custom_instructions`, `epq`.`notes` AS `notes`, `epq`.`created_at` AS `created_at`, `epq`.`updated_at` AS `updated_at`, `q`.`question_text` AS `question_text`, `q`.`question_type` AS `question_type`, `q`.`difficulty_level` AS `difficulty_level`, `q`.`bloom_taxonomy` AS `bloom_taxonomy`, `q`.`options` AS `options`, `c`.`code` AS `course_code`, `c`.`title` AS `course_title`, `su`.`name` AS `study_unit_title`, concat(`u`.`first_name`,' ',`u`.`last_name`) AS `created_by_name`, concat('Q',`epq`.`question_number`,case when `epq`.`sub_question_label` is not null then concat('(',`epq`.`sub_question_label`,')') else '' end) AS `full_question_number` FROM (((((`exam_paper_questions` `epq` join `questions` `q` on(`epq`.`question_id` = `q`.`id`)) join `exam_papers` `ep` on(`epq`.`exam_paper_id` = `ep`.`id`)) join `courses` `c` on(`ep`.`course_id` = `c`.`id`)) left join `study_units` `su` on(`q`.`study_unit_id` = `su`.`id`)) left join `users` `u` on(`q`.`created_by` = `u`.`id`)) WHERE `ep`.`deleted_at` is null AND `q`.`deleted_at` is null ORDER BY `epq`.`exam_paper_id` ASC, `epq`.`section` ASC, `epq`.`sequence_order` ASC, `epq`.`indentation_level` ASC ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
