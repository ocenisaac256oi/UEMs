<?php
// upload_profile.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'includes/auth.php';
require_login(); // Ensure user is logged in

$user_id = (int)$_SESSION['user_id'];

$upload_dir = 'assets/images/profiles/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        // Delete existing profile pictures for this user
        $existing = glob($upload_dir . $user_id . '.*');
        $deleted = false;
        foreach ($existing as $ext_file) {
            if (is_file($ext_file)) {
                unlink($ext_file);
                $deleted = true;
            }
        }
        if ($deleted) {
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Profile picture deleted.'];
        }
    } elseif (isset($_FILES['profile_picture'])) {
        $file = $_FILES['profile_picture'];

        // Check for errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Error uploading file.'];
            header("Location: " . $_SERVER['HTTP_REFERER']);
            exit();
        }

        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($file['type'], $allowed_types)) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Invalid file type. Only JPG, PNG, and GIF allowed.'];
            header("Location: " . $_SERVER['HTTP_REFERER']);
            exit();
        }

        // 5MB limit
        if ($file['size'] > 5 * 1024 * 1024) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'File is too large. Max 5MB allowed.'];
            header("Location: " . $_SERVER['HTTP_REFERER']);
            exit();
        }

        // Create directory if it does not exist
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        // Delete existing profile pictures for this user to avoid conflicts
        $existing = glob($upload_dir . $user_id . '.*');
        foreach ($existing as $ext_file) {
            if (is_file($ext_file)) {
                unlink($ext_file);
            }
        }

        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = $user_id . '.' . strtolower($ext);
        $filepath = $upload_dir . $filename;

        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Profile picture updated successfully.'];
        } else {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Failed to save profile picture.'];
        }
    }
}

// Redirect back
$referer = $_SERVER['HTTP_REFERER'] ?? 'index.php';
header("Location: " . $referer);
exit();
