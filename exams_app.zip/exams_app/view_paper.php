<?php
// view_paper.php (aka paper_preview.php)
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

require_login();
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$paper_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($paper_id === 0) {
    header("Location: exam_papers.php");
    exit();
}

// Fetch Paper
$p_q = mysqli_query($conn, "SELECT p.*, c.code as course_code, c.title as course_title, d.name as dept_name, col.name as col_name 
                            FROM exam_papers p 
                            JOIN courses c ON p.course_id = c.id
                            LEFT JOIN departments d ON c.department_id = d.id
                            LEFT JOIN colleges col ON c.college_id = col.id
                            WHERE p.id = $paper_id");
if (!$p_q || mysqli_num_rows($p_q) === 0) {
    header("Location: exam_papers.php");
    exit();
}
$paper = mysqli_fetch_assoc($p_q);

// Strict security check: Lecturer can only view their own paper
if ($role === 'lecturer' && $paper['created_by'] != $user_id) {
    set_flash_message('danger', 'Unauthorized Access: You can only view examination papers that you have authored.');
    header("Location: exam_papers.php");
    exit();
}

// Submit Workflow
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit') {
    if ($paper['status'] === 'Draft' && ($role === 'lecturer' || $role === 'admin' || $role === 'hod')) {
        mysqli_query($conn, "UPDATE exam_papers SET status = 'Submitted', submitted_at = CURRENT_TIMESTAMP WHERE id = $paper_id");
        set_flash_message('success', 'Paper submitted for HOD review!');
        header("Location: view_paper.php?id=$paper_id");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_for_publishing') {
    $target_id = (int)($_POST['paper_id'] ?? $paper_id);
    if (in_array($paper['status'], ['Submitted', 'Approved']) && $role === 'hod' && $target_id > 0) {
        mysqli_query($conn, "UPDATE exam_papers SET status = 'Hod_approved', hod_approved_at = CURRENT_TIMESTAMP WHERE id = $target_id");
        mysqli_query($conn, "INSERT INTO workflow_history (exam_paper_id, action, from_status, to_status, actor_id, actor_role) VALUES ($target_id, 'hod_approved', '{$paper['status']}', 'Hod_approved', $user_id, '$role')");
        set_flash_message('success', 'Paper approved and sent to Exam Master for publishing!');
        header("Location: exam_papers.php");
        exit();
    }
}

// Fetch Questions
$questions = [];
$q_res = mysqli_query($conn, "SELECT epq.section, q.* FROM exam_paper_questions epq JOIN questions q ON epq.question_id = q.id 
                              WHERE epq.exam_paper_id = $paper_id ORDER BY epq.section, epq.sequence_order");
if ($q_res) {
    while ($row = mysqli_fetch_assoc($q_res)) {
        $questions[] = $row;
    }
}
?>

<?php require_once 'includes/header.php'; ?>

<!-- Print CSS -->
<style>
    @media print {
        @page {
            size: A4 portrait;
            margin: 15mm;

            @bottom-center {
                content: "Page " counter(page);
            }
        }

        .no-print,
        footer,
        .top-header,
        .sidebar {
            display: none !important;
        }

        #printableContent {
            box-shadow: none !important;
            padding: 0 !important;
            min-height: auto !important;
        }
    }

    #printableContent,
    #printableContent * {
        font-family: 'Times New Roman', serif !important;
        font-size: 12pt !important;
    }
</style>

<div class="row mb-4 no-print">
    <div class="col-12 text-center">
        <div class="d-flex gap-2 justify-content-center flex-wrap align-items-center">
            <a href="exam_papers.php" class="btn btn-light border btn-sm"><i class="bi bi-arrow-left"></i> Back</a>

            <?php if ($role === 'student'): ?>
                <button onclick="downloadPDF()" class="btn btn-primary btn-sm"><i class="bi bi-download"></i> Download</button>
            <?php endif; ?>

            <?php if ($role !== 'admin'): ?>
                <?php if ($paper['status'] === 'Draft' && $role !== 'hod'): ?>
                    <a href="paper_questions.php?id=<?php echo $paper_id; ?>" class="btn btn-outline-primary btn-sm"><i class="bi bi-list-check"></i> Edit Questions</a>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="action" value="submit">
                        <button type="submit" class="btn btn-primary btn-sm" onclick="return confirm('Submit for HOD review?')"><i class="bi bi-send"></i> Submit to HOD</button>
                    </form>
                <?php endif; ?>

                <?php if ($paper['status'] === 'Submitted' && $role === 'hod'): ?>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="action" value="submit_for_publishing">
                        <input type="hidden" name="paper_id" value="<?php echo $paper_id; ?>">
                        <button type="submit" class="btn btn-primary btn-sm shadow-sm" onclick="return confirm('Approve and forward this paper to the Exam Master?')">
                            <i class="bi bi-send-check"></i> Approve & Forward
                        </button>
                    </form>
                    <button class="btn btn-danger btn-sm shadow-sm" data-bs-toggle="modal" data-bs-target="#rejectModal" data-id="<?php echo $paper_id; ?>"><i class="bi bi-x-lg"></i> Reject</button>
                <?php endif; ?>

                <?php if ($paper['status'] === 'Approved' && $role === 'hod'): ?>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="action" value="submit_for_publishing">
                        <input type="hidden" name="paper_id" value="<?php echo $paper_id; ?>">
                        <button type="submit" class="btn btn-primary btn-sm shadow-sm" onclick="return confirm('Paper was previously approved. Forward to Exam Master now?')">
                            <i class="bi bi-send"></i> Forward to Exam Master
                        </button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row justify-content-center">
    <!-- Main A4 Page Preview -->
    <div class="col-lg-10 col-xl-8 mx-auto">
        <div id="printableContent" class="card shadow-lg border-0 bg-white" style="min-height: 1122px; padding: 50px;">
            <div class="text-center mb-4">
                <img src="assets/images/exam.png" alt="University Logo" style="height: 100px; width: auto;" class="mb-3">
                <h4 class="text-uppercase font-weight-bold">KAMPALA INTERNATIONAL UNIVERSITY</h4>
                <?php if (!empty($paper['col_name'])): ?>
                    <h5 class="text-uppercase"><?php echo htmlspecialchars($paper['col_name']); ?></h5>
                <?php endif; ?>

                <div class="mt-4">
                    <hr style="border: 0; border-top: 3px solid black; opacity: 1; margin: 20px 0;">
                    <div class="text-start fw-bold" style="font-size: 12pt; line-height: 1.5;">
                        <div class="row mb-1">
                            <div class="col-5">Course Code:</div>
                            <div class="col-7"><?php echo htmlspecialchars($paper['course_code']); ?></div>
                        </div>
                        <div class="row mb-1">
                            <div class="col-5">Course Title:</div>
                            <div class="col-7"><?php echo htmlspecialchars($paper['course_title']); ?></div>
                        </div>
                        <div class="row mb-1">
                            <div class="col-5">Year of Study:</div>
                            <div class="col-7"><?php echo htmlspecialchars($paper['year_of_study']); ?></div>
                        </div>
                        <div class="row mb-1">
                            <div class="col-5">Semester:</div>
                            <div class="col-7"><?php echo $paper['semester']; ?></div>
                        </div>
                        <div class="row mb-1">
                            <div class="col-5">Duration:</div>
                            <div class="col-7"><?php echo floor($paper['duration'] / 60); ?> Hours <?php echo $paper['duration'] % 60 > 0 ? ($paper['duration'] % 60) . ' Mins' : ''; ?></div>
                        </div>
                        <div class="row mb-1">
                            <div class="col-5">Exam Type:</div>
                            <div class="col-7"><?php echo htmlspecialchars($paper['exam_type']); ?></div>
                        </div>
                        <div class="row mb-1">
                            <div class="col-5">Academic Year:</div>
                            <div class="col-7"><?php echo htmlspecialchars($paper['academic_year']); ?></div>
                        </div>
                    </div>
                    <hr style="border: 0; border-top: 3px solid black; opacity: 1; margin: 20px 0;">
                </div>
            </div>

            <div class="mb-5 text-start" style="font-size: 12pt;">
                <p class="mb-1 text-uppercase fw-bold">Instructions to Candidates:</p>
                <?php if (!empty($paper['instructions'])): ?>
                    <?php echo nl2br(htmlspecialchars($paper['instructions'])); ?>
                <?php else: ?>
                    <ol class="mb-0 ps-3">
                        <li>Do not open the examination paper until instructed to do so.</li>
                        <li>Write clearly and legibly.</li>
                    </ol>
                <?php endif; ?>
            </div>

            <hr style="border: 0; border-top: 3px solid black; opacity: 1; margin-bottom: 30px; margin-top: -30px;">

            <div class="questions-list">
                <?php if (!empty($paper['paper_content'])): ?>
                    <div class="fs-6 text-start" style="white-space: pre-wrap; line-height: 1.8;"><?php echo htmlspecialchars($paper['paper_content']); ?></div>
                <?php else: ?>
                    <?php if (empty($questions)): ?>
                        <div class="alert alert-danger text-center no-print py-5 shadow-sm rounded-4 border-2">
                            <i class="bi bi-exclamation-triangle-fill display-4 text-danger mb-3"></i>
                            <h4 class="fw-bold">No Questions Attached</h4>
                            <p class="mb-4">You have generated the exam paper outline, but you have not manually selected any questions from the databank to go into this paper yet.</p>
                            <a href="paper_questions.php?id=<?php echo $paper_id; ?>" class="btn btn-danger btn-lg px-4"><i class="bi bi-list-check"></i> Select Questions Now</a>
                        </div>
                    <?php else: ?>
                        <?php
                        $current_section = '';
                        $q_num = 1;
                        ?>
                        <?php foreach ($questions as $q): ?>
                            <?php
                            if ($current_section !== $q['section']) {
                                $current_section = $q['section'];
                                echo "<h5 class='border-bottom border-dark pb-2 mb-4 text-uppercase fw-bold'>SECTION {$current_section}</h5>";
                            }
                            ?>
                            <div class="question-block mb-4 d-flex">
                                <div class="fw-bold me-2" style="width: 30px;"><?php echo $q_num++; ?>.</div>
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between mb-2">
                                        <div class="text-justify lh-base"><?php echo nl2br(htmlspecialchars($q['question_text'])); ?></div>
                                    </div>

                                    <?php if ($q['question_type'] === 'multiple_choice' && !empty($q['options'])): ?>
                                        <?php
                                        $options = json_decode($q['options'], true);
                                        if (is_array($options)):
                                        ?>
                                            <div class="ms-3 mt-2">
                                                <?php foreach ($options as $idx => $opt): ?>
                                                    <div class="mb-1"><?php echo chr(65 + $idx); ?>. <?php echo htmlspecialchars($opt); ?></div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>


</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Reject Paper</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="approvals.php">
                <div class="modal-body">
                    <input type="hidden" name="action" value="reject">
                    <input type="hidden" name="paper_id" id="reject_id">
                    <p>Are you sure you want to reject this paper and send it back to draft?</p>
                    <div class="mb-3">
                        <label class="form-label">Feedback / Reason (Optional)</label>
                        <textarea class="form-control" name="feedback" rows="3" placeholder="Explain what needs to be changed..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reject Paper</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
    function downloadPDF() {
        var element = document.getElementById('printableContent');
        var opt = {
            margin: [0.5, 0.5, 0.5, 0.5],
            filename: '<?php echo htmlspecialchars($paper['course_code']); ?>_Past_Paper.pdf',
            image: {
                type: 'jpeg',
                quality: 0.98
            },
            html2canvas: {
                scale: 2
            },
            jsPDF: {
                unit: 'in',
                format: 'letter',
                orientation: 'portrait'
            }
        };
        html2pdf().set(opt).from(element).save();
    }

    // helper for rendering letter mapping
    function getLetter(index) {
        return String.fromCharCode(65 + index);
    }

    // Manage document title for cleaner browser print headers
    var originalTitle = document.title;
    window.addEventListener("beforeprint", function() {
        document.title = "\u200b"; // Zero-width space to hide title in print header
    });
    window.addEventListener("afterprint", function() {
        document.title = originalTitle;
    });

    document.addEventListener('DOMContentLoaded', function() {
        var rejectModal = document.getElementById('rejectModal');
        if (rejectModal) {
            rejectModal.addEventListener('show.bs.modal', function(event) {
                var button = event.relatedTarget;
                rejectModal.querySelector('#reject_id').value = button.getAttribute('data-id');
            });
        }
    });
</script>

<?php require_once 'includes/footer.php'; ?>